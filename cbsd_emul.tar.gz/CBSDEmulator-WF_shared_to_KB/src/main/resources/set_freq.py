import usb1
import libusb1
import sys
import time
from struct import pack

VENDOR_ID = 0x04D8
DEVICE1_ID = 0x003F
DEVICE2_ID = 0x002F

COMMAND_DATA_LEN = 61
COMMAND_RETRIEVE_LO_FREQ = '\x01'
COMMAND_RETRIEVE_FREQ_OFFSET = '\x02'
COMMAND_UPDATE_FREQ_OFFSET = '\x05'
COMMAND_UPDATE_DEVICE_STANDBY = '\x06'
USB_TIME_OUT = 20 # ms


def getDeviceHandle(context, vendor_id, device_id, usb_device=None):
	if usb_device is None:
		handle = context.openByVendorIDAndProductID(vendor_id, device_id)
	else:
		handle = None
		bus_number, device_address = usb_device
		for device in context.getDeviceList():
			if bus_number != device.getBusNumber() \
				or device_address != device.getDeviceAddress():
				continue
			else:
				if (device.getVendorID(), device.getProductID()) == (vendor_id, device_id):
					handle = device.open()
					break
				else:
					raise ValueError(
						'Device at %03i.%03i is not of expected type: '
						'%04x.%04x, %04x.%04x expected' %
						usb_device + (vendor_id, device_id),
					)
	return handle


class UsbDevice(object):
	def __init__(self, vendor, device):
		self.vendorId = vendor
		self.deviceId = device
		self.handle = ""
		self.isConnected = False
		self.isAttached = False
		self.updateFreqFlag = False
		self.updateStandbyFlag = False
		self.loFreq = 0
		self.freqOffset = 0


class FreqControl(object):
	def __init__(self):
		self.delay = 0.25 # sec
		self.exitFlag = 0
		self.DevStandbyStatus = True

		self.context = usb1.USBContext()
		self.dev1 = UsbDevice(VENDOR_ID, DEVICE1_ID)
		self.dev2 = UsbDevice(VENDOR_ID, DEVICE2_ID)

	def start(self):
		self.DevStandbyStatus = False

		self.originFreq = 5785

		print "Start LO frequency setup.."
		time.sleep(self.delay)

	def setFreq(self, originFreq, outputFreq):
		print 'Set Frequency from [' + str(originFreq) + ' MHz] to [' + str(outputFreq) + ' MHz]'

		self.originFreq = originFreq
		self.outputFreq = outputFreq

		if self.DevStandbyStatus == False:
			self.setDevStandby(True)

		usb_device = None
		self.dev1.handle = getDeviceHandle(self.context, self.dev1.vendorId, self.dev1.deviceId, usb_device)

		if self.dev1.handle is None:
			self.dev1.isConnected = False
		else:
			self.dev1.isConnected = True

		self.dev2.handle = getDeviceHandle(self.context, self.dev2.vendorId, self.dev2.deviceId, usb_device)
		if self.dev2.handle is None:
			self.dev2.isConnected = False
		else:
			self.dev2.isConnected = True

		self.readWriteUsbDev()

	def setDevStandby(self, standby):
		print 'Set Device Standby = ' + str(standby)

		self.DevStandbyStatus = standby

	def readWriteUsbDev(self):
		if self.dev1.isConnected == True and self.dev2.isConnected == True:
			print "2 transponders are connected: MIMO Mode"
		elif self.dev1.isConnected == True or self.dev2.isConnected == True:
			print "1 transponder is connected: SISO Mode"
		else:
			print 'Transponders are not connected!!'
			return

		for dev in [self.dev1, self.dev2]:
			if dev.isConnected == True:
				dev.isAttached = dev.handle.kernelDriverActive(0)
				#print dev.isAttached

				if dev.isAttached == True:
					ret = dev.handle.detachKernelDriver(0)
					if ret != None:
						print 'detachKernelDriver=' + str(ret)
						return

				ret = dev.handle.claimInterface(0)
				if ret != None:
					print 'claimInterface=' + str(ret)
					return

				ret = self.transmitData(dev.handle, COMMAND_RETRIEVE_LO_FREQ)
				if ret == True:
					dev.loFreq = self.receiveData(dev.handle)
					dev.loFreq = dev.loFreq / 1000000 # Hz -> MHz
					print 'Current loFreq = ' + str(dev.loFreq) + ' MHz'
				else:
					print 'Unable to send command to retrieve LO frequency'
					return

				ret = self.transmitData(dev.handle, COMMAND_RETRIEVE_FREQ_OFFSET)
				if ret == True:
					dev.freqOffset = self.receiveData(dev.handle)
					dev.freqOffset = dev.freqOffset / 1000000 # Hz -> MHz
					print 'Current freqOffset = ' + str(dev.freqOffset) + ' MHz'
				else:
					print 'Unable to send command to retrieve frequency offset'
					return

				ret = self.transmitData(dev.handle, COMMAND_UPDATE_FREQ_OFFSET, currLoFreq=dev.loFreq)
				if ret != True:
					print 'Unable to send command to update frequency offset'
					return

				ret = self.transmitData(dev.handle, COMMAND_UPDATE_DEVICE_STANDBY, devStandby=self.DevStandbyStatus)
				if ret == True:
					dev.updateStandbyFlag = False
				else:
					print 'Unable to send command to update device standby'
					return

				dev.handle.releaseInterface(0)

				if dev.isAttached == True:
					ret = dev.handle.attachKernelDriver(0)
					if ret != None:
						print 'attachKernelDriver=' + str(ret)
						return

				dev.isAttached = False
			#else:
				#print 'Device [' + str(dev.deviceId) + '] is not connected..'

	def transmitData(self, handle, function, currLoFreq=0, devStandby=False):
		# Initialize the USB Data Transmit stream to 0xFF to minimize interference
		if function == COMMAND_RETRIEVE_LO_FREQ or function == COMMAND_RETRIEVE_FREQ_OFFSET:
			data = ''
			dataLen = len(data)

			if dataLen < COMMAND_DATA_LEN:
				data = data + '\x00' * (COMMAND_DATA_LEN - dataLen)

			subFunction='\x00'
			toWrite = ''.join((function, subFunction, data, pack('B', dataLen)))
		elif function == COMMAND_UPDATE_FREQ_OFFSET:
			print 'COMMAND_UPDATE_FREQ_OFFSET'

			if self.originFreq <= 0 or self.outputFreq <= 0:
				return False

			if self.originFreq < 3600: # 3600 MHz is the center of shared spectrum range
				newLoFreq = self.outputFreq - self.originFreq
			else:
				newLoFreq = self.originFreq - self.outputFreq

			freqOffset = newLoFreq - currLoFreq

			if freqOffset > 0:
				sign = '+'
			else:
				sign = '-'

			print 'new newLoFreq = ' + str(newLoFreq) + ' MHz'
			print 'new freqOffset = ' + str(freqOffset) + ' MHz'

			freqOffset = abs(freqOffset) * pow(10, 6) # MHz -> Hz

			data = ''
			data = chr(freqOffset >> 24)
			freqOffset = freqOffset & 0x00FFFFFF;
			data = data + chr(freqOffset >> 16)
			freqOffset = freqOffset & 0x0000FFFF;
			data = data + chr(freqOffset >> 8)
			freqOffset = freqOffset & 0x000000FF;
			data = data + chr(freqOffset)

			dataLen = len(data)

			if dataLen < COMMAND_DATA_LEN:
				data = data + '\x00' * (COMMAND_DATA_LEN - dataLen)

			toWrite = ''.join((function, sign, data, pack('B', dataLen)))
		elif function == COMMAND_UPDATE_DEVICE_STANDBY:
			print 'COMMAND_UPDATE_DEVICE_STANDBY'

			data = ''

			if devStandby == True:
				data = chr(1)
			else:
				data = chr(0)

			dataLen = len(data)

			if dataLen < (COMMAND_DATA_LEN + 1): # No sign data
				data = data + '\x00' * (COMMAND_DATA_LEN + 1 - dataLen)

			toWrite = ''.join((function, data, pack('B', dataLen)))
		else:
			print 'Unsupported command = ' + str(int(function))
			return False

		# Transfer data over USB
		assert len(toWrite) == 64, repr(toWrite)
		ret = handle.interruptWrite(0x01, toWrite, USB_TIME_OUT)

		if ret != 64:
			print 'interruptWrite Error=' + str(ret)
			return False

		return True

	def receiveData(self, handle):
		data = handle.interruptRead(0x81, 64, USB_TIME_OUT)

		command = ord(data[0])

#        print ord(data[1])
#        print ord(data[2])
#        print ord(data[3])
#        print ord(data[4])

		if command == 1:
			ret = ord(data[1]) << 24
			ret = ret + (ord(data[2]) << 16)
			ret = ret + (ord(data[3]) << 8)
			ret = ret + ord(data[4])
		elif command == 2:
			ret = ord(data[2]) << 24
			ret = ret + (ord(data[3]) << 16)
			ret = ret + (ord(data[4]) << 8)
			ret = ret + ord(data[5])

			if data[1] == '-':
				ret = ret * (-1)

		return ret


def main(originFreq, outputFreq):
	print "==== Init LO frequency setup ===="

	freqControl = FreqControl()
	freqControl.start()

	try:
		freqControl.setFreq(int(originFreq), int(outputFreq))
	except libusb1.USBError, ex:
		print 'USB error: ' + str(ex)

	print "==== Finished LO frequency setup ===="


if __name__ == "__main__":
	#print 'Number of arguments:', len(sys.argv), 'arguments.'
	#print 'Argument List:', str(sys.argv)

	if len(sys.argv) < 3:
		print 'Please enter parameters..'
		print 'Python set_freq.py origin_freq output_freq'

	main(sys.argv[1], sys.argv[2])