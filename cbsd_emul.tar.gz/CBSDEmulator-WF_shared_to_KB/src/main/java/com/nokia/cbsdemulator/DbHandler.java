package com.nokia.cbsdemulator;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.nokia.cbsdemulator.utils.LogUtils;
import cbsdemulator.utils.ParamUtils;
import static com.nokia.cbsdemulator.utils.LogUtils.SEVERE;
import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class handles the database.
 * @author hyperkcw
 */
public class DbHandler {
    protected Connection con = null;

    /**
     * Connect to Database
     * @return true - connects to database, false - fails to connect to database.  
     */
    /*
    protected boolean connectDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            LogUtils.INSTANCE.writeLog("SEVERE", e.getMessage());
        }
        
        String url = "jdbc:mysql://localhost:3306/cbsd_emulator";
        String opt = "?autoDeserialize=true&zeroDateTimeBehavior=convertToNull";
        url += opt;
        String username = "dbmanager";
        String passwd = "admin123";
            
        if (con == null) {
            try {
                // connect to database
                con = DriverManager.getConnection(url, username, passwd);
                LogUtils.INSTANCE.writeLog("INFO", "DB Connection = " + con);            
            } catch (SQLException e){
                LogUtils.INSTANCE.writeLog("SEVERE", e.getMessage());
                return false;
            }
        }

//        LogUtils.INSTANCE.writeLog("INFO", "Connected to DB");            
        
        return true;
    }
*/    
    /**
     * Connect to Database
     * @param configFilePath
     * @return true - connects to database, false - fails to connect to database.
     */
    protected boolean connectDB(String configFilePath) {
        String ipAddr, username, passwd, dbName;
        LogUtils.INSTANCE.writeLog("INFO", "DB configFilePath = " + configFilePath);      
        try {
            ipAddr = ParamUtils.INSTANCE.lookupSymbol("DB_IP_Address", configFilePath);
            username = ParamUtils.INSTANCE.lookupSymbol("DB_User_Name", configFilePath);
            passwd = ParamUtils.INSTANCE.lookupSymbol("DB_Password", configFilePath);
            dbName = ParamUtils.INSTANCE.lookupSymbol("CBSD_DB_Name", configFilePath);

        } catch(NullPointerException | IOException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            return false;
        }
	
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            return false;
        }
        
        if ((dbName==null) || (dbName.isEmpty()))
        {
            dbName="cbsd_emulator";
           LogUtils.INSTANCE.writeLog("INFO", "CBSD_DB_Name not given, defaulting to " + dbName);
       
        }
        String url = "jdbc:mysql://" + ipAddr + "/" + dbName;
        String opt = "?autoDeserialize=true&zeroDateTimeBehavior=convertToNull&useSSL=false";
        url += opt;        

        if (con == null) {
            try {
                // connect to database
                con = DriverManager.getConnection(url, username, passwd);
//                LogUtils.INSTANCE.writeLog("INFO", "DB Connection = " + con);            
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
                return false;
            }
        }
/*
        if (con==null)
        {
            LogUtils.INSTANCE.writeLog("SEVERE", "Unable to connect to DB ["+ dbName + "] on host ["+ ipAddr + "] with user id=[" + username+"]");
            return false;
        }

*/        
        return true;
    }
    
    /**
     * Disconnect to Database
     * @return true - disconnects to database, false - fails to disconnect to database.  
     */
    protected boolean disconnectDB() {
        try {
            if (con != null) {
                con.close();
                con = null;
            }
        } catch (SQLException e){
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            return false;
        }

//        LogUtils.INSTANCE.writeLog("INFO", "Diconnected to DB");            
        
        return true;
    }    
}
