/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator;

import com.nokia.cbsdemulator.cbsd.CBSD;
import com.nokia.cbsdemulator.cbsd.PALDevice;
import com.nokia.cbsdemulator.ui.CBSDListPane;
import com.nokia.cbsdemulator.utils.LogUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import cbsdemulator.utils.ParamUtils;
import static com.nokia.cbsdemulator.utils.LogUtils.SEVERE;
import java.io.IOException;


/**
 *
 * @author dbserver
 */
public class CBSDManager {
    
    private int nThreads;
    //private ScheduledExecutorService  threadPoolExec;
    private ThreadPoolExecutor threadPoolExec;
    private final CBSDListPane cbsdListPane;
            
    public CBSDManager(CBSDListPane pane) {
        this.cbsdListPane = pane;
    }
    
    public void start(String configFilePath) {
        ArrayList list = getCbsdList();
      
    //   String numThreads = "150" , timeout = "25"; 
        nThreads = list.size();
/*
         try {
           // numThreads = ParamUtils.INSTANCE.lookupSymbol("Num_threads", configFilePath);
            timeout = ParamUtils.INSTANCE.lookupSymbol("timeout", configFilePath);
        } catch(NullPointerException | IOException e) {
            System.out.println(e.getMessage());
        }
*/
        
        //RejectedExecutionHandler implementation
        RejectedExecutionHandlerImpl rejectionHandler = new RejectedExecutionHandlerImpl();

        // Get the ThreadFactory implementation to use
        ThreadFactory threadFactory = Executors.defaultThreadFactory();

        // Creating the ThreadPoolExecutor
        try {   
             threadPoolExec = new ThreadPoolExecutor(nThreads, nThreads+10, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<>(10), threadFactory, rejectionHandler);
            //threadPoolExec = new ScheduledThreadPoolExecutor(Integer.parseInt(numThreads));
        } catch (IllegalArgumentException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            
        }
//        int schedTimeout = Integer.parseInt(timeout);
        for (Iterator it = list.iterator(); it.hasNext();) {
            CBSD cbsd = (CBSD) it.next();
            
            if (cbsd.getAuthStatus() == 0) { // PAL
                PALDevice dev = (PALDevice)cbsd;
                threadPoolExec.execute(dev);
                //threadPoolExec.scheduleWithFixedDelay(dev,0,schedTimeout,TimeUnit.SECONDS);
            } 
            
            /*else if (cbsd.authStatus == 1) { // GAA
                GAADevice dev = (GAADevice)cbsd;
                threadPoolExec.execute(dev);
            }*/
        }
        
        LogUtils.INSTANCE.writeLog("INFO", "The number of running CBSDs = " );
    }

    public void startCBSD(CBSD cbsd) {
        //PALDevice dev = (PALDevice)cbsd;
        Thread t = new Thread ((PALDevice)cbsd);
        t.start();
    }
    
    public void stop() {
/*        
        ArrayList list = getCbsdList();

        for (Iterator it = list.iterator(); it.hasNext();) {
            CBSD cbsd = (CBSD) it.next();
            
            if (cbsd.authStatus == 0) { // PAL
                PALDevice dev = (PALDevice)cbsd;
                dev.stop();
            } else if (cbsd.authStatus == 1) { // GAA
                GAADevice dev = (GAADevice)cbsd;
                dev.stop();
            }
        }
*/        
        //shut down the pool
        List<Runnable> runningDevs = threadPoolExec.shutdownNow();

        LogUtils.INSTANCE.writeLog("INFO", "The number of running devices = " + runningDevs.size());  

        try {
            if (threadPoolExec.awaitTermination(60, TimeUnit.SECONDS)) {
                LogUtils.INSTANCE.writeLog("INFO", "Completed all CBSDs successfully.");
            } else {
                LogUtils.INSTANCE.writeLog("SEVERE", "Failed to terminate in 60 seconds." );
            } 
        } catch (InterruptedException e) {
            LogUtils.INSTANCE.writeLog("SEVERE", e.getMessage());
            Thread.currentThread().interrupt();
        }

        LogUtils.INSTANCE.writeLog("INFO", "Stop Emulation");
    }
    
    private ArrayList getCbsdList() {
        return cbsdListPane.getCbsdList();
    }
    
    public class RejectedExecutionHandlerImpl implements RejectedExecutionHandler {
        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            LogUtils.INSTANCE.writeLog("WARNING", r.toString());            
        }
    }
    
}
