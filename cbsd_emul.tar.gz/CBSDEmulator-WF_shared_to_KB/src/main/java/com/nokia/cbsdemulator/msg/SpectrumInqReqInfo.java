/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

import com.nokia.cbsdemulator.msg.EventInfo;

/**
 *
 * @author kutlay
 */
public class SpectrumInqReqInfo extends EventInfo{

    private String  sasCbsdId;
    private long  lowFreq;
    private long  highFreq;
    
    public SpectrumInqReqInfo() {
     
        sasCbsdId = "";
        lowFreq = 0;
        highFreq = 0;

    }        

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the lowFreq
     */
    public long getLowFreq() {
        return lowFreq;
    }

    /**
     * @param lowFreq the lowFreq to set
     */
    public void setLowFreq(long lowFreq) {
        this.lowFreq = lowFreq;
    }

    /**
     * @return the highFreq
     */
    public long getHighFreq() {
        return highFreq;
    }

    /**
     * @param highFreq the highFreq to set
     */
    public void setHighFreq(long highFreq) {
        this.highFreq = highFreq;
    }
}
