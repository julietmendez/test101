/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

//import cbsdemulator.cbsd.CBSDInterfaceInfo;
//import cbsdemulator.utils.LogUtils;
//import cbsdemulator.msg.EventInfo.Message;

import com.nokia.cbsdemulator.utils.LogUtils;
import java.io.StringReader;
import java.util.ArrayList;
import javax.json.Json;
import javax.json.JsonArray;
//import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonReader;

/**
 *
 * @author kutlay
 */
public class MsgParser {
    public static ArrayList<EventInfo> parseMsg(String msg) {

        ArrayList<EventInfo> eventList = new ArrayList();
        
        // Parse a message encapsulated with PAWS
        try ( // Parse a JSON message encapsulated with PAWS
            JsonReader jsonReader = Json.createReader(new StringReader(msg))) {
            JsonObject jsonObject = jsonReader.readObject();
            LogUtils.INSTANCE.writeLog("DEBUG", "jsonObject " + ": " + jsonObject);

            JsonArray paramArray;
            if (jsonObject.containsKey("registrationResponse")) {
                paramArray = jsonObject.getJsonArray("registrationResponse");
                if (paramArray.isEmpty() != true) {
                    eventList = parseRegisterRespMsg(paramArray);
                }
            } else if (jsonObject.containsKey("spectrumInquiryResponse")) {
                paramArray = jsonObject.getJsonArray("spectrumInquiryResponse");
                if (paramArray.isEmpty() != true) {
                    eventList = parseSpectrumInqRespMsg(paramArray);
                }
            } else if (jsonObject.containsKey("grantResponse")) {
                paramArray = jsonObject.getJsonArray("grantResponse");
                if (paramArray.isEmpty() != true) {
                    eventList = parseGrantRespMsg(paramArray);
                }
            } else if (jsonObject.containsKey("heartbeatResponse")) {
                paramArray = jsonObject.getJsonArray("heartbeatResponse");
                if (paramArray.isEmpty() != true) {
                    eventList = parseHeartbeatRespMsg(paramArray);
                }
            } else if (jsonObject.containsKey("relinquishmentResponse")) {
                paramArray = jsonObject.getJsonArray("relinquishmentResponse");
                if (paramArray.isEmpty() != true) {
                    eventList = parseRelinquishmentRespMsg(paramArray);
                }
            } else if (jsonObject.containsKey("deregistrationResponse")) {
                paramArray = jsonObject.getJsonArray("deregistrationResponse");
                if (paramArray.isEmpty() != true) {
                    eventList = parseDeregistrationRespMsg(paramArray);
                }
            }
        }
        return eventList;
    }
    
    private static ArrayList<EventInfo> parseRegisterRespMsg(JsonArray paramArray) {
        ArrayList<EventInfo> eventList = new ArrayList();
        for (int i = 0; i < paramArray.size(); i++) {
            JsonObject tmpObj = paramArray.getJsonObject(i);

            if (tmpObj == null) {
            } else {
                RegisterResponseInfo info = new RegisterResponseInfo();
        
                info.setMsgType(EventInfo.Message.REGISTRATION_RESP);
                info.setErrorType(0);
                JsonObject response = tmpObj.getJsonObject("response");
                int errCode = response.getJsonNumber("responseCode").intValue();
                if (response.containsKey("responseMessage")) {
                    info.setRespMsg(response.getString("responseMessage"));
                }
                String resp = "";
                JsonArray respData;
                if (response.containsKey("responseData")) {
                    respData = response.getJsonArray("responseData");
                    //registration response;  responseData data types are array of string if exists
                    for (int k = 0; k < respData.size(); k++) {
                        resp += respData.getString(k) + ", ";
                    }
                }
                info.setErrorType(errCode);
                info.setRespMsg(resp);
                
                if (info.getErrorType() == EventInfo.ErrorType.SUCCESS) {
                    info.setSasCbsdId(tmpObj.getString("cbsdId"));
/*
                    if (tmpObj.containsKey("measReportConfig")) {
                        JsonArray measReportConfigArr = tmpObj.getJsonArray("measReportConfig");
                        for (int j = 0; j < measReportConfigArr.size(); j++) {
                            String measReportConfigStr = measReportConfigArr.getString(j);
                        }
                    }
*/
                } else if (info.getErrorType() == EventInfo.ErrorType.REG_PENDING) {
                    LogUtils.INSTANCE.writeLog("INFO", info.getMsgType() + " ErrorCode:" + info.getErrorType().name()
                        + " " + info.getErrorType().errorMsg() + ": " + info.getRespMsg());                    
                
                } else {
                    LogUtils.INSTANCE.writeLog("WARNING", "Received registrationResponse responseCode " 
                        + info.getErrorType().name() + info.getErrorType().errorMsg() + info.getRespMsg());
                }
                eventList.add(info);
            }
        }
        
        return eventList;
    } 
    
    private static ArrayList<EventInfo> parseSpectrumInqRespMsg(JsonArray paramArray) {
        ArrayList<EventInfo> eventList = new ArrayList();
        
        for (int i = 0; i < paramArray.size(); i++) {
            JsonObject tmpObj = paramArray.getJsonObject(i);

            if (tmpObj == null) {
            } else {
                SpectrumInqRespInfo info = new SpectrumInqRespInfo();
        
                info.setMsgType(EventInfo.Message.SPECTRUM_INQ_RESP);
                info.setErrorType(0);
                JsonObject response = tmpObj.getJsonObject("response");
                int errCode = response.getJsonNumber("responseCode").intValue();
                if (response.containsKey("responseMessage")) {
                    info.setRespMsg(response.getString("responseMessage"));
                }
                String resp = "";
                JsonArray respData;
                if (response.containsKey("responseData")) {
                    respData = response.getJsonArray("responseData");
                    //registration response;  responseData data types are array of string if exists
                    if (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) {
                        LogUtils.INSTANCE.writeLog("WARNING", "Received SpectrumInquiry Response responseCode " 
                            + info.getErrorType().name() );
                        String[] invalidArgs = new String[respData.size()];
                        for (int k = 0; k < respData.size(); k++) {
                            invalidArgs[k] = respData.getString(k);
                            String parts[] = invalidArgs[k].split(":");
                            if (!(parts[0].isEmpty()) && !(parts[1].isEmpty())) {
                                String key = parts[0];
                                String value = parts[1];
                                if (key.equals("cbsdId")) {
                                    info.setSasCbsdId(value.trim());
                                }
                            }
                        }
                    }    
                }
                info.setErrorType(errCode);
                info.setRespMsg(resp);
                
                if ( (info.getErrorType() == EventInfo.ErrorType.SUCCESS)||
                        (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) ){ 
                    if (tmpObj.containsKey("cbsdId")) {
                        info.setSasCbsdId(tmpObj.getString("cbsdId"));
                    }
                    if (tmpObj.containsKey("availableChannel")) {
                        JsonArray availableChannelArr = tmpObj.getJsonArray("availableChannel");
                        if (availableChannelArr.size() > 0) {
                            for (int j = 0; j < availableChannelArr.size(); j++) {
                                JsonObject availChanObj = availableChannelArr.getJsonObject(j);
                                JsonObject freqRangeObj = availChanObj.getJsonObject("frequencyRange");
                                ChannelInfo chInfo = new ChannelInfo();
                                chInfo.setChannelType(availChanObj.getString("channelType"));
                                chInfo.setRuleApplied(availChanObj.getString("ruleApplied"));
                                chInfo.setStartFreq((double)freqRangeObj.getJsonNumber("lowFrequency").longValue() / 1000000);
                                chInfo.setEndFreq((double)freqRangeObj.getJsonNumber("highFrequency").longValue() / 1000000);
                            //LogUtils.INSTANCE.writeLog("INFO", "Spectrum Inquiry Response available startFreq:" 
                                //    + chInfo.startFreq + " endFreq:" + chInfo.endFreq + "channelType:" + chInfo.channelType);
                                info.getAvailChannels().add(chInfo);
                            }
                        }
                    }
/*                    
                    if (tmpObj.containsKey("measReportConfig")) {
                        JsonArray measReportConfigArr = tmpObj.getJsonArray("measReportConfig");
                        for (int j = 0; j < measReportConfigArr.size(); j++) {
                            String measReportConfigStr = measReportConfigArr.getString(j);
                        }
                    }
*/
                }
                LogUtils.INSTANCE.writeLog("DEBUG", "Spectrum Inquiry Response responseCode " 
                        + info.getErrorType().name() + info.getErrorType().errorMsg());
                eventList.add(info);
            }
        }
        
        return eventList;
    }
    
    private static ArrayList<EventInfo> parseGrantRespMsg(JsonArray paramArray) {
    
        ArrayList<EventInfo> eventList = new ArrayList();

        for (int i = 0; i < paramArray.size(); i++) {
            JsonObject tmpObj = paramArray.getJsonObject(i);

            if (tmpObj == null) {
            } else {
                GrantRespInfo info = new GrantRespInfo();
                info.setMsgType(EventInfo.Message.GRANT_RESP);
                info.setErrorType(0);
                JsonObject response = tmpObj.getJsonObject("response");
                int errCode = response.getJsonNumber("responseCode").intValue();
                if (response.containsKey("responseMessage")) {
                    info.setRespMsg(response.getString("responseMessage"));
                }
                String resp = "";
                JsonArray respData;
                if (response.containsKey("responseData")) {
                    respData = response.getJsonArray("responseData");
                    //registration response;  responseData data types are array of string if exists
                    if (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) {
                        LogUtils.INSTANCE.writeLog("WARNING", "Received Grant Response responseCode " 
                            + info.getErrorType().name() );
                        String[] invalidArgs = new String[respData.size()];
                        for (int k = 0; k < respData.size(); k++) {
                            invalidArgs[k] = respData.getString(k);
                            String parts[] = invalidArgs[k].split(":");
                            if (!(parts[0].isEmpty()) && !(parts[1].isEmpty())) {
                                String key = parts[0];
                                String value = parts[1];
                                if (key.equals("cbsdId")) {
                                    info.setSasCbsdId(value.trim());
                                }
                                if (key.equals("grantId")) {
                                    info.setGrantId(value.trim());
                                }
                            }
                        }
                    }    
                }
                info.setErrorType(errCode);
                info.setRespMsg(resp);
                
                if ( (info.getErrorType() == EventInfo.ErrorType.SUCCESS) ||
                        (info.getErrorType() == EventInfo.ErrorType.INTERFERENCE) ||
                        (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) ) {  
                    info.setSasCbsdId(tmpObj.getString("cbsdId"));
                    if (tmpObj.containsKey("grantId")) {
                        info.setGrantId(tmpObj.getString("grantId"));
                    }
                    if (tmpObj.containsKey("grantExpireTime")) {
                        info.setGrantExpireTime(tmpObj.getString("grantExpireTime"));
                    }
                    if (tmpObj.containsKey("heartbeatInterval")) {
                        info.setHeartbeatInterval(tmpObj.getJsonNumber("heartbeatInterval").intValue());
                    }
/*
                    if (tmpObj.containsKey("measReportConfig")) {
                        JsonArray measReportConfigArr = tmpObj.getJsonArray("measReportConfig");
                        for (int j = 0; j < measReportConfigArr.size(); j++) {
                            String measReportConfigStr = measReportConfigArr.getString(j);
                        }
                    }
*/
                    if (tmpObj.containsKey("operationParam")) {
                        JsonObject opParamObj = tmpObj.getJsonObject("operationParam");
                        info.setMaxEirp(opParamObj.getJsonNumber("maxEirp").doubleValue());
                        JsonObject freqRangeObj = opParamObj.getJsonObject("operationFrequencyRange");
                        info.setLowFreq(freqRangeObj.getJsonNumber("lowFrequency").longValue());
                        info.setHighFreq(freqRangeObj.getJsonNumber("highFrequency").longValue());
                        LogUtils.INSTANCE.writeLog("DEBUG", "Received Grant Response lowFreq: " + info.getLowFreq() + " highFreq: " + info.getHighFreq());
                    }
                }
                
                LogUtils.INSTANCE.writeLog("DEBUG", "Received Grant Response responseCode " 
                        + info.getErrorType().name() + info.getErrorType().errorMsg());
                eventList.add(info);
            }
        }
        
        return eventList;
    }

    private static ArrayList<EventInfo> parseHeartbeatRespMsg(JsonArray paramArray) {
        
        ArrayList<EventInfo> eventList = new ArrayList();

        for (int i = 0; i < paramArray.size(); i++) {
            JsonObject tmpObj = paramArray.getJsonObject(i);

            if (tmpObj == null) {
            } else {
                HeartbeatRespInfo info = new HeartbeatRespInfo();        
                info.setMsgType(EventInfo.Message.HEARTBEAT_RESP);
                info.setErrorType(0);
                JsonObject response = tmpObj.getJsonObject("response");
                int errCode = response.getJsonNumber("responseCode").intValue();
                if (response.containsKey("responseMessage")) {
                    info.setRespMsg(response.getString("responseMessage"));
                }
                String resp = "";
                JsonArray respData;
                if (response.containsKey("responseData")) {
                    respData = response.getJsonArray("responseData");
                    //registration response;  responseData data types are array of string if exists
                    if (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) {
                        LogUtils.INSTANCE.writeLog("WARNING", "Received Heartbeat Response responseCode " 
                            + info.getErrorType().name() );
                        String[] invalidArgs = new String[respData.size()];
                        for (int k = 0; k < respData.size(); k++) {
                            invalidArgs[k] = respData.getString(k);
                            String parts[] = invalidArgs[k].split(":");
                            if (!(parts[0].isEmpty()) && !(parts[1].isEmpty())) {
                                String key = parts[0];
                                String value = parts[1];
                                if (key.equals("cbsdId")) {
                                    info.setSasCbsdId(value.trim());
                                }
                                if (key.equals("grantId")) {
                                    info.setGrantId(value.trim());
                                }
                            }
                        }
                    }    
                }
                info.setErrorType(errCode);
                info.setRespMsg(resp);
                
                if ((info.getErrorType() == EventInfo.ErrorType.SUCCESS) || (info.getErrorType() == EventInfo.ErrorType.SUSPENDED_GRANT) ||
                        (info.getErrorType() == EventInfo.ErrorType.TERMINATED_GRANT)|| (info.getErrorType() == EventInfo.ErrorType.UNSYNC_OP_PARAM) ||
                        (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) ) {
                    if (tmpObj.containsKey("cbsdId")) {
                        info.setSasCbsdId(tmpObj.getString("cbsdId"));
                    }    
                    if (tmpObj.containsKey("grantId")) {
                        info.setGrantId(tmpObj.getString("grantId"));
                    }
                    if (tmpObj.containsKey("operationStatusReq")) {
                        info.setOperationStatusReq(tmpObj.getBoolean("operationStatusReq"));
                    }
                    if (tmpObj.containsKey("transmitExpireTime")) {
                        info.setTransmitExpireTime(tmpObj.getString("transmitExpireTime"));
                    }
                    if (tmpObj.containsKey("grantExpireTime")) {
                        info.setGrantExpireTime(tmpObj.getString("grantExpireTime"));
                    }
                    if (tmpObj.containsKey("heartbeatInterval")) {
                        info.setHeartbeatInterval(tmpObj.getJsonNumber("heartbeatInterval").intValue());
                    }
/*
                    if (tmpObj.containsKey("measReportConfig")) {
                        JsonArray measReportConfigArr = tmpObj.getJsonArray("measReportConfig");
                        for (int j = 0; j < measReportConfigArr.size(); j++) {
                            String measReportConfigStr = measReportConfigArr.getString(j);
                        }
                    }
*/
                    if (tmpObj.containsKey("operationParam")) {
                        JsonObject opParamObj = tmpObj.getJsonObject("operationParam");
                        if (opParamObj.containsKey("maxEirp")) {
                            info.setMaxEirp(opParamObj.getJsonNumber("maxEirp").doubleValue());
                            LogUtils.INSTANCE.writeLog("INFO", "Received heartbeat Response maxEirp " + info.getMaxEirp());
                        }
                        if (opParamObj.containsKey("operationFrequencyRange")) {
                            JsonObject freqRangeObj = opParamObj.getJsonObject("operationFrequencyRange");
                            info.setLowFreq(freqRangeObj.getJsonNumber("lowFrequency").longValue());
                            info.setHighFreq(freqRangeObj.getJsonNumber("highFrequency").longValue());
                            LogUtils.INSTANCE.writeLog("INFO", "Received heartbeat Response new frequencies: " 
                                    + info.getLowFreq() + ", " + info.getHighFreq());
                        }    
                    }
                }
                
                LogUtils.INSTANCE.writeLog("DEBUG", "Received heartbeat Response responseCode " 
                        + info.getErrorType().name() + info.getErrorType().errorMsg());
                eventList.add(info);
            }            
        }
        
        return eventList;
    }
    
    private static ArrayList<EventInfo> parseRelinquishmentRespMsg(JsonArray paramArray) {
    
        ArrayList<EventInfo> eventList = new ArrayList();
        for (int i = 0; i < paramArray.size(); i++) {
            JsonObject tmpObj = paramArray.getJsonObject(i);

            if (tmpObj == null) {
            } else {
                RelinquishmentRespInfo info = new RelinquishmentRespInfo();        
                info.setMsgType(EventInfo.Message.RELINQUISHMENT_RESP);
                info.setErrorType(0);
                JsonObject response = tmpObj.getJsonObject("response");
                int errCode = response.getJsonNumber("responseCode").intValue();
                if (response.containsKey("responseMessage")) {
                    info.setRespMsg(response.getString("responseMessage"));
                }
                info.setErrorType(errCode);                
                String resp = "";
                JsonArray respData;
                if (response.containsKey("responseData")) {
                    respData = response.getJsonArray("responseData");
                    //registration response;  responseData data types are array of string if exists
                    if (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) {
                        LogUtils.INSTANCE.writeLog("WARNING", "Received Relinquishment Response responseCode " 
                            + info.getErrorType().name() );
                        String[] invalidArgs = new String[respData.size()];
                        for (int k = 0; k < respData.size(); k++) {
                            invalidArgs[k] = respData.getString(k);
                            String parts[] = invalidArgs[k].split(":");
                            if (!(parts[0].isEmpty()) && !(parts[1].isEmpty())) {
                                String key = parts[0];
                                String value = parts[1];
                                if (key.equals("cbsdId")) {
                                    info.setSasCbsdId(value.trim());
                                }
                                if (key.equals("grantId")) {
                                    info.setGrantId(value.trim());
                                }
                            }
                        }
                    }    
                }
                info.setRespMsg(resp);
                
                if ( (info.getErrorType() == EventInfo.ErrorType.SUCCESS) ||
                       (info.getErrorType() == EventInfo.ErrorType.INVALID_VALUE) ) {
                    if (tmpObj.containsKey("cbsdId")) {
                        info.setSasCbsdId(tmpObj.getString("cbsdId"));
                    }    
                    if (tmpObj.containsKey("grantId")) {
                        info.setGrantId(tmpObj.getString("grantId"));
                    }
                }

                LogUtils.INSTANCE.writeLog("DEBUG", "Received Relinquishment Response responseCode " 
                        + info.getErrorType().name() + info.getErrorType().errorMsg());
                eventList.add(info);
            }
        }
        
        return eventList;
    }
    
    private static ArrayList<EventInfo> parseDeregistrationRespMsg(JsonArray paramArray) {
        ArrayList<EventInfo> eventList = new ArrayList();
        
        for (int i = 0; i < paramArray.size(); i++) {
            JsonObject tmpObj = paramArray.getJsonObject(i);

            if (tmpObj == null) {
            } else {
                DeregistrationRespInfo info = new DeregistrationRespInfo();
        
                info.setMsgType(EventInfo.Message.DEREGISTRATION_RESP);
                info.setErrorType(0);
                JsonObject response = tmpObj.getJsonObject("response");
                int errCode = response.getJsonNumber("responseCode").intValue();
                if (response.containsKey("responseMessage")) {
                    info.setRespMsg(response.getString("responseMessage"));
                }
                String resp = "";
                JsonArray respData;
                if (response.containsKey("responseData")) {
                    respData = response.getJsonArray("responseData");
                    //registration response;  responseData data types are array of string if exists
                    for (int k = 0; k < respData.size(); k++) {
                        resp += respData.getString(k) + ", ";
                    }
                }
                info.setErrorType(errCode);
                info.setRespMsg(resp);
                
                if (info.getErrorType() == EventInfo.ErrorType.SUCCESS) {                
                    if (tmpObj.containsKey("cbsdId")) {
                        info.setSasCbsdId(tmpObj.getString("cbsdId"));
                    }
                }    
                LogUtils.INSTANCE.writeLog("WARNING", "Received Deregistration Response responseCode " 
                        + info.getErrorType().name() + info.getErrorType().errorMsg());
                eventList.add(info);
            }
        }
        
        return eventList;
    }    
}

