/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

/**
 *
 * @author kutlay
 */
public class HeartbeatReqInfo extends EventInfo{
    private String  sasCbsdId;
    private String  grantId;
    private boolean grantRenew;
    private String operationState;

    
    public HeartbeatReqInfo() {
        sasCbsdId = "";
        grantId = "";
        grantRenew = false;
        operationState = "";

    }                

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the grantId
     */
    public String getGrantId() {
        return grantId;
    }

    /**
     * @param grantId the grantId to set
     */
    public void setGrantId(String grantId) {
        this.grantId = grantId;
    }

    /**
     * @return the grantRenew
     */
    public boolean isGrantRenew() {
        return grantRenew;
    }

    /**
     * @param grantRenew the grantRenew to set
     */
    public void setGrantRenew(boolean grantRenew) {
        this.grantRenew = grantRenew;
    }

    /**
     * @return the operationState
     */
    public String getOperationState() {
        return operationState;
    }

    /**
     * @param operationState the operationState to set
     */
    public void setOperationState(String operationState) {
        this.operationState = operationState;
    }
}
