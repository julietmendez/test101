/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author changki
 */
public class TimeUtils {
    private long startTime;
    private long endTime;
    private static final TimeZone timeZone = TimeZone.getTimeZone("UTC");
    
    public enum timeUnit {
        DAYS, HOURS, MINUTES, SECONDS, MILLISECONDS, MICROSECONDS;
    }
    
    public TimeUtils () {
        startTime = 0;
        endTime = 0;
    }
    
    public void startTimer() {
        startTime = System.nanoTime();
    }
    
    public void stopTimer() {
        endTime = System.nanoTime();
    }
 
    public double getTimeDiff(timeUnit unit) {
        long elapsedTime = endTime - startTime;

        double time;
        
        switch (unit) {
            case DAYS :
                time = (double)elapsedTime / 1000000000.0;
                time = time / (60*60*24);
            break;
            case HOURS :
                time = (double)elapsedTime / 1000000000.0;
                time = time / (60*60);
            break;
            case MINUTES :
                time = (double)elapsedTime / 1000000000.0;
                time = time / 60;
            break;
            case SECONDS :
                time = (double)elapsedTime / 1000000000.0;
            break;
            case MILLISECONDS :
                time = (double)elapsedTime / 1000000.0;
            break;
            case MICROSECONDS :
                time = (double)elapsedTime / 1000.0;
            break;
            default : // Milli Seconds
                time = (double)elapsedTime / 1000000.0;
        }
            
        // Return in Milli Seconds
        return time;
    }
    
    public static long getTimeDiff(String startTime, String endTime, TimeUnit unit, boolean isIso8601) {
        DateFormat dateFormat;
        if (isIso8601 == true) {
            dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // ISO 8601 Format in RFC 3339
        } else {
            dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
        dateFormat.setTimeZone(timeZone);
        
        Date start, end;
        try {
            start = dateFormat.parse(startTime);
            end = dateFormat.parse(endTime);
        } catch (ParseException e) {
            LogUtils.INSTANCE.writeLog("SEVERE", e.getMessage());            
            return 0;
        }
        
        long diff;
        
        switch (unit) { // Convert from milliseconds
            case HOURS :
                diff = (end.getTime()/3600000) - (start.getTime()/3600000);
            break;
            case MINUTES :
                diff = (end.getTime()/60000) - (start.getTime()/60000);
            break;
            case SECONDS :
                diff = (end.getTime()/1000) - (start.getTime()/1000);
            break;
            case MILLISECONDS :
                diff = end.getTime() - start.getTime();
            break;
            default : // Minutes
                diff = (end.getTime()/60000) - (start.getTime()/60000);
        }

        return diff;
    }
        
    public static String getCurrentDateTime(boolean isIso8601) {
        DateFormat dateFormat;
        
        if (isIso8601 == true) {
            dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // ISO 8601 Format in RFC 3339
        } else {
            dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
        dateFormat.setTimeZone(timeZone);

        // Get Current Date & Time
        Calendar cal = Calendar.getInstance(timeZone);
        
        return dateFormat.format(cal.getTime());
    }

    public static String getFutureTime(timeUnit unit, int period, boolean isIso8601) {
        DateFormat dateFormat;
        
        if (isIso8601 == true) {
            dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // ISO 8601 Format in RFC 3339
        } else {
            dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
        dateFormat.setTimeZone(timeZone);
        
        // Get Current Date & Time
        Calendar cal = Calendar.getInstance(timeZone);
//        LogUtils.INSTANCE.writeLog("INFO", dateFormat.format(cal.getTime()));

        switch (unit) {
            case DAYS :
                cal.add(Calendar.DAY_OF_MONTH, period);
            break;
            case HOURS :
                cal.add(Calendar.HOUR_OF_DAY, period);
            break;
            case MINUTES :
                cal.add(Calendar.MINUTE, period);
            break;
            case SECONDS :
                cal.add(Calendar.SECOND, period);
            break;
            default : // Hour
                cal.add(Calendar.HOUR_OF_DAY, period);
        }
        
        String futureTime = dateFormat.format(cal.getTime());
//        LogUtils.INSTANCE.writeLog("INFO", futureTime);

        return futureTime;
    }
    
    public static String parseIso8601DateTime(String input) {
        String output;
        
        String tmp = input.replace("T", " ");
        output = tmp.replace("Z", "");
        
        return output;
    }
    
    public static String getCurrentTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(timeZone);

        // Get Current Time
        Calendar cal = Calendar.getInstance(timeZone);

        return dateFormat.format(cal.getTime());
    }
}
