/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

import java.util.ArrayList;

/**
 *
 * @author kutlay
 */
public class RegisterResponseInfo extends EventInfo{
    private String sasCbsdId;
    private ArrayList<String> measReportConfigList;
    
    public RegisterResponseInfo() {
        measReportConfigList = new ArrayList();        
    }

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the measReportConfigList
     */
    public ArrayList<String> getMeasReportConfigList() {
        return measReportConfigList;
    }

    /**
     * @param measReportConfigList the measReportConfigList to set
     */
    public void setMeasReportConfigList(ArrayList<String> measReportConfigList) {
        this.measReportConfigList = measReportConfigList;
    }
}

