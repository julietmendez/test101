/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cbsdemulator.utils;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author dbserver
 */
public enum ParamUtils {
    INSTANCE;
    
    private static Properties symbolMap;
    private static boolean initialized = false;

    private void initialize(String path) throws IOException {
        if (initialized == false) {
            File file = new File(path);
            symbolMap = new Properties();

            //Populate the symbol map from the XML file            
            symbolMap.loadFromXML( file.toURI().toURL().openStream() );
           // initialized = false; //The reason we set this to false is be 
                                   //able to change config XML while the code is running
            initialized = true;
        }
        
    }    
    
    public String lookupSymbol(String symbol, String path) throws NullPointerException, IOException {
        String value;
        initialized = false;
        initialize(path);
            //Retrieve the value of the associated key
        value = symbolMap.getProperty(symbol);

        if (value == null) {
            throw new NullPointerException("Symbol not found: " + symbol);
        }

        return value;
    }
}
