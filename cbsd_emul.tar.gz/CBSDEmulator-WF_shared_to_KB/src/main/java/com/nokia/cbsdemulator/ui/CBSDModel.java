/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.ui;


/**
 *
 * @author dbserver
 */
public class CBSDModel {
    private int cbsdId;
    private String grantId;
    private String operator;
    private double latitude;
    private double longitude;
    private double txPower; // Unit in dBm
    private double antHeight; // Unit in meter
    private double startFreq; // Unit in MHz
    private double endFreq; // Unit in MHz
    private double bandwidth; // Unit in MHz
    private double assignedTxPower; // Unit in dBm
    private String devId;
    private String sasCbsdId;
    private String state;
    private String subState;

    public CBSDModel(int cbsdId, String grantId, String operator, 
            double latitude, double longitude, double txPower, double antHeight, 
            double startFreq, double endFreq, double bandwidth, double assignedTxPower, 
            String devId, String sasCbsdId, String state, String subState ) {
        this.cbsdId = cbsdId;
        this.grantId = grantId;
        this.operator = operator;
        this.latitude = latitude;
        this.longitude = longitude;
        this.txPower = txPower;
        this.antHeight = antHeight;
        this.startFreq = startFreq;
        this.endFreq = endFreq;
        this.bandwidth = bandwidth;
        this.assignedTxPower = assignedTxPower;
        this.devId = devId;
        this.sasCbsdId = sasCbsdId;
        this.state = state;
        this.subState = subState;
    }

    public int getCbsdId() {
        return this.cbsdId;
    }
    public void setCbsdId(int id) {
        this.cbsdId = id;
    }
    
    public String getSasCbsdId() {
        return this.sasCbsdId;
    }
    public void setSasCbsdId(String id) {
        this.sasCbsdId = id;
    }
    
    public String sasCbsdIdProperty() {
        return this.sasCbsdId;
    }

    public String getGrantId() {
        return this.grantId;
    }
    public void setGrantId(String id) {
        this.grantId=id;
    }
    
    public String grantIdProperty() {
        return this.grantId;
    }

    public String getOperator() {
        return this.operator;
    }
    public void setOperator(String oper) {
        this.operator=oper;
    }
    
    public double getLatitude() {
        return this.latitude;
    }
    public void setLatitude(double lat) {
        this.latitude=lat;
    }

    public double getLongitude() {
        return this.longitude;
    }
    public void setLongitude(double lng) {
        this.longitude=lng;
    }

    public double getTxPower() {
        return this.txPower;
    }
    public void setTxPower(double power) {
        this.txPower=power;
    }

    public double getAntHeight() {
        return this.antHeight;
    }
    public void setAntHeight(double height) {
        this.antHeight=height;
    }

    public double startFreqProperty() { // For real-time update
        return this.startFreq;
    }
    public double getStartFreq() {
        return this.startFreq;
    }
    public void setStartFreq(double freq) {
        this.startFreq=freq;
    }

    public double endFreqProperty() { // For real-time update
        return this.endFreq;
    }
    public double getEndFreq() {
        return this.endFreq;
    }
    public void setEndFreq(double freq) {
        this.endFreq=freq;
    }

    public double bandwidthProperty() { // For real-time update
        return this.bandwidth;
    }
    public double getBandwidth() {
        return this.bandwidth;
    }
    public void setBandwidth(double bw) {
        this.bandwidth=bw;
    }

    public double assignedTxPowerProperty() { // For real-time update
        return this.assignedTxPower;
    }
    public double getAssignedTxPower() {
        return this.assignedTxPower;
    }
    public void setAssignedTxPower(double power) {
        this.assignedTxPower=power;
    }
    
    public String getDevId() {
        return this.devId;
    }
    public void setDevId(String id) {
        this.devId=id;
    }
    
    public String stateProperty() { // For real-time update
        return this.state;
    }
    public String getState() {
        return this.state;
    }
    public void setState(String st) {
        this.state=st;
    }
    
    public String subStateProperty() { // For real-time update
        return this.subState;
    }
    
    public String getSubState() {
        return this.subState;
    }
    
    public void setSubState(String st) {
        this.subState=st;
    }

}