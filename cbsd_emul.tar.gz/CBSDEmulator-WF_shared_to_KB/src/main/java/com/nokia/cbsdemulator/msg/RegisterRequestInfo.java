
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

//import cbsdemulator.cbsd.CBSDInterfaceInfo;
//import java.util.ArrayList;

/**
 *
 * @author kutlay
 */
public class RegisterRequestInfo extends EventInfo{
  
    private String fccId;
    private String cbsdCategory;
    private String airInterface;    
    private String callSign;
    private String userId;
    
    private String radioTechnology;
    private String measCap;
    
    private String cbsdSerialNumber;
    
    private boolean signalStrength;
    private boolean interferenceStrength;
    
    private double latitude;
    private double longitude;
    private double txPower;
    private double antHeight;
    private String antHeightType;
    private int antAzimuth;
    private int antDowntilt;
    private int antGain;
    private int antBeamwidth;
    private int indoorDeployment;
    private String cpiId;
    private String cpiSignatureAlgorithm;
    
    private String groupId;
    private String groupType;
    
   // public DeviceDescInfo descInfo;
    
   // public ArrayList<String> licenseList;
   // public ArrayList<CBSDInterfaceInfo> ifList;
    
   // public ScannerInfo scannerInfo;
    
    public RegisterRequestInfo() {
        fccId = "";
        cbsdCategory = "";
        callSign = "";
        userId = "";
        radioTechnology = "";
        measCap = "";
        cpiId = "";
        cpiSignatureAlgorithm = "";
        latitude = 100.0;
        longitude = 200.0;
        antHeight = 0.0;
        antHeightType = "";
        antAzimuth = 0x3ff;
        antDowntilt = 0x3ff;
        antGain = 0x3ff;
        antBeamwidth = 0x3ff;
        indoorDeployment = -1;
        
        groupId = userId;
        groupType = "interference-coordination";
        txPower =0;
    }    

    /**
     * @return the fccId
     */
    public String getFccId() {
        return fccId;
    }

    /**
     * @param fccId the fccId to set
     */
    public void setFccId(String fccId) {
        this.fccId = fccId;
    }

    /**
     * @return the cbsdCategory
     */
    public String getCbsdCategory() {
        return cbsdCategory;
    }

    /**
     * @param cbsdCategory the cbsdCategory to set
     */
    public void setCbsdCategory(String cbsdCategory) {
        this.cbsdCategory = cbsdCategory;
    }

    /**
     * @return the callSign
     */
    public String getCallSign() {
        return callSign;
    }

    /**
     * @param callSign the callSign to set
     */
    public void setCallSign(String callSign) {
        this.callSign = callSign;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the radioTechnology
     */
    public String getRadioTechnology() {
        return radioTechnology;
    }

    /**
     * @param radioTechnology the radioTechnology to set
     */
    public void setRadioTechnology(String radioTechnology) {
        this.radioTechnology = radioTechnology;
    }

    /**
     * @return the cbsdSerialNumber
     */
    public String getCbsdSerialNumber() {
        return cbsdSerialNumber;
    }

    /**
     * @param cbsdSerialNumber the cbsdSerialNumber to set
     */
    public void setCbsdSerialNumber(String cbsdSerialNumber) {
        this.cbsdSerialNumber = cbsdSerialNumber;
    }

    /**
     * @return the signalStrength
     */
    public boolean isSignalStrength() {
        return signalStrength;
    }

    /**
     * @param signalStrength the signalStrength to set
     */
    public void setSignalStrength(boolean signalStrength) {
        this.signalStrength = signalStrength;
    }

    /**
     * @return the interferenceStrength
     */
    public boolean isInterferenceStrength() {
        return interferenceStrength;
    }

    /**
     * @param interferenceStrength the interferenceStrength to set
     */
    public void setInterferenceStrength(boolean interferenceStrength) {
        this.interferenceStrength = interferenceStrength;
    }

    /**
     * @return the latitude
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longitude
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     * @param longitude the longitude to set
     */
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    /**
     * @return the antHeight
     */
    public double getAntHeight() {
        return antHeight;
    }

    /**
     * @param antHeight the antHeight to set
     */
    public void setAntHeight(double antHeight) {
        this.antHeight = antHeight;
    }

    /**
     * @return the indoorDeployment
     */
    public int getIndoorDeployment() {
        return indoorDeployment;
    }

    /**
     * @param indoorDeployment the indoorDeployment to set
     */
    public void setIndoorDeployment(int indoorDeployment) {
        this.indoorDeployment = indoorDeployment;
    }

    /**
     * @return the groupId
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * @param groupId the groupId to set
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * @return the groupType
     */
    public String getGroupType() {
        return groupType;
    }

    /**
     * @param groupType the groupType to set
     */
    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    /**
     * @return the antHeightType
     */
    public String getAntHeightType() {
        return antHeightType;
    }

    /**
     * @param antHeightType the antHeightType to set
     */
    public void setAntHeightType(String antHeightType) {
        this.antHeightType = antHeightType;
    }

    /**
     * @return the antDowntilt
     */
    public int getAntDowntilt() {
        return antDowntilt;
    }

    /**
     * @param antDowntilt the antDowntilt to set
     */
    public void setAntDowntilt(int antDowntilt) {
        this.antDowntilt = antDowntilt;
    }

    /**
     * @return the antGain
     */
    public int getAntGain() {
        return antGain;
    }

    /**
     * @param antGain the antGain to set
     */
    public void setAntGain(int antGain) {
        this.antGain = antGain;
    }

    /**
     * @return the antBeamwidth
     */
    public int getAntBeamwidth() {
        return antBeamwidth;
    }

    /**
     * @param antBeamwidth the antBeamwidth to set
     */
    public void setAntBeamwidth(int antBeamwidth) {
        this.antBeamwidth = antBeamwidth;
    }

    /**
     * @return the antAzimuth
     */
    public int getAntAzimuth() {
        return antAzimuth;
    }

    /**
     * @param antAzimuth the antAzimuth to set
     */
    public void setAntAzimuth(int antAzimuth) {
        this.antAzimuth = antAzimuth;
    }

    /**
     * @return the airInterface
     */
    public String getAirInterface() {
        return airInterface;
    }

    /**
     * @param airInterface the airInterface to set
     */
    public void setAirInterface(String airInterface) {
        this.airInterface = airInterface;
    }

    /**
     * @return the measCap
     */
    public String getMeasCap() {
        return measCap;
    }

    /**
     * @param measCap the measCap to set
     */
    public void setMeasCap(String measCap) {
        this.measCap = measCap;
    }

    /**
     * @return the cpiId
     */
    public String getCpiId() {
        return cpiId;
    }

    /**
     * @param cpiId the cpiId to set
     */
    public void setCpiId(String cpiId) {
        this.cpiId = cpiId;
    }
    
/**
     * @return the cpiKey
     */
    public String getCpiSignatureAlgorithm() {
        return cpiSignatureAlgorithm;
    }

    /**
     * @param cpiSignatureAlgorithm the cpiKey to set
     */
    public void setCpiSignatureAlgorithm(String cpiSignatureAlgorithm) {
        this.cpiSignatureAlgorithm = cpiSignatureAlgorithm;
    }    

    /**
     * @return the txPower
     */
    public double getTxPower() {
        return txPower;
    }

    /**
     * @param txPower the txPower to set
     */
    public void setTxPower(double txPower) {
        this.txPower = txPower;
    }
}
