/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.ui;


/**
 *
 * @author kutlay
 */
public class GrantModel {
    private  String grantExpireTime;
    private  int lowFrequency;
    private  int highFrequency;
    private  int maxEirp;
    
    public GrantModel(String grantExpireTime, int lowFrequency, int highFrequency, int maxEirp) {
        this.grantExpireTime = grantExpireTime;
        this.lowFrequency = lowFrequency;
        this.highFrequency = highFrequency;
        this.maxEirp = maxEirp;
    }

    public String getGrantExpTime() {
        return grantExpireTime;
    }
    public void setAuthStatus(String grantExpTime) {
        grantExpireTime=grantExpTime;
    }

    public int getLowFrequency() {
        return lowFrequency;
    }
    public void setLowFrequency(int lowFrequency) {
        this.lowFrequency=lowFrequency;
    }

    public int getHighFrequency() {
        return highFrequency;
    }
    public void setHighFrequency(int highFrequency) {
        this.highFrequency=highFrequency;
    }  
    public int getMaxEip() {
        return maxEirp;
    }
    public void setMaxEip(int maxEirp) {
        this.maxEirp=maxEirp;
    }                
}
