/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.cbsd;

/**
 *
 * @author dbserver
 */
public class CBSDInfo {

    private int cbsdId;
    private String sasCbsdId;
    private int ifId;
    private int operator;
    private int authStatus;

    private double latitude;
    private double longitude;
    private double txPower; // Unit in dBm
    private double antHeight; // Unit in meter
    private String antBase;

    private double startFreq; // Unit in MHz
    private double endFreq; // Unit in MHz
    private double bandwidth; // Unit in MHz
    private double assignedTxPower;

    private double distance; // distance from source CBSD
    
    public CBSDInfo() {
        this.cbsdId = 0;
        this.sasCbsdId = "";
        this.ifId = 0;
        this.operator = 0;
        this.authStatus = 0;
        this.latitude = 0.0;
        this.longitude = 0.0;
        this.txPower = 0.0;
        this.antHeight = 0.0;
        this.antBase = "";
        this.startFreq = 0.0;
        this.endFreq = 0.0;
        this.bandwidth = 0.0;
        this.assignedTxPower = 0.0;
        this.distance = 0.0;
    }
    
    public CBSDInfo(int cbsdId, String sasCbsdId, int ifId, int operator, int authStatus,  
            double latitude, double longitude, double txPower, double antHeight, 
            String antBase, double startFreq, double endFreq, double bandwidth,
            double assignedTxPower, double distance) {
        this.cbsdId = cbsdId;
        this.sasCbsdId = sasCbsdId;
        this.ifId = ifId;
        this.operator = operator;
        this.authStatus = authStatus;
        this.latitude = latitude;
        this.longitude = longitude;
        this.txPower = txPower;
        this.antHeight = antHeight;
        this.antBase = antBase;
        this.startFreq = startFreq;
        this.endFreq = endFreq;
        this.bandwidth = bandwidth;
        this.assignedTxPower = assignedTxPower;
        this.distance = distance;
    }

    /**
     * @return the cbsdId
     */
    public int getCbsdId() {
        return cbsdId;
    }

    /**
     * @param cbsdId the cbsdId to set
     */
    public void setCbsdId(int cbsdId) {
        this.cbsdId = cbsdId;
    }

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the ifId
     */
    public int getIfId() {
        return ifId;
    }

    /**
     * @param ifId the ifId to set
     */
    public void setIfId(int ifId) {
        this.ifId = ifId;
    }

    /**
     * @return the operator
     */
    public int getOperator() {
        return operator;
    }

    /**
     * @param operator the operator to set
     */
    public void setOperator(int operator) {
        this.operator = operator;
    }

    /**
     * @return the authStatus
     */
    public int getAuthStatus() {
        return authStatus;
    }

    /**
     * @param authStatus the authStatus to set
     */
    public void setAuthStatus(int authStatus) {
        this.authStatus = authStatus;
    }

    /**
     * @return the latitude
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longitude
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     * @param longitude the longitude to set
     */
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    /**
     * @return the txPower
     */
    public double getTxPower() {
        return txPower;
    }

    /**
     * @param txPower the txPower to set
     */
    public void setTxPower(double txPower) {
        this.txPower = txPower;
    }

    /**
     * @return the antHeight
     */
    public double getAntHeight() {
        return antHeight;
    }

    /**
     * @param antHeight the antHeight to set
     */
    public void setAntHeight(double antHeight) {
        this.antHeight = antHeight;
    }

    /**
     * @return the antBase
     */
    public String getAntBase() {
        return antBase;
    }

    /**
     * @param antBase the antBase to set
     */
    public void setAntBase(String antBase) {
        this.antBase = antBase;
    }

    /**
     * @return the startFreq
     */
    public double getStartFreq() {
        return startFreq;
    }

    /**
     * @param startFreq the startFreq to set
     */
    public void setStartFreq(double startFreq) {
        this.startFreq = startFreq;
    }

    /**
     * @return the endFreq
     */
    public double getEndFreq() {
        return endFreq;
    }

    /**
     * @param endFreq the endFreq to set
     */
    public void setEndFreq(double endFreq) {
        this.endFreq = endFreq;
    }

    /**
     * @return the bandwidth
     */
    public double getBandwidth() {
        return bandwidth;
    }

    /**
     * @param bandwidth the bandwidth to set
     */
    public void setBandwidth(double bandwidth) {
        this.bandwidth = bandwidth;
    }

    /**
     * @return the assignedTxPower
     */
    public double getAssignedTxPower() {
        return assignedTxPower;
    }

    /**
     * @param assignedTxPower the assignedTxPower to set
     */
    public void setAssignedTxPower(double assignedTxPower) {
        this.assignedTxPower = assignedTxPower;
    }

    /**
     * @return the distance
     */
    public double getDistance() {
        return distance;
    }

    /**
     * @param distance the distance to set
     */
    public void setDistance(double distance) {
        this.distance = distance;
    }
}
