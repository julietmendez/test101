/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

/**
 *
 * @author kutlay
 */
public class ChannelInfo {
    private String channelType;
    private double startFreq;
    private double endFreq;
    private String ruleApplied;

    
    public ChannelInfo() {
        this.channelType = "";
        this.startFreq = 0.0;
        this.endFreq = 0.0;
        this.ruleApplied = "";
    }
    
    public ChannelInfo(String channelType, double startFreq, double endFreq, String ruleApplied) {
        this.channelType = channelType;
        this.startFreq = startFreq;
        this.endFreq = endFreq;
        this.ruleApplied = ruleApplied;
    }    

    /**
     * @return the channelType
     */
    public String getChannelType() {
        return channelType;
    }

    /**
     * @param channelType the channelType to set
     */
    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    /**
     * @return the startFreq
     */
    public double getStartFreq() {
        return startFreq;
    }

    /**
     * @param startFreq the startFreq to set
     */
    public void setStartFreq(double startFreq) {
        this.startFreq = startFreq;
    }

    /**
     * @return the endFreq
     */
    public double getEndFreq() {
        return endFreq;
    }

    /**
     * @param endFreq the endFreq to set
     */
    public void setEndFreq(double endFreq) {
        this.endFreq = endFreq;
    }

    /**
     * @return the ruleApplied
     */
    public String getRuleApplied() {
        return ruleApplied;
    }

    /**
     * @param ruleApplied the ruleApplied to set
     */
    public void setRuleApplied(String ruleApplied) {
        this.ruleApplied = ruleApplied;
    }
}
