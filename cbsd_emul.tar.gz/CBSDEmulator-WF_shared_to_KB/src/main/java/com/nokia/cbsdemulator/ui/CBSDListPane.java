/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.ui;

import com.nokia.cbsdemulator.CBSDEmulator;
import com.nokia.cbsdemulator.cbsd.CBSD;

import com.nokia.cbsdemulator.utils.LogUtils;
import static com.nokia.cbsdemulator.utils.LogUtils.SEVERE;
import java.util.ArrayList;

/**
 *
 * @author kutlay
 */
public class CBSDListPane {
    private final CBSDEmulator emulator; 
    private final ArrayList<CBSD> cbsdList = new ArrayList();
      
    private int cbsdCount;
    
    public CBSDListPane(CBSDEmulator emulator) {
        this.emulator = emulator;
        this.cbsdCount = 0;
    }
  
    public void addCbsdList(ArrayList list) {
        try {
            cbsdList.addAll(list);
        }
        catch(NullPointerException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            return;
        }
/*
        for (Iterator it = list.iterator(); it.hasNext();) {
            CBSD cbsd = (CBSD) it.next();
            for (Iterator grIt = cbsd.getGrantList().iterator(); grIt.hasNext();){
                CBSDGrantInfo grantInfo = (CBSDGrantInfo) grIt.next();
                
            }

        }
*/        
        cbsdCount = list.size();

    }
    
    public void updateCbsdNum() {
        cbsdCount = cbsdList.size();
    }
            
    public int getCbsdCount() {
        return cbsdCount;
    }
    
    public ArrayList getCbsdList() {
        return cbsdList;
    }

    
}
