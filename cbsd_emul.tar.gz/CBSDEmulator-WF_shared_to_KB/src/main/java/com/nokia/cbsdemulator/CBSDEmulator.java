/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator;


import com.nokia.cbsdemulator.cbsd.CBSD;
import com.nokia.cbsdemulator.cbsd.CBSDHandler;
import com.nokia.cbsdemulator.ui.CBSDListPane;
import com.nokia.cbsdemulator.ui.InterfaceModel;

import com.nokia.cbsdemulator.utils.LogUtils;

import cbsdemulator.utils.ParamUtils;
import com.nokia.cbsdemulator.utils.Stats;
import io.prometheus.client.exporter.HTTPServer;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author dbserver
 */
public class CBSDEmulator {
    
    private CBSDManager cbsdManager;
    
    private final CBSDListPane cbsdListPane;// = new CBSDListPane(this);
    
    private  String configFilePath;
    private  Stats  stats;
    private  String cbsdDataFilePath = "";
    private  String cbsdIpAddr;

    private boolean running;
    
    private int cbsdId;
    private int portNum;
    private String userId;
    private String fccId;
    private String serialNumber;
    private Double latitude;
    private Double longitude;
    private int startFreq;
    private int endFreq;
    private int txPower;
    private int antHeight;
    
    //@Override
    public void init(String[] args) throws Exception {
        
        System.out.println("init()");
  
        
        CBSDHandler cbsdHandle = new CBSDHandler(this.getConfigFilePath(), getStats());
        
        ArrayList cbsdList = cbsdHandle.getCbsdData(this.getConfigFilePath());
        
        
        cbsdListPane.addCbsdList(cbsdList);
         cbsdListPane.updateCbsdNum();

        setCbsdManager(new CBSDManager(cbsdListPane));
        setRunning(true);
        getCbsdManager().start(this.getConfigFilePath());
    }
    
   
    public  CBSDEmulator() {
        configFilePath = "./src/main/resources/config_emulator.xml";
        String mountedConfigFilePath = "/home/config_emulator.xml";
        String userName = System.getProperty("user.name");
        String userConfigFileName = "./src/main/resources/" + userName + "_config_emulator.xml";
        String mapServerAddress = "";
        File userConfigFile = new File(userConfigFileName);
        File dockerConfigFile = new File(mountedConfigFilePath);
        if (dockerConfigFile.exists()) {
            configFilePath = mountedConfigFilePath;
            System.out.println("Found user specific configuration File: " + mountedConfigFilePath);
        } else if (userConfigFile.exists()) {
            configFilePath = userConfigFileName;
            System.out.println("Found user specific configuration File: " + configFilePath);
        } else {

            System.out.println("DEFAULTS Configuration File : " + configFilePath);
        }
                    
        try {
            String logLevel = ParamUtils.INSTANCE.lookupSymbol("Log_Level", configFilePath);
            String logDirectory = ParamUtils.INSTANCE.lookupSymbol("Log_Directory", configFilePath);
            Integer logSize = Integer.parseInt(ParamUtils.INSTANCE.lookupSymbol("Log_FileSizeBytes", configFilePath));
            Integer logNumFiles = Integer.parseInt(ParamUtils.INSTANCE.lookupSymbol("Log_NumberOfFiles", configFilePath));
            LogUtils.INSTANCE.initialize(logLevel, logDirectory, logSize, logNumFiles); // Initialize Logger Class
            String graphiteServer = ParamUtils.INSTANCE.lookupSymbol("Graphite_Server", configFilePath);
            int graphitePort = Integer.parseInt(ParamUtils.INSTANCE.lookupSymbol("Graphite_Port", configFilePath));
            System.out.println(graphiteServer + graphitePort);
            stats = new Stats(graphiteServer,graphitePort);

        } catch(NullPointerException | IOException e) {
            throw new RuntimeException(e);
        }               
        try {
            cbsdIpAddr = ParamUtils.INSTANCE.lookupSymbol("CBSD_IP_Address", configFilePath);            
        } catch (NullPointerException | IOException e) {
            System.err.println("ERROR: Unable to determine CBSD_IP_Address");
            throw new RuntimeException(e);
        } 
        
        cbsdListPane = new CBSDListPane(this);

     }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
/*
        try {
            HTTPServer server = new HTTPServer(9500);
        } catch (IOException ex) {
            Logger.getLogger(CBSDEmulator.class.getName()).log(Level.SEVERE, null, ex);
        }
*/        
        final CBSDEmulator emulator = new CBSDEmulator();
        try {
            emulator.init(args);
        } catch (Exception ex) {
            Logger.getLogger(CBSDEmulator.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    /**
     * @return the cbsdManager
     */
    public CBSDManager getCbsdManager() {
        return cbsdManager;
    }

    /**
     * @param cbsdManager the cbsdManager to set
     */
    public void setCbsdManager(CBSDManager cbsdManager) {
        this.cbsdManager = cbsdManager;
    }

    /**
     * @return the configFilePath
     */
    public String getConfigFilePath() {
        return configFilePath;
    }

    /**
     * @param configFilePath the configFilePath to set
     */
    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }

    /**
     * @return the cbsdDataFilePath
     */
    public String getCbsdDataFilePath() {
        return cbsdDataFilePath;
    }

    /**
     * @param cbsdDataFilePath the cbsdDataFilePath to set
     */
    public void setCbsdDataFilePath(String cbsdDataFilePath) {
        this.cbsdDataFilePath = cbsdDataFilePath;
    }

    /**
     * @return the cbsdIpAddr
     */
    public String getCbsdIpAddr() {
        return cbsdIpAddr;
    }

    /**
     * @param cbsdIpAddr the cbsdIpAddr to set
     */
    public void setCbsdIpAddr(String cbsdIpAddr) {
        this.cbsdIpAddr = cbsdIpAddr;
    }

    /**
     * @return the running
     */
    public boolean isRunning() {
        return running;
    }

    /**
     * @param running the running to set
     */
    public void setRunning(boolean running) {
        this.running = running;
    }

    /**
     * @return the stats
     */
    public Stats getStats() {
        return stats;
    }

    /**
     * @param stats the stats to set
     */
    public void setStats(Stats stats) {
        this.stats = stats;
    }
}
