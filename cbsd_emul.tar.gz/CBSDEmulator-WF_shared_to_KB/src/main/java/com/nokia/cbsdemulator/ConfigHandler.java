/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator;

import java.util.ArrayList;

/**
 *
 * @author dbserver
 */
public class ConfigHandler {
    
    private static volatile ConfigHandler instance = null;
    
    final private ArrayList<String> authStatusList = new ArrayList();
    final private ArrayList<String> operatorList = new ArrayList();
            
    private ConfigHandler() { // Prevents any other class from instantiating
        authStatusList.add("PAL");
        authStatusList.add("GAA");
        
        operatorList.add("Verizon");
        operatorList.add("AT&T");
        operatorList.add("Sprint");
        operatorList.add("T-Mobile");
        operatorList.add("NOKIA");
    }
    
    public static ConfigHandler getSingletonInstance() {
        if (instance == null) {
            synchronized (ConfigHandler.class) {
                if (instance == null) { // Double check
                    instance = new ConfigHandler();
                    // System.out.println("Creating new instance");
                }
            }
        }
        
        return instance;
    }

    public String getAuthStatusString(int index) {
        return authStatusList.get(index);
    }
    
    public String getOperatorString(int index) {
        return operatorList.get(index);
    }

    public int getAuthStatusIdx(String status) {
        int index = 0;
        
        for (int i = 0; i < authStatusList.size(); i++) {
            if (authStatusList.get(i).equals(status) == true) {
                index = i;
            }
        }        
        
        return index;
    }
    
    public int getOperatorIdx(String operator) {
        int index = 0;
        
        for (int i = 0; i < operatorList.size(); i++) {
            if (operatorList.get(i).equals(operator) == true) {
                index = i;
            }
        }        
        
        return index;
    }

    public ArrayList getAuthStatusList() {
        return authStatusList;
    }
    
    public ArrayList getOperatorList() {
        return operatorList;
    }
}
