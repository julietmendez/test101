/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

/**
 *
 * @author kutlay
 */
public class EventInfo {

    /**
     * @return the msgType
     */
    public Message getMsgType() {
        return msgType;
    }

    /**
     * @param msgType the msgType to set
     */
    public void setMsgType(Message msgType) {
        this.msgType = msgType;
    }

    /**
     * @return the errorType
     */
    public ErrorType getErrorType() {
        return errorType;
    }

    /**
     * @param errorType the errorType to set
     */
    public void setErrorType(ErrorType errorType) {
        this.errorType = errorType;
    }

    /**
     * @return the respMsg
     */
    public String getRespMsg() {
        return respMsg;
    }

    /**
     * @return the cbsdId
     */
    public int getCbsdId() {
        return cbsdId;
    }

    /**
     * @param cbsdId the cbsdId to set
     */
    public void setCbsdId(int cbsdId) {
        this.cbsdId = cbsdId;
    }
    public enum Message {
        REGISTRATION_REQ, REGISTRATION_RESP, SPECTRUM_INQ_REQ, SPECTRUM_INQ_RESP, 
        GRANT_REQ, GRANT_RESP, HEARTBEAT_REQ, HEARTBEAT_RESP, RELINQUISHMENT_REQ, 
        RELINQUISHMENT_RESP, DEREGISTRATION_REQ, DEREGISTRATION_RESP, NONE;
    }
    
    public enum ErrorType {
        SUCCESS (0,""),
        
        VERSION (100,"Protocol versions supported"),
        BLACKLISTED (101, ""),
        MISSING_PARAM (102, "Missing parameter list"),
        INVALID_VALUE (103, "Parameters with invalid values"),
        CERT_ERROR (104, ""),
        DEREGISTER (105, ""),
        
        REG_PENDING (200, "missing registration params"),
        GROUP_ERROR (201, "grouping parameters errors"),
        CATEGORY_ERROR (202, ""),
        
        UNSUPPORTED_SPECTRUM (300, "Unsupported value"),
        
        INTERFERENCE (400, "List of available channels"),
        GRANT_CONFLICT (401, "grantId of an existing grant causing conflict"),
        EXCLUSION_ZONE (402, "Grant requested is in an active exclusion zone"),
        
        TERMINATED_GRANT (500, ""),
        SUSPENDED_GRANT (501, ""),
        UNSYNC_OP_PARAM (502, ""),
        
        UNKNOWN (999, "Unknown response code");
        
        private final int errorCode;
        private final String errorMsg;
        
        ErrorType(int code, String msg) {
            this.errorCode = code;
            this.errorMsg = msg;
        }
        
        public int errorCode() { 
            return errorCode;
        }
        
        public String errorMsg() { 
            return errorMsg;
        } 
    }
    private Message msgType;
    private ErrorType errorType;
    private String respMsg;
    private int cbsdId;
    
    public EventInfo() {
        msgType = Message.NONE;
        errorType = ErrorType.SUCCESS;
        cbsdId = 0;
        respMsg = "";
    } 
    
    public void setErrorType (int errType) {
        switch (errType) {
            case 0: 
                this.setErrorType(ErrorType.SUCCESS);
                break;
            case 100:
                this.setErrorType(ErrorType.VERSION);
                break;
            case 101:
                this.setErrorType(ErrorType.BLACKLISTED);
                break;
            case 102:
                this.setErrorType(ErrorType.MISSING_PARAM);
                break;
            case 103:
                this.setErrorType(ErrorType.INVALID_VALUE);
                break;
            case 104:
                this.setErrorType(ErrorType.CERT_ERROR);
                break; 
            case 105:
                this.setErrorType(ErrorType.DEREGISTER);
                break;
            case 200:
                this.setErrorType(ErrorType.REG_PENDING);
                break;
            case 201:
                this.setErrorType(ErrorType.GROUP_ERROR);
                break;
            case 202:
                this.setErrorType(ErrorType.CATEGORY_ERROR);
                break;
            case 300:
                this.setErrorType(ErrorType.UNSUPPORTED_SPECTRUM);
                break;
            case 400:
                this.setErrorType(ErrorType.INTERFERENCE);
                break;
            case 401:
                this.setErrorType(ErrorType.GRANT_CONFLICT);
                break;
            case 402:
                this.setErrorType(ErrorType.EXCLUSION_ZONE);
                break;
            case 500:
                this.setErrorType(ErrorType.TERMINATED_GRANT);
                break;
            case 501:
                this.setErrorType(ErrorType.SUSPENDED_GRANT);
                break;
            case 502:
                this.setErrorType(ErrorType.UNSYNC_OP_PARAM);
                break;
            default:
                this.setErrorType(ErrorType.UNKNOWN);
                break;
        }
    }

    public void setRespMsg(String respMsg) {
        this.respMsg = respMsg;
    }
}