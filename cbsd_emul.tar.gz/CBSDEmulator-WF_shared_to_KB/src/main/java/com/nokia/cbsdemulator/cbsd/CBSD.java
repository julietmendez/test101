/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.cbsd;

//import cbsdemulator.ConfigHandler;

import com.nokia.cbsdemulator.msg.ChannelInfo;
//import cbsdemulator.PerformanceReportCreator;
import com.nokia.cbsdemulator.msg.EventInfo;
import com.nokia.cbsdemulator.msg.MsgGenerator;
import com.nokia.cbsdemulator.msg.RegisterRequestInfo;
import com.nokia.cbsdemulator.msg.RegisterResponseInfo;
import com.nokia.cbsdemulator.msg.SpectrumInqReqInfo;
import com.nokia.cbsdemulator.msg.SpectrumInqRespInfo;
import com.nokia.cbsdemulator.msg.GrantReqInfo;
import com.nokia.cbsdemulator.msg.GrantRespInfo;
import com.nokia.cbsdemulator.msg.HeartbeatReqInfo;
import com.nokia.cbsdemulator.msg.HeartbeatRespInfo;
import com.nokia.cbsdemulator.msg.RelinquishmentReqInfo;
import com.nokia.cbsdemulator.msg.RelinquishmentRespInfo;
import com.nokia.cbsdemulator.msg.DeregistrationReqInfo;
import com.nokia.cbsdemulator.msg.DeregistrationRespInfo;
import com.nokia.cbsdemulator.utils.LogUtils;
import com.nokia.cbsdemulator.utils.NetworkUtils;
import cbsdemulator.utils.ParamUtils;
import com.nokia.cbsdemulator.utils.TimeUtils;
import com.nokia.cbsdemulator.cbsd.CBSD.StateMachine.States;
import com.nokia.cbsdemulator.cbsd.CBSDGrantInfo.GrantStateMachine.GrantStates;
import static com.nokia.cbsdemulator.utils.LogUtils.SEVERE;
import com.nokia.cbsdemulator.utils.Stats;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.Integer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import io.prometheus.client.Histogram;
import io.prometheus.client.Counter;
import java.security.InvalidKeyException;


/**
 *
 * @author kutlay
 */
public class CBSD {
    private int cbsdId;
    private String userId;
    private String fccId;
    private String serialNumber;
    private String sasCbsdId;
    private ArrayList<CBSDGrantInfo> grantList;
    private int incumbentArrivalPeriod;
    private Timer hbTimer;
    private int authStatus;

    private String cbsdCategory;
    private String airInterface;
    private ArrayList<String> measCapability;
    private double latitude;
    private double longitude;
    
    private double txPower; // Unit in dBm
    private double antHeight; // Unit in meter
    private String antHeightType;
    private int antAzimuth;
    private int antDowntilt;
    private int antGain;
    private int antBeamwidth;
    private int indoorDeployment;  
    private String measCap;
    private double startFreq; // Unit in MHz
    private double endFreq; // Unit in MHz
    private double bandwidth; // Unit in MHz
    private double assignedPower; // Unit in dBm
    private String cpiId;
    private String cpiSignatureAlgorithm;    
    
    private String license;
    private String devId;
    
    private String xmitExpTime;

    private StateMachine state;
    private String subState;
    
    private boolean stayDeregistered = false;
    private boolean isDeregistered = false;
    private boolean deregistrationInProgress = false;
    
    //private HttpsServer hServer;
    //private HttpServerMgrWf hSvrMgr;
    //protected PerformanceReportCreator perfReportCreator;
    
    private String csasIpAddr;
    private int csasPortNum;
    private String csasPath = "v1.2";
    
    private String cbsdIpAddr;
    private int cbsdPortNum;
    
    private boolean cbsdControllerEnabled;
    
    private double relocateProb = 0.0;
    private double terminateProb = 0.0;
    private double idleProb = 0.0;
    
    protected String configFilePath;
    private Stats stats;

    protected int requestId;
    
    private boolean specInqSent = false;
    private boolean spectrumAvailable = false;
    private boolean checkSpectrumAgain = false;
    
    
    /* Prometheus Metrics*/
    static final Histogram registrationRequestLatency = Histogram.build().name("registration_requests_latency_seconds").help("Registration Request latency in seconds.").register();
    static final Histogram specInqRequestLatency = Histogram.build().name("spec_inquiry_requests_latency_seconds").help("Spectrum Inquiry Request latency in seconds.").register();
    static final Histogram grantRequestLatency = Histogram.build().name("grant_requests_latency_seconds").help("Grant Request latency in seconds.").register();
    static final Histogram heartbeatRequestLatency = Histogram.build().name("heartbeat_requests_latency_seconds").help("Heartbeat Request latency in seconds.").register();
    static final Histogram relinquishmentRequestLatency = Histogram.build().name("relinquishment_requests_latency_seconds").help("Relinquishment Request latency in seconds.").register();
    static final Histogram deregistrationRequestLatency = Histogram.build().name("deregistration_requests_latency_seconds").help("DeRegistration Request latency in seconds.").register();
    
    static final Counter failedRegistrationRequests = Counter.build().name("failed_registration_requests").help("Number of failed Registration Requests").register();
    static final Counter failedSpectrumInquiryRequests = Counter.build().name("failed_spectrum_inquiry_requests").help("Number of failed Spectrum Inquiry Requests").register();
    static final Counter failedGrantRequests = Counter.build().name("failed_grant_requests").help("Number of failed Grant Requests").register();
    static final Counter failedHeartbeatRequests = Counter.build().name("failed_heartbeat_requests").help("Number of failed Heartbeat Requests").register();
    static final Counter failedRelinquishmentRequests = Counter.build().name("failed_relinquishment_requests").help("Number of failed Relinquishment Requests").register();
    static final Counter failedDeregistrationRequests = Counter.build().name("failed_deregistration_requests").help("Number of failed Deregistration Requests").register();
    
    
    
    public CBSD(int stateIdx, String filePath) {
        this.state = new StateMachine(this, stateIdx);
        configFilePath = filePath;
        try {
            this.csasIpAddr = ParamUtils.INSTANCE.lookupSymbol("CSAS_IP_Address", configFilePath);
            this.csasPortNum = Integer.parseInt(ParamUtils.INSTANCE.lookupSymbol("CSAS_Port_Number", configFilePath));
            this.relocateProb = Double.parseDouble(ParamUtils.INSTANCE.lookupSymbol("Prob_Relocation", configFilePath));
            this.terminateProb = Double.parseDouble(ParamUtils.INSTANCE.lookupSymbol("Prob_Termination", configFilePath));
            this.idleProb = Double.parseDouble(ParamUtils.INSTANCE.lookupSymbol("Prob_Idle", configFilePath));
        //    this.incumbentArrivalPeriod = Integer.parseInt(ParamUtils.INSTANCE.lookupSymbol("Incumbent_Arrival_Period", configFilePath));
            this.cbsdControllerEnabled = Boolean.parseBoolean(ParamUtils.INSTANCE.lookupSymbol("CBSD_CONTROLLER", configFilePath));
        } catch(NullPointerException | IOException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        }
        
        this.requestId = 0;
        this.userId= "";
        this.airInterface = "";
        this.cbsdCategory = "";
        this.grantList = new ArrayList();
        this.measCapability = new ArrayList();

    }
    
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }
        
    public String getSasCbsdId() {
        return sasCbsdId;
    }
    
    protected boolean sendHttpsRequest(String url, String params, EventInfo.Message msgType, ArrayList<CBSDGrantInfo> grantList) {
        LogUtils.INSTANCE.writeLog("INFO", msgType + ":" + params);
        StringBuilder respParams = new StringBuilder();
        double elapsed;
        TimeUtils t = new TimeUtils();
        String startTime = TimeUtils.getCurrentTime();
        t.startTimer();
        boolean sendReq = NetworkUtils.sendHttpsRequest(url, params, respParams);
        t.stopTimer();
        elapsed = t.getTimeDiff(TimeUtils.timeUnit.MILLISECONDS);

        
        //LogUtils.INSTANCE.writeLog("INFO", msgType + " - [" + getCbsdId() + "]:" + elapsed + "msec" );
        if (sendReq == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "Fail to send " + msgType + "[" + getCbsdId() + "]");
            try {
                sleepCbsd(10, false);
            } catch (InterruptedException ex) {
                Logger.getLogger(CBSD.class.getName()).log(Level.SEVERE, null, ex);
                Thread.currentThread().interrupt();
            }
        } else {
            //LogUtils.INSTANCE.writeLog("DEBUG", msgType + "[" + getCbsdId() + "]");
            if (handleMsg(respParams.toString(), getCsasIpAddr(), grantList) == false) {
                try {
                    sleepCbsd(10, false);
                } catch (InterruptedException ex) {
                    Logger.getLogger(CBSD.class.getName()).log(Level.SEVERE, null, ex);
                    Thread.currentThread().interrupt();
                }
            }
            try {
                getStats().update(msgType, getSasCbsdId(), grantList, startTime, elapsed);
            } catch (IOException ex) {
                Logger.getLogger(CBSD.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return sendReq;
    }

    protected void handleStateUnRegistered() throws NoSuchAlgorithmException, InvalidKeyException {
        // Change to UNREGISTERED state
    //    CBSDHandler handle = new CBSDHandler(configFilePath, stats);
//        handle.resetCbsds();
        if (isCbsdControllerEnabled()) {
            System.out.println("SENDING commission.sh\n");
            int earfcn1 = 42090;
            int earfcn2 = 42290;

            String command = "/root/Downloads/CLI/commission.sh -ne 192.168.255.129 -pw Nemuadmin:nemuuser -parameter"
                    + " LNCEL:1:earfcn:" + String.valueOf(earfcn1)
                    + ",LNCEL:2:earfcn:" + String.valueOf(earfcn2);

            try {
                Process p = Runtime.getRuntime().exec(command);
                BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

                BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

                // read the output from the command
                String s;
                System.out.println("Output of the command:" + command + "\n");
                while ((s = stdInput.readLine()) != null) {
                    System.out.println(s);
                }

                // read any errors from the attempted command
                System.out.println("ERROR of the command (if any):\n");
                while ((s = stdError.readLine()) != null) {
                    System.out.println(s);
                }
            } catch (IOException ex) {
                Logger.getLogger(CBSD.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (stayDeregistered) {
            return;
        }
        // Generate REGISTER_REQ msg
        RegisterRequestInfo info = new RegisterRequestInfo();

        info.setUserId(getUserId());
        info.setFccId(this.getFccId());
        info.setCbsdSerialNumber(this.getSerialNumber());
        info.setCbsdCategory(this.getCbsdCategory());
        info.setAirInterface(this.getAirInterface());
        info.setMeasCap(this.getMeasCap());
        info.setLatitude(this.getLatitude());
        info.setLongitude(this.getLongitude());
        info.setAntHeight(this.getAntHeight());
        info.setAntHeightType(this.getAntHeightType());
        info.setAntBeamwidth(this.getAntBeamwidth());
        info.setAntAzimuth(this.getAntAzimuth());
        info.setAntGain(this.getAntGain());
        info.setAntDowntilt(this.getAntDowntilt());
        info.setIndoorDeployment(this.getIndoorDeployment());
        info.setCpiId(this.getCpiId());
        info.setCpiSignatureAlgorithm(this.getCpiSignatureAlgorithm());
        info.setTxPower(this.txPower);
        // Get inteface information

        String msg = MsgGenerator.generateRegisterReqMsg(info);

        // Send REGISTER_REQ
        String url = "https://" + getCsasIpAddr();
        if (getCsasPortNum() > 0) {
            url += ":" + getCsasPortNum(); 
        }
        url += "/" + getCsasPath() + "/" + "registration";
        String params = msg;
        Histogram.Timer registrationReqTimer = registrationRequestLatency.startTimer();

        boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.REGISTRATION_REQ, getGrantList());
        if (sendReq) {
            registrationReqTimer.observeDuration();
        } else {
            failedRegistrationRequests.inc();
        }
    }
    
    protected void handleStateRegistered() {
  
        Boolean sendGrantReq = false;
        Boolean sendRelinquishmentReq = false;
        Boolean sendHeartbeatReq = false;
        int heartbeatInterval = 0;
        
        if ( ( isIsDeregistered() ) && (getState().getCurrState() != States.UNREGISTERED ) ){
            // start deregistration
            deregisterCbsd();
            return;
        }
        if (isDeregistrationInProgress()) {
            LogUtils.INSTANCE.writeLog("INFO", "deregistration in progress...");
            return;
        }
        if (!specInqSent) {
            // Generate SPECTRUM_INQ_REQ msg
            spectrumAvailable = false;
            checkSpectrum(3550, 3700);
        }
        
       // CBSDHandler handle = new CBSDHandler(configFilePath, stats);
        for (CBSDGrantInfo grantInfo : getGrantList()) {
            if (grantInfo.getGrantState().isGrantStateNONE() ||
                    grantInfo.getGrantState().isGrantStateIDLE()) {
                if (grantInfo.isHbTimerScheduled()) {
                    getHbTimer().cancel();
                    grantInfo.setHbTimerScheduled(false);
                    LogUtils.INSTANCE.writeLog("DEBUG", "HbTimerScheduled=" + grantInfo.isHbTimerScheduled());
                }
                grantInfo.setRelinquishSent(false);                                
                grantInfo.setSasCbsdId(this.getSasCbsdId());                
                grantInfo.getGrantState().setCurrGrantState(GrantStates.IDLE, grantInfo.getGrantId());
                grantInfo.setSendGrant(true);
                this.setStartFreq(grantInfo.getOrigLowFrequency());
                this.setEndFreq(grantInfo.getOrigHighFrequency());
                this.setBandwidth((double)grantInfo.getHighFrequency() - grantInfo.getLowFrequency());
                this.setAssignedPower(grantInfo.getMaxEirp());
                grantInfo.getGrantState().setCurrGrantState(GrantStates.IDLE, grantInfo.getGrantId());
                sendGrantReq = true;
            }
        }
        if (sendGrantReq) {
            String msg = MsgGenerator.generateGrantReqMsg(getGrantList());

            String url = "https://" + getCsasIpAddr();
            if (getCsasPortNum() > 0) {
                url += ":" + getCsasPortNum();
            }
            url += "/" + getCsasPath() + "/" + "grant";
            String params = msg;

            Histogram.Timer grantReqTimer = grantRequestLatency.startTimer();
            boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.GRANT_REQ, getGrantList() /*grantInfo.getGrantId()*/);
            if (sendReq) {
                grantReqTimer.observeDuration();
            } else {
                failedGrantRequests.inc();
            }
        }
        for (CBSDGrantInfo grantInfo : getGrantList()) {            
            if ( ( grantInfo.getGrantState().isGrantStateAUTHORIZED()) &&
                grantInfo.isGrantTimerExpired() ) {
                    grantInfo.setGrantRenew(true);   
            }
            if ( (grantInfo.getGrantState().isGrantStateGRANTED() ||
                    grantInfo.getGrantState().isGrantStateAUTHORIZED()) &&
                            !grantInfo.isHbTimerScheduled() ) {
                sendHeartbeatReq = true;
                heartbeatInterval = grantInfo.getHeartbeatInterval();
                grantInfo.setHbTimerScheduled(true);
            }      

        }
        if (sendHeartbeatReq) {
            setHbTimer(new Timer());
            getHbTimer().schedule(new HeartbeatTask(), (long) heartbeatInterval * 1000);
            LogUtils.INSTANCE.writeLog("DEBUG", "HbTimerScheduled");
        }
        if (sendRelinquishmentReq) {
            String msg = MsgGenerator.generateRelinquishmentReqMsg(getGrantList());

            // Send RELINQUISHMENT_REQ
            String url = "https://" + getCsasIpAddr();
            if (getCsasPortNum() > 0) {
                url += ":" + getCsasPortNum();
            }
            url += "/" + getCsasPath() + "/" + "relinquishment";
            String params = msg;
            Histogram.Timer relinquishmentReqTimer = relinquishmentRequestLatency.startTimer();
            Boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.RELINQUISHMENT_REQ, getGrantList());
            if (sendReq) {
                relinquishmentReqTimer.observeDuration();
            } else {
                failedRelinquishmentRequests.inc();
            }
        }        
    }
    
    public boolean deregisterCbsd() {
        
        Boolean sendRelinquishmentReq = false;
        if (getState().getCurrState() == StateMachine.States.UNREGISTERED) {
            LogUtils.INSTANCE.writeLog("INFO", "CBSD is in UNREGISTERED state");
            return true;
        } 
        setDeregistrationInProgress(true);
        for (CBSDGrantInfo grantInfo : getGrantList()) {
            if (grantInfo.getGrantState().isGrantStateGRANTED()
                    || grantInfo.getGrantState().isGrantStateAUTHORIZED()) {
                if (grantInfo.isHbTimerScheduled()) {
                    getHbTimer().cancel();
                    grantInfo.setHbTimerScheduled(false);
                    LogUtils.INSTANCE.writeLog("DEBUG", "HbTimerScheduled=" + grantInfo.isHbTimerScheduled());
                }
                grantInfo.setRelinquishSent(true);
                sendRelinquishmentReq = true;
                String msg = MsgGenerator.generateRelinquishmentReqMsg(getGrantList());

                // Send REGISTER_REQ
                String url = "https://" + getCsasIpAddr();
                if (getCsasPortNum() > 0) {
                    url += ":" + getCsasPortNum();
                }
                url += "/" + getCsasPath() + "/" + "relinquishment";
                String params = msg;
                Histogram.Timer relinquishmentReqTimer = relinquishmentRequestLatency.startTimer();
                boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.RELINQUISHMENT_REQ, getGrantList());
                if (sendReq == false) {                    
                    failedRelinquishmentRequests.inc();
                } else {
                    relinquishmentReqTimer.observeDuration();
                    grantInfo.setRelinquishSent(true);
                }            
            }
        }
        if (sendRelinquishmentReq) {
            String msg = MsgGenerator.generateRelinquishmentReqMsg(getGrantList());

            // Send REGISTER_REQ
            String url = "https://" + getCsasIpAddr();
            if (getCsasPortNum() > 0) {
                url += ":" + getCsasPortNum();
            }
            url += "/" + getCsasPath() + "/" + "relinquishment";
            String params = msg;
            Histogram.Timer relinquishmentReqTimer = relinquishmentRequestLatency.startTimer();
            boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.RELINQUISHMENT_REQ, getGrantList());
            if (sendReq == false) {
                failedRelinquishmentRequests.inc();
            } else {
                relinquishmentReqTimer.observeDuration();
            }

        }
        
        // send deregistration
        DeregistrationReqInfo deregInfo = new DeregistrationReqInfo();
        deregInfo.setSasCbsdId(this.getSasCbsdId());

        String msg = MsgGenerator.generateDeregistrationReqMsg(deregInfo);

        // Send DEREGISTER_REQ
        String url = "https://" + getCsasIpAddr();
        if (getCsasPortNum() > 0) {
            url += ":" + getCsasPortNum();
        }
        url += "/" + getCsasPath() + "/" + "deregistration";
        String params = msg;
        StringBuilder respParams = new StringBuilder();
        
        Histogram.Timer deregReqTimer = deregistrationRequestLatency.startTimer();
        boolean sendReq = NetworkUtils.sendHttpsRequest(url, params, respParams);

        setDeregistrationInProgress(false);
        if (sendReq == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "Fail to send DEREGISTRATION REQ - [" + getSasCbsdId() + "]");
            failedDeregistrationRequests.inc();
            try {
                sleepCbsd(10, false);
            } catch (InterruptedException ex) {
                Logger.getLogger(CBSD.class.getName()).log(Level.SEVERE, null, ex);
                Thread.currentThread().interrupt();
            }
        } else {
            LogUtils.INSTANCE.writeLog("DEBUG", "Success to send DEREGISTRATION REQ - [" + getSasCbsdId() + "]");
            if (handleMsg(respParams.toString(), getCsasIpAddr(), getGrantList())) {
                deregReqTimer.observeDuration();
                return true;
            }
            // clear isDeregistered flag
            //isDeregistered = false;
        }
        return false;
    }
    
    public boolean handleMsg(String msg, String clientAddr, ArrayList<CBSDGrantInfo> grantList) {
        return true;
    }
    
    
    protected void handleEvtRegisterResp(ArrayList<EventInfo> registerResponseList) {
        RegisterResponseInfo registerRespInfo = (RegisterResponseInfo)registerResponseList.get(0);
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle REGISTER_RESP cbsdId:" + registerRespInfo.getSasCbsdId());
        setSasCbsdId(registerRespInfo.getSasCbsdId());
        
        if (getState().getCurrState() != StateMachine.States.UNREGISTERED) {
            LogUtils.INSTANCE.writeLog("INFO", "CBSD is not in UNREGISTERED state");
            return;
        }

        LogUtils.INSTANCE.writeLog("DEBUG", "Registration Succeeded!!");
        
        getState().setCurrState(StateMachine.States.REGISTERED, getSasCbsdId());
        
    }
    
    protected void handleEvtSpectrumInqResp(ArrayList<EventInfo> spectrumInqRespList) {
        SpectrumInqRespInfo spectrumInqRespInfo = (SpectrumInqRespInfo)spectrumInqRespList.get(0);
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle SPECTRUM INQ RESP sasCbsdId:" + spectrumInqRespInfo.getSasCbsdId());
        if (!sasCbsdId.equals(spectrumInqRespInfo.getSasCbsdId())) {
            LogUtils.INSTANCE.writeLog("INFO", "RECEIVED a DIFFERENT CBSD ID" + spectrumInqRespInfo.getSasCbsdId() + " than " + sasCbsdId);
            return;
        }
        if (getState().getCurrState() != StateMachine.States.REGISTERED) {
            LogUtils.INSTANCE.writeLog("INFO", "CBSD is not in REGISTERED state");
            return;
        }

        if (!spectrumInqRespInfo.getAvailChannels().isEmpty()) {
            
            for (int i = 0; i < spectrumInqRespInfo.getAvailChannels().size(); i++) {
                ChannelInfo lastChannel = spectrumInqRespInfo.getAvailChannels().get(i);

                for (int j = 1; j < spectrumInqRespInfo.getAvailChannels().size(); j++) {
                    ChannelInfo currentChannel = spectrumInqRespInfo.getAvailChannels().get(j);

                    if (((int)(currentChannel.getEndFreq() - lastChannel.getStartFreq()) == (int)getBandwidth())
                            && ((int)lastChannel.getStartFreq() == (int)getStartFreq()) && ((int)currentChannel.getEndFreq() == (int)getEndFreq())) {

                        LogUtils.INSTANCE.writeLog("DEBUG", "Inquired freq free; startFreq:" + lastChannel.getStartFreq() + " end_freq:" + currentChannel.getEndFreq());
                        setStartFreq(lastChannel.getStartFreq());
                        setEndFreq(currentChannel.getEndFreq());
                        setBandwidth(getEndFreq() - getStartFreq());
                        spectrumAvailable = true;
                        break;
                    }
                }
                if (spectrumAvailable) {
                    break;
                }
            }
            
        }
        
    }
    protected void checkSpectrum(long lowFreq, long highFreq) {
    
        // Generate SPECTRUM_INQ_REQ msg
        SpectrumInqReqInfo info = new SpectrumInqReqInfo();

        info.setSasCbsdId(this.getSasCbsdId());

        info.setLowFreq(lowFreq);
        info.setHighFreq(highFreq);

        // Get inteface information
       // CBSDHandler handle = new CBSDHandler(configFilePath, stats);

        String msg = MsgGenerator.generateSpectrumInqReqMsg(info);

            // Send SPECTRUM INQ REQ
        String url = "https://" + getCsasIpAddr();
        if (getCsasPortNum() > 0) {
            url += ":" + getCsasPortNum();
        }
        url += "/" + getCsasPath() + "/" + "spectrumInquiry";
        String params = msg;
        Histogram.Timer specInqTimer = specInqRequestLatency.startTimer();
        boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.SPECTRUM_INQ_REQ, getGrantList());

        if (sendReq == true) {
            specInqTimer.observeDuration();
            specInqSent = true;
        } else {
            failedSpectrumInquiryRequests.inc();
        }
    }

    protected void handleEvtGrantResp(ArrayList<EventInfo> grantRespList) {
        GrantRespInfo grantRespInfo = (GrantRespInfo) grantRespList.get(0);
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle GRANT RESP sasCbsdId:" + grantRespInfo.getSasCbsdId());
        if (!sasCbsdId.equals(grantRespInfo.getSasCbsdId())) {
            LogUtils.INSTANCE.writeLog("WARNING", "RECEIVED a DIFFERENT CBSD ID" + grantRespInfo.getSasCbsdId() + " than " + sasCbsdId);
            return;
        }
        if (getState().getCurrState() != StateMachine.States.REGISTERED) {
            LogUtils.INSTANCE.writeLog("WARNING", "CBSD is not in REGISTERED state");
            return;
        }
        Boolean sendHeartbeat = false;
        
        LogUtils.INSTANCE.writeLog("DEBUG", "Grant Request Succeeded!!");
       // CBSDHandler handle = new CBSDHandler(configFilePath, stats);
        int respIdx = 0;
        for (CBSDGrantInfo grantInfo : getGrantList()) {
            grantRespInfo = (GrantRespInfo) grantRespList.get(respIdx);
            if (grantRespInfo.getGrantId().isEmpty()) {
                deregisterCbsd();
                stayDeregistered = true;
                return;
            }
            respIdx++;
            if (grantInfo.getGrantState().isGrantStateIDLE()) {
                if (((grantRespInfo.getErrorType() == EventInfo.ErrorType.INTERFERENCE) || 
                        (grantRespInfo.getErrorType() == EventInfo.ErrorType.GRANT_CONFLICT))
                        &&
                        (grantRespInfo.getGrantId().isEmpty()) ){
                    if ((grantRespInfo.getLowFreq() > 0) && (grantRespInfo.getHighFreq() > 0)) {
                        int lowFreq = (int) (grantRespInfo.getLowFreq());
                        int highFreq = (int) (grantRespInfo.getHighFreq());
                        if ((lowFreq > 0) && (lowFreq != grantInfo.getLowFrequency())
                                && (highFreq > 0) && (highFreq != grantInfo.getHighFrequency())) {
                            grantInfo.setFreqRange(lowFreq, highFreq);
                         
                            grantInfo.setOrigLowFrequency(lowFreq);
                            grantInfo.setOrigHighFrequency(highFreq);
                        }
                    } else {
                        deregisterCbsd();
                        stayDeregistered = true;                    
                    }
                    return;
                            
                }
                grantInfo.setGrantId(grantRespInfo.getGrantId());
                grantInfo.getGrantState().setCurrGrantState(GrantStates.GRANTED, grantInfo.getGrantId());
             
                grantInfo.setGrantHeartbeatInterval(grantRespInfo.getHeartbeatInterval());
                grantInfo.setGrantExpireTime(grantRespInfo.getGrantExpireTime());
                if ( (grantRespInfo.getMaxEirp() > 0) && grantRespInfo.getMaxEirp() != grantInfo.getMaxEirp() ) {
                    grantInfo.setMaxEirp(grantRespInfo.getMaxEirp());
                }
                long lowFreq =  grantRespInfo.getLowFreq();
                long highFreq =  grantRespInfo.getHighFreq();
                if ( (lowFreq > 0) && (lowFreq != grantInfo.getLowFrequency() ) ||
                        (highFreq > 0) && (highFreq != grantInfo.getHighFrequency() )){
                    grantInfo.setFreqRange(lowFreq, highFreq);
                  
                }
                
                this.setBandwidth((double) grantInfo.getHighFrequency() - grantInfo.getLowFrequency());
                this.setAssignedPower(grantInfo.getMaxEirp());
                // Update GUI
                grantInfo.setSendHeartbeat(true);
           
                sendHeartbeat = true;
            }
        }    
        if (sendHeartbeat) {
            String msg = MsgGenerator.generateHeartbeatReqMsg(getGrantList());
            String url = "https://" + getCsasIpAddr();
            if (getCsasPortNum() > 0) {
                url += ":" + getCsasPortNum();
            }
            url += "/" + getCsasPath() + "/" + "heartbeat";
            String params = msg;
            Histogram.Timer hbReqTimer = heartbeatRequestLatency.startTimer();
            boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.HEARTBEAT_REQ, getGrantList());
            if (sendReq == false) {
                failedHeartbeatRequests.inc();
            } else {
                hbReqTimer.observeDuration();
            }
        }    
    }
    
    protected void handleEvtHeartbeatResp(ArrayList<EventInfo> heartbeatRespList) {
        HeartbeatRespInfo heartbeatRespInfo = (HeartbeatRespInfo)heartbeatRespList.get(0);
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle HEARTBEAT RESP sasCbsdId:" 
                + heartbeatRespInfo.getSasCbsdId() + " grantId: " + heartbeatRespInfo.getGrantId());
        if (!sasCbsdId.equals(heartbeatRespInfo.getSasCbsdId())) {
            LogUtils.INSTANCE.writeLog("INFO", "RECEIVED a DIFFERENT CBSD ID" + heartbeatRespInfo.getSasCbsdId() + " than " + sasCbsdId + " grantId:" + heartbeatRespInfo.getGrantId());
            return;
        }
        if (getState().getCurrState() != StateMachine.States.REGISTERED) {
            LogUtils.INSTANCE.writeLog("DEBUG", "CBSD is not in REGISTERED state");
            return;
        }

        LogUtils.INSTANCE.writeLog("DEBUG", "Heartbeat Request Succeeded!!");

       // CBSDHandler handle = new CBSDHandler(configFilePath, stats);
        int respIdx = 0;
        for (CBSDGrantInfo grantInfo : getGrantList()) {
            heartbeatRespInfo = (HeartbeatRespInfo)heartbeatRespList.get(respIdx);
            respIdx++;
            if ((grantInfo.getGrantState().isGrantStateGRANTED() || grantInfo.getGrantState().isGrantStateAUTHORIZED() ) &&
                    (grantInfo.getGrantId().equals(heartbeatRespInfo.getGrantId()))) {
                if (heartbeatRespInfo.getErrorType() == EventInfo.ErrorType.SUCCESS) {
                    if (grantInfo.getGrantState().isGrantStateGRANTED() ) {
                        grantInfo.getGrantState().setCurrGrantState(GrantStates.AUTHORIZED, grantInfo.getGrantId());
                       
                        LogUtils.INSTANCE.writeLog("DEBUG", "AUTHORIZED [" + getCbsdId() + "/" + grantInfo.getGrantId() + "]");
                    } else {
                        
                    }
                }
                if (heartbeatRespInfo.getErrorType() == EventInfo.ErrorType.SUSPENDED_GRANT) {
                    grantInfo.getGrantState().setCurrGrantState(GrantStates.GRANTED, grantInfo.getGrantId());                      
                    LogUtils.INSTANCE.writeLog("WARNING", "SUSPENDED GRANT [" + getCbsdId() + "/" + grantInfo.getGrantId() + "]");
                }
                if (heartbeatRespInfo.getErrorType() == EventInfo.ErrorType.TERMINATED_GRANT) {
                    grantInfo.getGrantState().setCurrGrantState(GrantStates.IDLE, grantInfo.getGrantId());
                  
                    LogUtils.INSTANCE.writeLog("WARNING", "TERMINATED GRANT [" + getCbsdId() + "/" + grantInfo.getGrantId() + "]");
                    if ( (heartbeatRespInfo.getMaxEirp() > 0) && heartbeatRespInfo.getMaxEirp() != grantInfo.getMaxEirp() ) {
                        grantInfo.setNewOpParam(true);
                        grantInfo.setMaxEirp(heartbeatRespInfo.getMaxEirp());
                        this.setAssignedPower(grantInfo.getMaxEirp());
                        if (grantInfo.isTeTimerScheduled()) {
                            grantInfo.getTeTimer().cancel();
                            grantInfo.setTeTimerScheduled(false);
                        }
                    }
                    return;
                }
                
                if (heartbeatRespInfo.getErrorType() == EventInfo.ErrorType.UNSYNC_OP_PARAM) {
                    LogUtils.INSTANCE.writeLog("WARNING", "UNSYNC_OP_PARAM [" + getCbsdId() + "/" + grantInfo.getGrantId() + "]");
                    grantInfo.setGrantExpireTime(TimeUtils.getCurrentDateTime(true));
                    return;
                }
                if (heartbeatRespInfo.getHeartbeatInterval() > 0) {
                    grantInfo.setGrantHeartbeatInterval(heartbeatRespInfo.getHeartbeatInterval());
                }
                LogUtils.INSTANCE.writeLog("DEBUG", "heartbeat interval set to  " + grantInfo.getHeartbeatInterval() + " sec.");
                if (!heartbeatRespInfo.getTransmitExpireTime().isEmpty() )  {
                    grantInfo.setTransmitExpireTime(heartbeatRespInfo.getTransmitExpireTime());
                    String tCur = TimeUtils.getCurrentDateTime(true);
                    String tRecv = heartbeatRespInfo.getTransmitExpireTime();
                    long timeDiff = TimeUtils.getTimeDiff(tCur, tRecv, TimeUnit.SECONDS, true);
                    /*if (timeDiff <= 0) {
                        // STOP TRANSMITTING
                        grantInfo.getGrantState().setCurrGrantState(GrantStates.GRANTED, grantInfo.getGrantId());
                      
                        LogUtils.INSTANCE.writeLog("WARNING", "Suspending grant due to time expiry in HB [" + getCbsdId() + "/" + grantInfo.getGrantId() + "] at:" 
                                + tCur + " recvd:" + tRecv);
                        
                    }*/
                    if (grantInfo.isTeTimerScheduled()) {
                        grantInfo.getTeTimer().cancel();
                        grantInfo.setTeTimerScheduled(false);
                    }    
                    if (!grantInfo.isTeTimerScheduled() && grantInfo.getTransmitExpireTimeInSec() > 0) {
                        grantInfo.setTeTimer(new Timer());
                        grantInfo.getTeTimer().schedule(new XmitExpTask(grantInfo.getGrantId()), grantInfo.getTransmitExpireTimeInSec() * 1000);
                        grantInfo.setTeTimerScheduled(true);
                        LogUtils.INSTANCE.writeLog("DEBUG", "Transmit Timer started for " + grantInfo.getTransmitExpireTimeInSec() + " sec.");
                    }                    
                } else {
                    if (!grantInfo.isTeTimerScheduled() && grantInfo.getTransmitExpireTimeInSec() > 0) {
                        grantInfo.setTeTimer(new Timer());
                        grantInfo.getTeTimer().schedule(new XmitExpTask(grantInfo.getGrantId()), grantInfo.getTransmitExpireTimeInSec() * 1000);
                        grantInfo.setTeTimerScheduled(true);
                        LogUtils.INSTANCE.writeLog("DEBUG", "Transmit Timer restarted for " + grantInfo.getTransmitExpireTimeInSec() + " sec.");
                    }
                }
                
                if (!heartbeatRespInfo.getGrantExpireTime().isEmpty()) {
                    grantInfo.setGrantExpireTime(heartbeatRespInfo.getGrantExpireTime());
                }

                
                if ( (heartbeatRespInfo.getMaxEirp() > 0) && heartbeatRespInfo.getMaxEirp() != grantInfo.getMaxEirp() ) {
                    grantInfo.setNewOpParam(true);
                    grantInfo.setMaxEirp(heartbeatRespInfo.getMaxEirp());
                }
                /*comment this if you don't want to change to new frequency
                long lowFreq = heartbeatRespInfo.getLowFreq();
                long highFreq = heartbeatRespInfo.getHighFreq();
                if ( (lowFreq == 0) && (highFreq == 0) && 
                        (EventInfo.ErrorType.SUSPENDED_GRANT == heartbeatRespInfo.getErrorType() )){
                    LogUtils.INSTANCE.writeLog("WARNING", "SUSPENDED_GRANT [" + getCbsdId() + "/" + grantInfo.getGrantId() + "] with lowFreq = " + lowFreq + " highFreq = " +  highFreq);

                }
                if ( (lowFreq > 0) && (lowFreq != grantInfo.getLowFrequency() ) ||
                        (highFreq > 0) && (highFreq != grantInfo.getHighFrequency() )){
                    grantInfo.setNewOpParam(true);
                    spectrumAvailable = false;
                    LogUtils.INSTANCE.writeLog("WARNING", "New Op Params [" + getCbsdId() + "/" + grantInfo.getGrantId() + "] lowFreq = " + lowFreq + " highFreq = " +  highFreq);
                    grantInfo.setFreqRange((lowFreq + ((respIdx - 1) * 10000000)), (highFreq + ((respIdx - 1) * 10000000)));                    
                }*/
                //handle.updateGrantInfo(grantInfo, cbsdId);
                /*    
                    if (isCbsdControllerEnabled()) {
                        // freq received in Hz
                        System.out.println("SENDING commission.sh\n");
                        int earfcn1 = (lowFreq + 10 - 3400) * 10 + 41590;
                        int earfcn2 = (highFreq - 10 - 3400) * 10 + 41590;

                        String command = "/root/Downloads/CLI/commission.sh -ne 192.168.255.129 -pw Nemuadmin:nemuuser -parameter"
                                + " LNCEL:1:earfcn:" + String.valueOf(earfcn1)
                                + ",LNCEL:2:earfcn:" + String.valueOf(earfcn2);

                        try {
                            Process p = Runtime.getRuntime().exec(command);
                            BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

                            BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

                            // read the output from the command
                            String s;
                            System.out.println("Output of the command:" + command + "\n");
                            while ((s = stdInput.readLine()) != null) {
                                System.out.println(s);
                            }

                            // read any errors from the attempted command
                            System.out.println("ERROR of the command (if any):\n");
                            while ((s = stdError.readLine()) != null) {
                                System.out.println(s);
                            }
                        } catch (IOException ex) {
                            Logger.getLogger(CBSD.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    }
                    */
                
                // Update CBSD parameters
                if (grantInfo.isNewOpParam()) {
                    this.setBandwidth((double)grantInfo.getHighFrequency() - grantInfo.getLowFrequency());
                    this.setAssignedPower(grantInfo.getMaxEirp());
                    if (!((heartbeatRespInfo.getErrorType() == EventInfo.ErrorType.SUCCESS ) ||
                            (heartbeatRespInfo.getErrorType() == EventInfo.ErrorType.SUSPENDED_GRANT ))) {
                        this.checkSpectrumAgain = true;
                    } 
                    if (grantInfo.isHbTimerScheduled()) {
                        getHbTimer().cancel();
                        grantInfo.setHbTimerScheduled(false);
                        LogUtils.INSTANCE.writeLog("DEBUG", "HbTimerScheduled=" + grantInfo.isHbTimerScheduled());
                    }
                }   
            }
        }
    }
    
    protected void handleEvtRelinquishmentResp(ArrayList<EventInfo> relinquishmentRespList) {
        RelinquishmentRespInfo relinquishmentRespInfo = (RelinquishmentRespInfo) relinquishmentRespList.get(0);
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle RELINQUISHMENT_RESP cbsdId:" + relinquishmentRespInfo.getSasCbsdId());
        
        if (!sasCbsdId.equals(relinquishmentRespInfo.getSasCbsdId())) {
            LogUtils.INSTANCE.writeLog("WARNING", "RECEIVED a DIFFERENT CBSD ID" + relinquishmentRespInfo.getSasCbsdId() + " than " + sasCbsdId);
            return;
        }    
        if (getState().getCurrState() != StateMachine.States.REGISTERED) {
            LogUtils.INSTANCE.writeLog("INFO", "CBSD is not in REGISTERED state");
            return;
        }
       // CBSDHandler handle = new CBSDHandler(configFilePath, stats);
        int respIdx = 0;
        int numResponses = relinquishmentRespList.size();
        for (CBSDGrantInfo grantInfo : getGrantList()) {
            relinquishmentRespInfo = (RelinquishmentRespInfo) relinquishmentRespList.get(respIdx);            
            if (grantInfo.getGrantId().equals(relinquishmentRespInfo.getGrantId())) { 
                grantInfo.getGrantState().setCurrGrantState(GrantStates.NONE, grantInfo.getGrantId());
                grantInfo.setGrantId("");
                LogUtils.INSTANCE.writeLog("INFO", "RelinquishmentResp for " + grantInfo.getGrantId() + " state =" + grantInfo.getGrantState().getCurrGrantStateString());
                grantInfo.setNewOpParam(false);
            }
            respIdx++;
            if (respIdx == numResponses) {
                break;
            }
        }

        LogUtils.INSTANCE.writeLog("DEBUG", "Relinquishment Succeeded!!");
        
    }
    
    protected void handleEvtDeregistrationResp(ArrayList<EventInfo> deregisterRespList) {
        DeregistrationRespInfo deregisterRespInfo = (DeregistrationRespInfo) deregisterRespList.get(0);
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle DEREGISTER_RESP cbsdId:" + deregisterRespInfo.getSasCbsdId());

        if (!sasCbsdId.equals(deregisterRespInfo.getSasCbsdId())) {
            LogUtils.INSTANCE.writeLog("INFO", "RECEIVED a DIFFERENT CBSD ID" + deregisterRespInfo.getSasCbsdId() + " than " + sasCbsdId);
            return;
        }  
        
        if (getState().getCurrState() != StateMachine.States.REGISTERED) {
            LogUtils.INSTANCE.writeLog("INFO", "CBSD is not in REGISTERED state");
            return;
        }

        LogUtils.INSTANCE.writeLog("DEBUG", "Deregistration Succeeded!!");
        
        getState().setCurrState(StateMachine.States.UNREGISTERED, getSasCbsdId());
        setSasCbsdId("");
        //updateStatus(StateMachine.States.UNREGISTERED);
        // clear isDeregistered
        //isDeregistered = false;
    }
    
    protected boolean handleErrorRespEvt(EventInfo eventInfo) {
        LogUtils.INSTANCE.writeLog("DEBUG", "Handle ERROR_RESP");
        if (getState().getCurrState() == States.UNREGISTERED) {
            switch (eventInfo.getErrorType()) {
                case REG_PENDING:
                    LogUtils.INSTANCE.writeLog("INFO", eventInfo.getMsgType() + " ErrorCode:" + eventInfo.getErrorType().name()
                        + " " + eventInfo.getErrorType().errorMsg() + ": " + eventInfo.getRespMsg());
                    break;
                case VERSION:
                case BLACKLISTED:
                case MISSING_PARAM:
                case INVALID_VALUE:
                case CERT_ERROR:
                    LogUtils.INSTANCE.writeLog("WARNING", eventInfo.getMsgType() + " ErrorCode:" + eventInfo.getErrorType().name()
                        + " " + eventInfo.getErrorType().errorMsg() + ": " + eventInfo.getRespMsg());
                    break;
                case DEREGISTER:
                    LogUtils.INSTANCE.writeLog("WARNING", eventInfo.getMsgType() + " ErrorCode:" + eventInfo.getErrorType().name()
                        + " " + eventInfo.getErrorType().errorMsg() + ": " + eventInfo.getRespMsg());
                    return false;
                default:
                    LogUtils.INSTANCE.writeLog("WARNING", "Invalid response code in unregistered state!!" + eventInfo.toString() + eventInfo.getMsgType());
                    break;
            }
        } else {
            LogUtils.INSTANCE.writeLog("DEBUG", "Registered!!" + eventInfo.getMsgType() + " " + eventInfo.getErrorType().name()
                        + " " + eventInfo.getErrorType().errorMsg() + ": " + eventInfo.getRespMsg());
            switch (eventInfo.getErrorType()) {
                case VERSION:
                case BLACKLISTED:
                case MISSING_PARAM:
                case CERT_ERROR:
                    LogUtils.INSTANCE.writeLog("WARNING", eventInfo.getMsgType() + " ErrorCode:" + eventInfo.getErrorType().name()
                        + " " + eventInfo.getErrorType().errorMsg() + ": " + eventInfo.getRespMsg());
                    return false;
                case INVALID_VALUE:
                    LogUtils.INSTANCE.writeLog("WARNING", eventInfo.getMsgType() + " ErrorCode:" + eventInfo.getErrorType().name()
                        + " " + eventInfo.getErrorType().errorMsg() + ": " + eventInfo.getRespMsg());
                    return true;
                case DEREGISTER:
                    LogUtils.INSTANCE.writeLog("SEVERE", "Going Unregistered state!!" + eventInfo.toString() + eventInfo.getMsgType());
                    // first deregister from SAS
                    deregisterCbsd();
                    return false;
                case GROUP_ERROR:
                    break;
                case CATEGORY_ERROR:
                    break;
                case INTERFERENCE:
                    return true;
                case GRANT_CONFLICT:
                    break;
                case EXCLUSION_ZONE:
                    LogUtils.INSTANCE.writeLog("SEVERE", "Received errorType EXCLUSION_ZONE!!" + eventInfo.toString() + eventInfo.getMsgType());
                    return true;
                case TERMINATED_GRANT:
                case SUSPENDED_GRANT: 
                case UNSYNC_OP_PARAM:    
                    return true;
                case UNSUPPORTED_SPECTRUM:
                    break;
                default:
                    break;
            }
        }
        return false;
    }
   
    protected double createTxPower(double avgTxPower) {
        return avgTxPower + 0.0;
    }
    
    protected double createAntHeight(double avgAntHeight) {
        return avgAntHeight + 0.0;
    }

    protected void updateStatus(CBSD.StateMachine.States state) {
        CBSDHandler handle = new CBSDHandler(configFilePath, getStats());
                
    //    handle.updateState(state, getCbsdId(), getSasCbsdId());
                
        LogUtils.INSTANCE.writeLog("DEBUG", 
                "CBSD [" + getCbsdId() + "] Update [" + state + "] STATE in DB SAS_CBSD_ID:" + getSasCbsdId());
    }
    
    protected void updateGrantStatus(CBSDGrantInfo grantInfo) {
       // CBSDHandler handle = new CBSDHandler(configFilePath, stats);
                
        //handle.updateGrantInfo(grantInfo, cbsdId);
                
        LogUtils.INSTANCE.writeLog("DEBUG", 
                "CBSD [" + getCbsdId() + "-" + "] Update [" + grantInfo.getGrantState().getCurrGrantStateString() + "] STATE in DB SAS_CBSD_ID:" + getSasCbsdId());
    }
    
    protected void sleepCbsd(int secs, boolean random) throws InterruptedException {
        int r;
        
        if (random == true) {
            r = ThreadLocalRandom.current().nextInt(1, secs); // in secs
        } else {
            r = secs;
        }

        LogUtils.INSTANCE.writeLog("DEBUG", "Sleep Time = " + r + " secs");
        
        long sleepTime = (long) ( r * 1000d );
        Thread.sleep(sleepTime);
    }    

    /**
     * @return the cbsdId
     */
    public int getCbsdId() {
        return cbsdId;
    }

    /**
     * @param cbsdId the cbsdId to set
     */
    public void setCbsdId(int cbsdId) {
        this.cbsdId = cbsdId;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the fccId
     */
    public String getFccId() {
        return fccId;
    }

    /**
     * @param fccId the fccId to set
     */
    public void setFccId(String fccId) {
        this.fccId = fccId;
    }

    /**
     * @return the serialNumber
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * @param serialNumber the serialNumber to set
     */
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * @return the grantList
     */
    public ArrayList<CBSDGrantInfo> getGrantList() {
        return grantList;
    }

    /**
     * @param grantList the grantList to set
     */
    public void setGrantList(ArrayList<CBSDGrantInfo> grantList) {
        this.grantList = grantList;
    }

    /**
     * @return the incumbentArrivalPeriod
     */
    public int getIncumbentArrivalPeriod() {
        return incumbentArrivalPeriod;
    }

    /**
     * @param incumbentArrivalPeriod the incumbentArrivalPeriod to set
     */
    public void setIncumbentArrivalPeriod(int incumbentArrivalPeriod) {
        this.incumbentArrivalPeriod = incumbentArrivalPeriod;
    }

    /**
     * @return the hbTimer
     */
    public Timer getHbTimer() {
        return hbTimer;
    }

    /**
     * @param hbTimer the hbTimer to set
     */
    public void setHbTimer(Timer hbTimer) {
        this.hbTimer = hbTimer;
    }

    /**
     * @return the authStatus
     */
    public int getAuthStatus() {
        return authStatus;
    }

    /**
     * @param authStatus the authStatus to set
     */
    public void setAuthStatus(int authStatus) {
        this.authStatus = authStatus;
    }

    /**
     * @return the latitude
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longitude
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     * @param longitude the longitude to set
     */
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    /**
     * @return the txPower
     */
    public double getTxPower() {
        return txPower;
    }

    /**
     * @param txPower the txPower to set
     */
    public void setTxPower(double txPower) {
        this.txPower = txPower;
    }

    /**
     * @return the antHeight
     */
    public double getAntHeight() {
        return antHeight;
    }

    /**
     * @param antHeight the antHeight to set
     */
    public void setAntHeight(double antHeight) {
        this.antHeight = antHeight;
    }

    /**
     * @return the startFreq
     */
    public double getStartFreq() {
        return startFreq;
    }

    /**
     * @param startFreq the startFreq to set
     */
    public void setStartFreq(double startFreq) {
        this.startFreq = startFreq;
    }

    /**
     * @return the endFreq
     */
    public double getEndFreq() {
        return endFreq;
    }

    /**
     * @param endFreq the endFreq to set
     */
    public void setEndFreq(double endFreq) {
        this.endFreq = endFreq;
    }

    /**
     * @return the bandwidth
     */
    public double getBandwidth() {
        return bandwidth;
    }

    /**
     * @param bandwidth the bandwidth to set
     */
    public void setBandwidth(double bandwidth) {
        this.bandwidth = bandwidth;
    }

    /**
     * @return the assignedPower
     */
    public double getAssignedPower() {
        return assignedPower;
    }

    /**
     * @param assignedPower the assignedPower to set
     */
    public void setAssignedPower(double assignedPower) {
        this.assignedPower = assignedPower;
    }

    /**
     * @return the license
     */
    public String getLicense() {
        return license;
    }

    /**
     * @param license the license to set
     */
    public void setLicense(String license) {
        this.license = license;
    }

    /**
     * @return the xmitExpTime
     */
    public String getXmitExpTime() {
        return xmitExpTime;
    }

    /**
     * @param xmitExpTime the xmitExpTime to set
     */
    public void setXmitExpTime(String xmitExpTime) {
        this.xmitExpTime = xmitExpTime;
    }

    /**
     * @return the state
     */
    public StateMachine getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(StateMachine state) {
        this.state = state;
    }

    /**
     * @return the subState
     */
    public String getSubState() {
        return subState;
    }

    /**
     * @param subState the subState to set
     */
    public void setSubState(String subState) {
        this.subState = subState;
    }

    /**
     * @return the isDeregistered
     */
    public boolean isIsDeregistered() {
        return isDeregistered;
    }

    /**
     * @param isDeregistered the isDeregistered to set
     */
    public void setIsDeregistered(boolean isDeregistered) {
        this.isDeregistered = isDeregistered;
    }

    /**
     * @return the deregistrationInProgress
     */
    public boolean isDeregistrationInProgress() {
        return deregistrationInProgress;
    }

    /**
     * @param deregistrationInProgress the deregistrationInProgress to set
     */
    public void setDeregistrationInProgress(boolean deregistrationInProgress) {
        this.deregistrationInProgress = deregistrationInProgress;
    }

    /**
     * @return the csasIpAddr
     */
    public String getCsasIpAddr() {
        return csasIpAddr;
    }

    /**
     * @param csasIpAddr the csasIpAddr to set
     */
    public void setCsasIpAddr(String csasIpAddr) {
        this.csasIpAddr = csasIpAddr;
    }

    /**
     * @return the csasPortNum
     */
    public int getCsasPortNum() {
        return csasPortNum;
    }

    /**
     * @param csasPortNum the csasPortNum to set
     */
    public void setCsasPortNum(int csasPortNum) {
        this.csasPortNum = csasPortNum;
    }

    /**
     * @return the csasPath
     */
    public String getCsasPath() {
        return csasPath;
    }

    /**
     * @param csasPath the csasPath to set
     */
    public void setCsasPath(String csasPath) {
        this.csasPath = csasPath;
    }

    /**
     * @return the cbsdIpAddr
     */
    public String getCbsdIpAddr() {
        return cbsdIpAddr;
    }

    /**
     * @param cbsdIpAddr the cbsdIpAddr to set
     */
    public void setCbsdIpAddr(String cbsdIpAddr) {
        this.cbsdIpAddr = cbsdIpAddr;
    }

    /**
     * @return the cbsdPortNum
     */
    public int getCbsdPortNum() {
        return cbsdPortNum;
    }

    /**
     * @param cbsdPortNum the cbsdPortNum to set
     */
    public void setCbsdPortNum(int cbsdPortNum) {
        this.cbsdPortNum = cbsdPortNum;
    }

    /**
     * @return the cbsdControllerEnabled
     */
    public boolean isCbsdControllerEnabled() {
        return cbsdControllerEnabled;
    }

    /**
     * @param cbsdControllerEnabled the cbsdControllerEnabled to set
     */
    public void setCbsdControllerEnabled(boolean cbsdControllerEnabled) {
        this.cbsdControllerEnabled = cbsdControllerEnabled;
    }

    /**
     * @return the stats
     */
    public Stats getStats() {
        return stats;
    }

    /**
     * @param stats the stats to set
     */
    public void setStats(Stats stats) {
        this.stats = stats;
    }

    /**
     * @return the cbsdCategory
     */
    public String getCbsdCategory() {
        return cbsdCategory;
    }

    /**
     * @param cbsdCategory the cbsdCategory to set
     */
    public void setCbsdCategory(String cbsdCategory) {
        this.cbsdCategory = cbsdCategory;
    }

    /**
     * @return the airInterface
     */
    public String getAirInterface() {
        return airInterface;
    }

    /**
     * @param airInterface the airInterface to set
     */
    public void setAirInterface(String airInterface) {
        this.airInterface = airInterface;
    }

    /**
     * @return the measCapability
     */
    public ArrayList<String> getMeasCapability() {
        return measCapability;
    }

    /**
     * @param measCapability the measCapability to set
     */
    public void setMeasCapability(ArrayList<String> measCapability) {
        this.measCapability = measCapability;
    }

    /**
     * @return the antHeightType
     */
    public String getAntHeightType() {
        return antHeightType;
    }

    /**
     * @param antHeightType the antHeightType to set
     */
    public void setAntHeightType(String antHeightType) {
        this.antHeightType = antHeightType;
    }

    /**
     * @return the antAzimuth
     */
    public int getAntAzimuth() {
        return antAzimuth;
    }

    /**
     * @param antAzimuth the antAzimuth to set
     */
    public void setAntAzimuth(int antAzimuth) {
        this.antAzimuth = antAzimuth;
    }

    /**
     * @return the antDowntilt
     */
    public int getAntDowntilt() {
        return antDowntilt;
    }

    /**
     * @param antDowntilt the antDowntilt to set
     */
    public void setAntDowntilt(int antDowntilt) {
        this.antDowntilt = antDowntilt;
    }

    /**
     * @return the antGain
     */
    public int getAntGain() {
        return antGain;
    }

    /**
     * @param antGain the antGain to set
     */
    public void setAntGain(int antGain) {
        this.antGain = antGain;
    }

    /**
     * @return the antBeamwidth
     */
    public int getAntBeamwidth() {
        return antBeamwidth;
    }

    /**
     * @param antBeamwidth the antBeamwidth to set
     */
    public void setAntBeamwidth(int antBeamwidth) {
        this.antBeamwidth = antBeamwidth;
    }

    /**
     * @return the indoorDeployment
     */
    public int getIndoorDeployment() {
        return indoorDeployment;
    }

    /**
     * @param indoorDeployment the indoorDeployment to set
     */
    public void setIndoorDeployment(int indoorDeployment) {
        this.indoorDeployment = indoorDeployment;
    }

    /**
     * @return the measCap
     */
    public String getMeasCap() {
        return measCap;
    }

    /**
     * @param measCap the measCap to set
     */
    public void setMeasCap(String measCap) {
        this.measCap = measCap;
    }

    /**
     * @return the cpiId
     */
    public String getCpiId() {
        return cpiId;
    }

    /**
     * @param cpiId the cpiId to set
     */
    public void setCpiId(String cpiId) {
        this.cpiId = cpiId;
    }

    /**
     * @return the cpiSignatureAlgorithm
     */
    public String getCpiSignatureAlgorithm() {
        return cpiSignatureAlgorithm;
    }

    /**
     * @param cpiSignatureAlgorithm the cpiSignatureAlgorithm to set
     */
    public void setCpiSignatureAlgorithm(String cpiSignatureAlgorithm) {
        this.cpiSignatureAlgorithm = cpiSignatureAlgorithm;
    }
    
    class XmitExpTask extends TimerTask {
        private final String grantId;
        
        XmitExpTask(String grantId) {
            this.grantId = grantId;
        }
        @Override
        public void run() {
            for (CBSDGrantInfo grantInfo : getGrantList()) {
                if (grantInfo.getGrantId().equals(grantId)) {
                    //LogUtils.INSTANCE.writeLog("WARNING", "Transmit Expiry Time Expired for [" + getSasCbsdId() + "/"
                    //    + this.grantId + "]");
                    grantInfo.getTeTimer().cancel();
                    grantInfo.setTeTimerScheduled(false);
                    // THIS IS THE PLACE to STOP TRANSMISSION
                    break;
                }
            }
            
        }
        
    }
    private void handleGrantExpiration(String grantId) {
        sendRelinquishmentReq(grantId); 
    }
    private void sendRelinquishmentReq(String grantId) {
        Boolean sendRelinquishmentReq = false;
        for (CBSDGrantInfo grantInfo : getGrantList()) {
            if (grantInfo.getGrantId().equals(grantId)) {
                if (grantInfo.isHbTimerScheduled()) {
                    getHbTimer().cancel();
                    grantInfo.setHbTimerScheduled(false);
                    LogUtils.INSTANCE.writeLog("DEBUG", "HbTimerScheduled=" + grantInfo.isHbTimerScheduled());
                }
                grantInfo.setNewOpParam(false);
                grantInfo.setLowFrequency((int) getStartFreq());
                grantInfo.setHighFrequency((int) getEndFreq());
                sendRelinquishmentReq =true;
            }
            break;
        }
        if (sendRelinquishmentReq) {
            String msg = MsgGenerator.generateRelinquishmentReqMsg(getGrantList());
            // Send RELINQUISHMENT_REQ
            String url = "https://" + getCsasIpAddr();
            if (getCsasPortNum() > 0) {
                url += ":" + getCsasPortNum();
            }
            url += "/" + getCsasPath() + "/" + "relinquishment";
            String params = msg;
            Histogram.Timer relinquishReqTimer = relinquishmentRequestLatency.startTimer();
            boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.RELINQUISHMENT_REQ, getGrantList());

            if (sendReq == true) {
                relinquishReqTimer.observeDuration();
            } else {
                failedRelinquishmentRequests.inc();
            }
        }        
    }

    class HeartbeatTask extends TimerTask {

        public void run() {
            if (getState().getCurrState() != StateMachine.States.REGISTERED) {
                LogUtils.INSTANCE.writeLog("INFO", "CBSD is not in REGISTERED state");
                if (getHbTimer() != null) {
                    getHbTimer().cancel();
                }
                return;
            }
            if (checkSpectrumAgain) {
                // Generate SPECTRUM_INQ_REQ msg
                spectrumAvailable = false;
                checkSpectrum((long) getStartFreq(), (long) getEndFreq());
                if (spectrumAvailable) {
                    checkSpectrumAgain = false;
                    for (CBSDGrantInfo grantInfo : getGrantList()) {
                        sendRelinquishmentReq(grantInfo.getGrantId());
                    }
                }
            }
            Boolean sendHeartbeatReq = false;
            for (CBSDGrantInfo grantInfo : getGrantList()) {
                if (grantInfo.isRelinquishSent()) {
                    grantInfo.setRelinquishSent(false);
                    continue;
                }
                if (grantInfo.getGrantState().isGrantStateAUTHORIZED()
                        || grantInfo.getGrantState().isGrantStateGRANTED()) {
                    HeartbeatReqInfo info = new HeartbeatReqInfo();
                    info.setSasCbsdId(getSasCbsdId());
                    info.setGrantId(grantInfo.getGrantId());
                    info.setGrantRenew(grantInfo.isGrantRenew());
                    info.setOperationState(grantInfo.getGrantState().getCurrGrantStateString());

                    sendHeartbeatReq = true;
                    grantInfo.setHbTimerScheduled(false);
                    LogUtils.INSTANCE.writeLog("DEBUG", "HbTimerScheduled=" + grantInfo.isHbTimerScheduled());
                    getHbTimer().cancel();
                }
            }
            if (sendHeartbeatReq) {                
                String msg = MsgGenerator.generateHeartbeatReqMsg(getGrantList());
                String url = "https://" + getCsasIpAddr();
                if (getCsasPortNum() > 0) {
                    url += ":" + getCsasPortNum();
                }
                url += "/" + getCsasPath() + "/" + "heartbeat";
                String params = msg;
                Histogram.Timer hbReqTimer = heartbeatRequestLatency.startTimer();
                boolean sendReq = sendHttpsRequest(url, params, EventInfo.Message.HEARTBEAT_REQ, getGrantList());

                if (sendReq == false) {
                    failedHeartbeatRequests.inc();
                    for (CBSDGrantInfo grantInfo : getGrantList()) {
                        grantInfo.getGrantState().setCurrGrantState(GrantStates.GRANTED, grantInfo.getGrantId());
                    }    
                } else {
                    hbReqTimer.observeDuration();
                }
            }
        }
    }
    
    /**
     *
     */
    public static final class StateMachine {
        public enum States {
           UNREGISTERED, REGISTERED;
        }
        
        private final CBSD device;

        private States currState;
        private States prevState;
        
        public StateMachine(CBSD cbsd, int stateIdx) {
            this.device = cbsd;
            currState = States.values()[stateIdx];
        }
        
        public States getCurrState() {
            return currState;
        }

        public int getCurrStateIdx() {
            return currState.ordinal();
        }
                
        public String getCurrStateString() {
            return currState.toString();
        }

        public void setCurrState(States state, String sasCbsdId) {
            prevState = currState;
            currState = state;

            LogUtils.INSTANCE.writeLog("DEBUG", 
                "CBSD [" + device.getCbsdId() + "] " + getCurrStateString() + " STATE now. SAS CBSD ID: " + sasCbsdId);  
            
        }
    }      
}
