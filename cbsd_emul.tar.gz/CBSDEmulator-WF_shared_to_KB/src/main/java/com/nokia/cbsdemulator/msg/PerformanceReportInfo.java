/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.msg;

import java.util.ArrayList;

/**
 *
 * @author dbserver
 */
public class PerformanceReportInfo extends EventInfo {
    
    private ArrayList<PerformanceInfo> perfList;
    
    private String devId;
    private double startFreq; // Unit in MHz
    private double endFreq; // Unit in MHz
    private String startTime;
    private String endTime;
    private ArrayList rssiList; // Unit in dBm
    
    public PerformanceReportInfo() {
        perfList = new ArrayList();
        devId = "";
        startFreq = 0.0;
        endFreq = 0.0;
        startTime = "";
        endTime = "";
        rssiList = new ArrayList();
    }

    /**
     * @return the perfList
     */
    public ArrayList<PerformanceInfo> getPerfList() {
        return perfList;
    }

    /**
     * @param perfList the perfList to set
     */
    public void setPerfList(ArrayList<PerformanceInfo> perfList) {
        this.perfList = perfList;
    }

    /**
     * @return the devId
     */
    public String getDevId() {
        return devId;
    }

    /**
     * @param devId the devId to set
     */
    public void setDevId(String devId) {
        this.devId = devId;
    }

    /**
     * @return the startFreq
     */
    public double getStartFreq() {
        return startFreq;
    }

    /**
     * @param startFreq the startFreq to set
     */
    public void setStartFreq(double startFreq) {
        this.startFreq = startFreq;
    }

    /**
     * @return the endFreq
     */
    public double getEndFreq() {
        return endFreq;
    }

    /**
     * @param endFreq the endFreq to set
     */
    public void setEndFreq(double endFreq) {
        this.endFreq = endFreq;
    }

    /**
     * @return the startTime
     */
    public String getStartTime() {
        return startTime;
    }

    /**
     * @param startTime the startTime to set
     */
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endTime
     */
    public String getEndTime() {
        return endTime;
    }

    /**
     * @param endTime the endTime to set
     */
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    /**
     * @return the rssiList
     */
    public ArrayList getRssiList() {
        return rssiList;
    }

    /**
     * @param rssiList the rssiList to set
     */
    public void setRssiList(ArrayList rssiList) {
        this.rssiList = rssiList;
    }
}
