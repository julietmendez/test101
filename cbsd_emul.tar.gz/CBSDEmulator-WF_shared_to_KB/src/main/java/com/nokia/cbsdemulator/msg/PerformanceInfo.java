/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.msg;

/**
 *
 * @author dbserver
 */
public class PerformanceInfo {
    
    private String ticket;
    private String startTime;
    private String endTime;
    
    private int clientNum;
    private double avgThroughput;
    private double avgRetransNum;
    private double avgDelay;
    private double avgPer;
            
    public PerformanceInfo() {
        ticket = "";
        startTime = "";
        endTime = "";
        
        clientNum = 0;
        avgThroughput = 0.0;
        avgRetransNum = 0.0;
        avgDelay = 0.0;
        avgPer = 0.0;
    }

    /**
     * @return the ticket
     */
    public String getTicket() {
        return ticket;
    }

    /**
     * @param ticket the ticket to set
     */
    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    /**
     * @return the startTime
     */
    public String getStartTime() {
        return startTime;
    }

    /**
     * @param startTime the startTime to set
     */
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endTime
     */
    public String getEndTime() {
        return endTime;
    }

    /**
     * @param endTime the endTime to set
     */
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    /**
     * @return the clientNum
     */
    public int getClientNum() {
        return clientNum;
    }

    /**
     * @param clientNum the clientNum to set
     */
    public void setClientNum(int clientNum) {
        this.clientNum = clientNum;
    }

    /**
     * @return the avgThroughput
     */
    public double getAvgThroughput() {
        return avgThroughput;
    }

    /**
     * @param avgThroughput the avgThroughput to set
     */
    public void setAvgThroughput(double avgThroughput) {
        this.avgThroughput = avgThroughput;
    }

    /**
     * @return the avgRetransNum
     */
    public double getAvgRetransNum() {
        return avgRetransNum;
    }

    /**
     * @param avgRetransNum the avgRetransNum to set
     */
    public void setAvgRetransNum(double avgRetransNum) {
        this.avgRetransNum = avgRetransNum;
    }

    /**
     * @return the avgDelay
     */
    public double getAvgDelay() {
        return avgDelay;
    }

    /**
     * @param avgDelay the avgDelay to set
     */
    public void setAvgDelay(double avgDelay) {
        this.avgDelay = avgDelay;
    }

    /**
     * @return the avgPer
     */
    public double getAvgPer() {
        return avgPer;
    }

    /**
     * @param avgPer the avgPer to set
     */
    public void setAvgPer(double avgPer) {
        this.avgPer = avgPer;
    }
}
