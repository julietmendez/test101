/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.utils;

import static com.nokia.cbsdemulator.utils.LogUtils.SEVERE;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Enumeration;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * This class is the collection of useful methods related to networking. 
 * @author hyperkcw
 */
public class NetworkUtils {
            
    public static String getFirstNonLoopbackAddress() throws SocketException {
        Enumeration en = NetworkInterface.getNetworkInterfaces();
        
        while (en.hasMoreElements()) {
            NetworkInterface i = (NetworkInterface) en.nextElement();
            
            for (Enumeration en2 = i.getInetAddresses(); en2.hasMoreElements();) {
                InetAddress addr = (InetAddress) en2.nextElement();
                
                if (addr.isLoopbackAddress() == false) {
                    if (addr instanceof Inet4Address) {
                        // Remove "/" at the starting character of address
                        String strAddr = addr.toString().substring(1);
                                
                        return strAddr;
                    }
                }
            }
        }
        
        return null;
    }
    
    public static String getIpAddress(String ipAddr) throws SocketException {
        Enumeration en = NetworkInterface.getNetworkInterfaces();
        
        while (en.hasMoreElements()) {
            NetworkInterface i = (NetworkInterface) en.nextElement();
            
            for (Enumeration en2 = i.getInetAddresses(); en2.hasMoreElements();) {
                InetAddress addr = (InetAddress) en2.nextElement();
                
                if (addr.isLoopbackAddress() == false) {
                    if (addr instanceof Inet4Address) {
                        // Remove "/" at the starting character of address
                        String strAddr = addr.toString().substring(1);
                                
                        if (strAddr.equals(ipAddr)) {
                            return strAddr;
                        }
                    }
                }
            }
        }                
        
        return null;
    }
    
    public static boolean sendHttpsRequest(String url, String params, StringBuilder responseData) {
        HttpsURLConnection conn;
        BufferedReader br;
        
        int responseCode;
        boolean isRequestSuccess = false;
        char[] password = "csaskey".toCharArray();

        try (FileInputStream ksFis = new FileInputStream("./src/main/resources/client.jks");
             FileInputStream tsFis = new FileInputStream("./src/main/resources/trustStore.jks")){
            //TrustManager[] trustManager = new TrustManager[] {new TrustAllTrustManager()}; //only for bypassing cert authentication
                  
            // Initialize the keystore
            KeyStore ks = KeyStore.getInstance("JKS");
            ks.load(ksFis, password);
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(ks, password);

            // Setup the trust store manager factory
            KeyStore ts = KeyStore.getInstance("JKS");
            ts.load(tsFis, password);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(ts);

            //sslContext.init(null, trustManager, new java.security.SecureRandom());  //this allows to trust any certificate, but doesn't send a cert
            KeyManager[] km = kmf.getKeyManagers();
            TrustManager[] tm = tmf.getTrustManagers();
            SecureRandom random = new java.security.SecureRandom();

            SSLSocketFactoryEx factory = new SSLSocketFactoryEx(km, tm, random);
           
            URL urlObj = new URL(url);
            
            conn = (HttpsURLConnection) urlObj.openConnection();
            conn.setHostnameVerifier(new VerifyAllHostnameVerifier());
            conn.setSSLSocketFactory(factory);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Content-Length", Integer.toString(params.length()));
 
            conn.setDoOutput(true);
            conn.setDoInput(true);
 
            // Send POST Request
            LogUtils.INSTANCE.writeLog("DEBUG", "Sending POST request to URL : " + url);
            LogUtils.INSTANCE.writeLog("DEBUG", "Post parameters : " + params);

            DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
            wr.writeBytes(params);
            wr.flush();
            wr.close();
 
            responseCode = conn.getResponseCode();
            LogUtils.INSTANCE.writeLog("DEBUG", "Response Code : " + responseCode);
            
            if (responseCode / 100 != 2) {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                isRequestSuccess = true;
            }
            
            String inLine;
            //StringBuilder responseData = new StringBuilder();

            while ((inLine = br.readLine()) != null) {
                responseData.append(inLine);
            }
            
            LogUtils.INSTANCE.writeLog("DEBUG", "Response Body : " + responseData);

            br.close();
            
        } catch (MalformedURLException | NoSuchAlgorithmException | FileNotFoundException e1) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e1);
            //continue;
        } catch (IOException | CertificateException | KeyStoreException | UnrecoverableKeyException | KeyManagementException e2) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e2);
            //continue;
        }
        
        return isRequestSuccess;
    }
          
    public static class TrustAllTrustManager implements X509TrustManager {
        @Override
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        @Override
        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {   }

        @Override
        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {   }
    }
    
    public static class VerifyAllHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String str, SSLSession session) {
            return true;
        }
    }
    
    public static class SSLSocketFactoryEx extends SSLSocketFactory {

        private SSLContext m_ctx;
        private String[] m_ciphers;
        private String[] m_protocols;

        public SSLSocketFactoryEx() throws NoSuchAlgorithmException, KeyManagementException {
            initSSLSocketFactoryEx(null, null, null);
        }

        public SSLSocketFactoryEx(KeyManager[] km, TrustManager[] tm, SecureRandom random) throws NoSuchAlgorithmException, KeyManagementException {
            initSSLSocketFactoryEx(km, tm, random);
        }

        public SSLSocketFactoryEx(SSLContext ctx) throws NoSuchAlgorithmException, KeyManagementException {
            initSSLSocketFactoryEx(ctx);
        }

        public String[] getDefaultCipherSuites() {
            return m_ciphers;
        }

        public String[] getSupportedCipherSuites() {
            return m_ciphers;
        }

        public String[] getDefaultProtocols() {
            return m_protocols;
        }

        public String[] getSupportedProtocols() {
            return m_protocols;
        }

        public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
            SSLSocketFactory factory = m_ctx.getSocketFactory();
            SSLSocket ss = (SSLSocket) factory.createSocket(s, host, port, autoClose);

            ss.setEnabledProtocols(m_protocols);
            ss.setEnabledCipherSuites(m_ciphers);

            return ss;
        }

        public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
            SSLSocketFactory factory = m_ctx.getSocketFactory();
            SSLSocket ss = (SSLSocket) factory.createSocket(address, port, localAddress, localPort);

            ss.setEnabledProtocols(m_protocols);
            ss.setEnabledCipherSuites(m_ciphers);

            return ss;
        }

        public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
            SSLSocketFactory factory = m_ctx.getSocketFactory();
            SSLSocket ss = (SSLSocket) factory.createSocket(host, port, localHost, localPort);

            ss.setEnabledProtocols(m_protocols);
            ss.setEnabledCipherSuites(m_ciphers);

            return ss;
        }

        public Socket createSocket(InetAddress host, int port) throws IOException {
            SSLSocketFactory factory = m_ctx.getSocketFactory();
            SSLSocket ss = (SSLSocket) factory.createSocket(host, port);

            ss.setEnabledProtocols(m_protocols);
            ss.setEnabledCipherSuites(m_ciphers);

            return ss;
        }

        public Socket createSocket(String host, int port) throws IOException {
            SSLSocketFactory factory = m_ctx.getSocketFactory();
            SSLSocket ss = (SSLSocket) factory.createSocket(host, port);

            ss.setEnabledProtocols(m_protocols);
            ss.setEnabledCipherSuites(m_ciphers);

            return ss;
        }

        private void initSSLSocketFactoryEx(KeyManager[] km, TrustManager[] tm, SecureRandom random)
                throws NoSuchAlgorithmException, KeyManagementException {
            m_ctx = SSLContext.getInstance("TLSv1.2");
            m_ctx.init(km, tm, random);

            m_protocols = GetProtocolList();
            m_ciphers = GetCipherList();
        }

        private void initSSLSocketFactoryEx(SSLContext ctx)
                throws NoSuchAlgorithmException, KeyManagementException {
            m_ctx = ctx;

            m_protocols = GetProtocolList();
            m_ciphers = GetCipherList();
        }

        protected String[] GetProtocolList() {
            String[] preferredProtocols = {"TLSv1.2"};
            return preferredProtocols;
        }

        protected String[] GetCipherList() {
            String[] preferredCiphers = {
                "TLS_RSA_WITH_AES_128_GCM_SHA256",
                "TLS_RSA_WITH_AES_256_GCM_SHA384",
                "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
                "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384",
                "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
            };
            return preferredCiphers;
        }
    }    
}
