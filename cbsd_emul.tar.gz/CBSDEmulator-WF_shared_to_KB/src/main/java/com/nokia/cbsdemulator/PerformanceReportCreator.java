/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator;

import com.nokia.cbsdemulator.cbsd.CBSDInfo;
import com.nokia.cbsdemulator.cbsd.CBSDInterfaceInfo;
import com.nokia.cbsdemulator.msg.PerformanceInfo;
import com.nokia.cbsdemulator.msg.PerformanceReportInfo;
import com.nokia.cbsdemulator.utils.LogUtils;
import com.nokia.cbsdemulator.utils.TimeUtils;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author dbserver
 */
public class PerformanceReportCreator {
    
    private final String configFilePath;
    
    private static final double k = 1.3806488 * Math.pow(10, -23); // Boltzmann constant
    private static final double T = 300.0; // Temperature
    private static final double B = 10; // MHz

    private final int startFreq = 3550;
    private final int endFreq = 3650;
    
    private final double radius = 10.0; // km
    
    private String prevReportTime = "";
    private final PropagationModel model;
    
    public PerformanceReportCreator(String configFilePath) {
        this.configFilePath = configFilePath;
        
        // Get report time
        prevReportTime = TimeUtils.getCurrentDateTime(true);
        
        model = new PropagationModel(configFilePath);
    }
    
    public void SetReportStartTime(String reportTime) {
        prevReportTime = reportTime;
    }
/*    
    public PerformanceReportInfo create(int cbsdId, String devId, double latitude, double longitude,
            double txPower, double antHeight) {
        PerformanceReportInfo reportInfo = new PerformanceReportInfo();
//        reportInfo.msgType = Message.PERF_REPORT_NOTI;
        reportInfo.devId = devId;
        
        // Get report time
        String reportTime = TimeUtils.getCurrentDateTime(true);

        // Get Interface List of the current CBSD
        CBSDHandler handle = new CBSDHandler(this.configFilePath);
//        ArrayList<CBSDInterfaceInfo> ifList = handle.getInterfaces(cbsdId);

        // Get neighbor CBSDs within location
//        ArrayList<CBSDInfo> cbsdList = handle.getInterferedCbsdList(cbsdId, latitude, longitude, radius);

        createSensingData(cbsdList, reportTime, antHeight, reportInfo);
        
//        for (CBSDInterfaceInfo ifInfo : ifList) {
//            reportInfo.perfList.add(createPerformanceData(ifInfo, reportTime));
//        }
        
        return reportInfo;
    }
*/
    private void createSensingData(ArrayList<CBSDInfo> cbsdList, String reportTime, 
            double rxAntHeight, PerformanceReportInfo reportInfo) {
        reportInfo.setStartFreq((double)this.startFreq);
        reportInfo.setEndFreq((double)this.endFreq);

        reportInfo.setStartTime(prevReportTime);
        reportInfo.setEndTime(reportTime);
                
        Random rand = new Random();
        
        double thermalNoise_watt = k*T*(B*1000000.0); // MHz -> Hz

        for (int i = this.startFreq; i < this.endFreq; i += B) {
            double centerFreq = (double)(i + (double)B/2);
            double rssi_watt = thermalNoise_watt;
//LogUtils.INSTANCE.writeLog("WARNING", "centerFreq (MHz) = " + centerFreq);

            for (CBSDInfo cbsd : cbsdList) {
                if (centerFreq > cbsd.getStartFreq() && centerFreq < cbsd.getEndFreq()) {
                    // Calculate Path loss from each CBSD
                    double pathLoss = model.getPathLoss(centerFreq, cbsd.getDistance(), cbsd.getAntHeight(), rxAntHeight);

                    double receivedPower = cbsd.getAssignedTxPower() - pathLoss;
                            
//LogUtils.INSTANCE.writeLog("WARNING", "pathLoss (dB) = " + pathLoss);

                    rssi_watt += Math.pow(10.0, receivedPower/10.0) / 1000.0; // dBm -> watt
                }
            }
            
            double rssi_dBm = 10*Math.log10(rssi_watt*1000.0);
            rssi_dBm += getRandomGaussian(0.0f, 1.0f, rand); // AWGN
            
//LogUtils.INSTANCE.writeLog("WARNING", "Signal Strength (dBm) = " + rssi_dBm);
            reportInfo.getRssiList().add(rssi_dBm);
        }
    }
      
    private PerformanceInfo createPerformanceData(CBSDInterfaceInfo ifInfo, String reportTime) {
        PerformanceInfo perfInfo = new PerformanceInfo();
        
        Random rand = new Random();
        
        perfInfo.setTicket(ifInfo.getTicket());
        perfInfo.setStartTime(prevReportTime);
        perfInfo.setEndTime(reportTime);
        perfInfo.setClientNum(10 + (int)getRandomGaussian(0.0f, 1.0f, rand));
        perfInfo.setAvgThroughput(10.0 + getRandomGaussian(0.0f, 1.0f, rand)); // Mbps
        perfInfo.setAvgRetransNum(5.0 + getRandomGaussian(0.0f, 1.0f, rand));
        perfInfo.setAvgDelay(100.0 + getRandomGaussian(0.0f, 1.0f, rand)); // ms
        perfInfo.setAvgPer(0.01 + getRandomGaussian(0.0f, 0.0001f, rand));
        if (perfInfo.getAvgPer() <= 0) {perfInfo.setAvgPer(0);}
        
        return perfInfo;
    }
      
    private double getRandomUniform(int start, int end, Random rand) {
        double retNumber = 0.0;
        
        if (start > end) {
            LogUtils.INSTANCE.writeLog("WARNING", "The start number is greater than the end number");
            return retNumber;
        }
        
        // Get the range by casting to long to avoid overflow problems
        long range = (long)end - (long)start;
        double fraction = (double)(range * rand.nextDouble());
        
        retNumber = fraction + start;
        
        return retNumber;
    }
    
    private double getRandomGaussian(double mean, double variance, Random rand) {
        return mean + rand.nextGaussian() * Math.sqrt(variance);
    }        
}
