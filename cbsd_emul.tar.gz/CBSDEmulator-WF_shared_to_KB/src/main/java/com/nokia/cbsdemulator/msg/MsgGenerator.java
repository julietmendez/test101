/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

import com.nokia.cbsdemulator.cbsd.CBSDGrantInfo;
import com.nokia.cbsdemulator.cbsd.CBSDGrantInfo.GrantStateMachine.GrantStates;
import com.nokia.cbsdemulator.utils.LogUtils;
import com.nokia.cbsdemulator.utils.TimeUtils;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;

/**
 *
 * @author kutlay
 */
public class MsgGenerator {
    
    public enum CpiAlgorithm {
        RS256, //RSA_USING_SHA256
        ES256 //ECDSA_USING_P256_CURVE_AND_SHA256
    }
    
    public static String generateRegisterReqMsg(RegisterRequestInfo info) throws NoSuchAlgorithmException, InvalidKeyException {
        
        
        JsonArrayBuilder regArr = Json.createArrayBuilder();
        
        JsonObjectBuilder instParamObject = Json.createObjectBuilder();
        Boolean instParams = false;
        if ((info.getLatitude() >= -90.0) && (info.getLatitude() <= 90.0)) {
            instParamObject.add("latitude", info.getLatitude());
            instParams = true;
        }
        if ((info.getLongitude() >= -180.0) && (info.getLongitude() <= 180.0)) {
            instParamObject.add("longitude", info.getLongitude());
            instParams = true;
        }
        if (info.getAntHeight() >= 0.0) {
            instParamObject.add("height", info.getAntHeight());
            instParams = true;
        }
        if (!info.getAntHeightType().trim().isEmpty()) {
            instParamObject.add("heightType", info.getAntHeightType());
            instParams = true;
        }
        if ((info.getIndoorDeployment() == 0) || (info.getIndoorDeployment() == 1)) {
            if (info.getIndoorDeployment() == 0) {
                instParamObject.add("indoorDeployment", false);
            } else {
                instParamObject.add("indoorDeployment", true);
            }
            instParams = true;
        }
        if ((info.getAntAzimuth() >= 0) && (info.getAntAzimuth() < 360))  {
            instParamObject.add("antennaAzimuth", info.getAntAzimuth());
            instParams = true;
        }
        if ((info.getAntDowntilt() >= -90) && (info.getAntDowntilt() <= 90)){
            instParamObject.add("antennaDowntilt", info.getAntDowntilt());
            instParams = true;
        }
        if ((info.getAntGain() >= -127) && (info.getAntGain() <= 127)) {
            instParamObject.add("antennaGain", info.getAntGain());
            instParams = true;
        } 
        if ((info.getAntBeamwidth() >= 0) && (info.getAntBeamwidth() <= 360)){
            instParamObject.add("antennaBeamwidth", info.getAntBeamwidth());
            instParams = true;
        }
        if (info.getTxPower() > 0){
            instParamObject.add("eirpCapability", info.getTxPower());
            instParams = true;
        }
        Boolean airIntf = false;
        if (!info.getAirInterface().trim().isEmpty()) {
            airIntf = true;
        }
        JsonObjectBuilder regReqObj = Json.createObjectBuilder();
        regReqObj.add("userId", String.valueOf(info.getUserId())); 
        regReqObj.add("fccId", String.valueOf(info.getFccId()));
        regReqObj.add("cbsdSerialNumber", String.valueOf(info.getCbsdSerialNumber()));
        if (!info.getCbsdCategory().trim().isEmpty()) {
            regReqObj.add("cbsdCategory", String.valueOf(info.getCbsdCategory()));
        }
        if (airIntf) {
            regReqObj.add("airInterface", Json.createObjectBuilder()
                        .add("radioTechnology", String.valueOf(info.getAirInterface())));
        }

        if (!info.getMeasCap().trim().isEmpty()) {
            JsonArrayBuilder measArr = Json.createArrayBuilder();
            String measCap = info.getMeasCap().trim();
            if (measCap.equals("NONE")) {
                measArr.add("");
            }  else {
                measArr.add(measCap);
            }  
            regReqObj.add("measCapability", measArr);
        }
        if (info.getCpiId().trim().isEmpty()) {
            if (instParams) {
                regReqObj.add("installationParam", instParamObject);
            }        
        } else  {
            JsonObjectBuilder profInstallDataObjBldr = Json.createObjectBuilder();
            profInstallDataObjBldr.add("cpiId", String.valueOf(info.getCpiId())); 
            profInstallDataObjBldr.add("cpiName", "John Doe");
            profInstallDataObjBldr.add("installCertificationTime", TimeUtils.getCurrentDateTime(true));
            JsonObject profInstallDataObj = profInstallDataObjBldr.build();
            System.out.println("profInstallData: " + profInstallDataObj.toString());
            
            JsonObjectBuilder cpiSignedDataObjBldr = Json.createObjectBuilder();
            cpiSignedDataObjBldr.add("fccId", String.valueOf(info.getFccId())); 
            cpiSignedDataObjBldr.add("cbsdSerialNumber", String.valueOf(info.getCbsdSerialNumber()));
            cpiSignedDataObjBldr.add("installationParam", instParamObject);
            cpiSignedDataObjBldr.add("professionalInstallerData", profInstallDataObj);
            JsonObject cpiSignedDataObj = cpiSignedDataObjBldr.build();
            System.out.println("cpiSignedData: " + cpiSignedDataObj.toString());
            
            
            String cpiSerializedString = getCpiSerializedString(CpiAlgorithm.valueOf(info.getCpiSignatureAlgorithm()), cpiSignedDataObj);
            
            if(cpiSerializedString == null || cpiSerializedString.isEmpty()) {
                LogUtils.INSTANCE.writeLog("SEVERE", "Could not add CPI object");
            } else {
                String[] parts = cpiSerializedString.split("\\."); //we can split on "." since it's base64
                if (parts.length != 3) { 
                    LogUtils.INSTANCE.writeLog("SEVERE", "CPI serialized string is not formatted correctly: length:" + parts.length + "  Could not add CPI object");
                } else {
                    regReqObj.add("cpiSignatureData", Json.createObjectBuilder()
                            .add("protectedHeader", parts[0])
                            .add("encodedCpiSignedData", parts[1])
                            .add("digitalSignature", parts[2]));
                }
            }
        }

        regArr.add(regReqObj);
               
                //.add("groupingParam", Json.createArrayBuilder()
                //        .add(Json.createObjectBuilder()
                //                .add("groupId", String.valueOf(info.groupId))
                //                .add("groupType", String.valueOf(info.groupType))
                //        )
                //)

        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        objectBuilder.add("registrationRequest", regArr);
        JsonObject object = objectBuilder.build();

        LogUtils.INSTANCE.writeLog("DEBUG", object.toString());

        return object.toString();
    }
    public static String generateSpectrumInqReqMsg(SpectrumInqReqInfo info) {
        
        
        JsonArrayBuilder regArr = Json.createArrayBuilder();

        regArr.add(Json.createObjectBuilder()
                .add("cbsdId", info.getSasCbsdId())
                .add("inquiredSpectrum", Json.createArrayBuilder()
                        .add(Json.createObjectBuilder()
                                .add("lowFrequency", (long)info.getLowFreq() * 1000000)
                                .add("highFrequency", (long)info.getHighFreq() * 1000000)
                        )
                )
        );

        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        objectBuilder.add("spectrumInquiryRequest", regArr);
        JsonObject object = objectBuilder.build();

        LogUtils.INSTANCE.writeLog("DEBUG", object.toString());
    
        return object.toString();
    }   
    
    public static String generateGrantReqMsg(ArrayList<CBSDGrantInfo> grantList) {
        
        
        JsonArrayBuilder reqArr = Json.createArrayBuilder();
        for (CBSDGrantInfo info : grantList) {
            reqArr.add(Json.createObjectBuilder()
                    .add("cbsdId", info.getSasCbsdId())
                    .add("operationParam", Json.createObjectBuilder()
                            .add("maxEirp", info.getMaxEirp())
                            .add("operationFrequencyRange", Json.createObjectBuilder()
                    .add("lowFrequency", info.getLowFrequency())
                    .add("highFrequency", info.getHighFrequency())
                    )
                )
            );
        }
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        objectBuilder.add("grantRequest", reqArr);
        JsonObject object = objectBuilder.build();

        LogUtils.INSTANCE.writeLog("DEBUG", object.toString());
    
        return object.toString();
    }   
    
    public static String generateHeartbeatReqMsg(ArrayList<CBSDGrantInfo> grantList) {
        
        
        JsonArrayBuilder reqArr = Json.createArrayBuilder();
        for (CBSDGrantInfo info : grantList) {
            JsonObjectBuilder hbObject = Json.createObjectBuilder();
                hbObject
                    .add("cbsdId", info.getSasCbsdId())
                    .add("grantId", info.getGrantId());

            if (info.isGrantRenew()) {
                hbObject.add("grantRenew", info.isGrantRenew());
            }

            if (!info.getGrantState().getCurrGrantStateString().isEmpty()) {
                hbObject
                    .add("operationState", info.getGrantState().getCurrGrantStateString());

            }
            reqArr.add(hbObject);
        }
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        objectBuilder.add("heartbeatRequest", reqArr);
        JsonObject object = objectBuilder.build();

        LogUtils.INSTANCE.writeLog("DEBUG", object.toString());
    
        return object.toString();
    }   
    
    public static String generateRelinquishmentReqMsg(ArrayList<CBSDGrantInfo> grantList) {
        
        
        JsonArrayBuilder reqArr = Json.createArrayBuilder();
        for (CBSDGrantInfo info : grantList) {
            if (info.getGrantState().isGrantStateAUTHORIZED() || info.getGrantState().isGrantStateGRANTED()) {
                JsonObjectBuilder relObject = Json.createObjectBuilder();
                relObject
                        .add("cbsdId", info.getSasCbsdId())
                        .add("grantId", info.getGrantId());
                reqArr.add(relObject);
            }
        }
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        
        objectBuilder.add("relinquishmentRequest", reqArr);
        JsonObject object = objectBuilder.build();

        LogUtils.INSTANCE.writeLog("DEBUG", object.toString());
    
        return object.toString();
    } 
    
    public static String generateDeregistrationReqMsg(DeregistrationReqInfo info) {
        
        JsonArrayBuilder regArr = Json.createArrayBuilder();
        JsonObjectBuilder deregObject = Json.createObjectBuilder();

        deregObject
                .add("cbsdId", info.getSasCbsdId());
        regArr.add(deregObject);
        
        JsonObjectBuilder objectBuilder = Json.createObjectBuilder();
        objectBuilder.add("deregistrationRequest", regArr);
        JsonObject object = objectBuilder.build();

        LogUtils.INSTANCE.writeLog("DEBUG", object.toString());
    
        return object.toString();
    } 
    
    public static String hashMac(String text, String secretKey) throws InvalidKeyException {
        String encryptedText = "";
        try {
            Key sk = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
            Mac mac = Mac.getInstance(sk.getAlgorithm());
            mac.init(sk);
            final byte[] hmac = mac.doFinal(text.getBytes());
            encryptedText = toHexString(hmac);
            System.out.println("encryptedText: " + encryptedText);
        } catch (NoSuchAlgorithmException e1) {
            // throw an exception or pick a different encryption method

            LogUtils.INSTANCE.writeLog("DEBUG", "error building signature, no such algorithm in device HmacSHA256 ");
        }
        return encryptedText;
    }

    public static String toHexString(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(0xff & bytes[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
    
    public static String getCpiSerializedString(CpiAlgorithm algoType, JsonObject profInstallDataObj){
            
        FileInputStream fis = null;
        String serializedString = null;
        
        try {
            String PRIVATE_KEY_FILE = "";
            String algorithmValue = ""; //RSA_USING_SHA256, ECDSA_USING_P256_CURVE_AND_SHA256
            String keyFactoryInstanceType = ""; //RSA, EC
            switch (algoType) {
                case RS256:
                    //get the private key
                    PRIVATE_KEY_FILE = "./src/main/resources/CpiInstallerRsaPrivate-key.der";
                    algorithmValue = AlgorithmIdentifiers.RSA_USING_SHA256;
                    keyFactoryInstanceType = "RSA";
                    break;
                case ES256:
                    //get the private key
                    PRIVATE_KEY_FILE = "./src/main/resources/EcEcdsaP256Private-key.der";
                    algorithmValue = AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256;
                    keyFactoryInstanceType = "EC";
                    break;
                default:
                    LogUtils.INSTANCE.writeLog("WARNING", "Algorithm not supported:" + algoType);
                    return null;
            }
            
            File file = new File(PRIVATE_KEY_FILE);
            fis = new FileInputStream(file);
            byte[] keyBytes;
            try (DataInputStream dis = new DataInputStream(fis)) {
                keyBytes = new byte[(int) file.length()];
                dis.readFully(keyBytes);
            }
            PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory kf = KeyFactory.getInstance(keyFactoryInstanceType);
            PrivateKey privateKey = kf.generatePrivate(spec);

            String jsonStr = profInstallDataObj.toString();

            // A JWT is a JWS and/or a JWE with JSON claims as the payload.
            JsonWebSignature jws = new JsonWebSignature();
            jws.setHeader("typ", "JWT");
            jws.setAlgorithmHeaderValue(algorithmValue); //RSA_USING_SHA256, ECDSA_USING_P256_CURVE_AND_SHA256
            jws.setPayload(jsonStr);
            jws.setKey(privateKey);
            //jws.setDoKeyValidation(false); // relaxes the key length requirement
            serializedString = jws.getCompactSerialization();
            LogUtils.INSTANCE.writeLog("DEBUG", "jose token: " + serializedString);
                
        } catch (JoseException | IOException | NoSuchAlgorithmException | InvalidKeySpecException ex) {
            LogUtils.INSTANCE.writeLogEx("SEVERE", ex);
        } finally {
            try {
                if(fis != null) {
                    fis.close();
                }
            } catch (IOException ex) {
                LogUtils.INSTANCE.writeLogEx("SEVERE", ex);
            }
        }
        
        return serializedString;
    }
}
