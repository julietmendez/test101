/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

import java.util.ArrayList;

/**
 *
 * @author kutlay
 */
public class SpectrumInqRespInfo extends EventInfo {
    
    private String sasCbsdId;
    //public long lowFreq;
    //public long highFreq;
    private ArrayList<ChannelInfo> availChannels;
    
    public SpectrumInqRespInfo() {
        availChannels = new ArrayList();
        sasCbsdId = "";         
    }

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the availChannels
     */
    public ArrayList<ChannelInfo> getAvailChannels() {
        return availChannels;
    }

    /**
     * @param availChannels the availChannels to set
     */
    public void setAvailChannels(ArrayList<ChannelInfo> availChannels) {
        this.availChannels = availChannels;
    }
}


