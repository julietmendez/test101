/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.msg;

/**
 *
 * @author dbserver
 */
public class DeviceDescInfo {
    
    private String serialNum;
    private String fccId;
    private int operator;
    private String ipAddr;
    private int portNum;
            
    public DeviceDescInfo() {
        serialNum = "";
        fccId = "";
        operator = 0;
        ipAddr = "";
        portNum = 0;
    }    

    /**
     * @return the serialNum
     */
    public String getSerialNum() {
        return serialNum;
    }

    /**
     * @param serialNum the serialNum to set
     */
    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    /**
     * @return the fccId
     */
    public String getFccId() {
        return fccId;
    }

    /**
     * @param fccId the fccId to set
     */
    public void setFccId(String fccId) {
        this.fccId = fccId;
    }

    /**
     * @return the operator
     */
    public int getOperator() {
        return operator;
    }

    /**
     * @param operator the operator to set
     */
    public void setOperator(int operator) {
        this.operator = operator;
    }

    /**
     * @return the ipAddr
     */
    public String getIpAddr() {
        return ipAddr;
    }

    /**
     * @param ipAddr the ipAddr to set
     */
    public void setIpAddr(String ipAddr) {
        this.ipAddr = ipAddr;
    }

    /**
     * @return the portNum
     */
    public int getPortNum() {
        return portNum;
    }

    /**
     * @param portNum the portNum to set
     */
    public void setPortNum(int portNum) {
        this.portNum = portNum;
    }
}
