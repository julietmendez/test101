/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

/**
 *
 * @author kutlay
 */
public class RelinquishmentReqInfo extends EventInfo{
    private String sasCbsdId;
    private String grantId;
    
    public RelinquishmentReqInfo() {
        sasCbsdId = "";
        grantId = "";
    }

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the grantId
     */
    public String getGrantId() {
        return grantId;
    }

    /**
     * @param grantId the grantId to set
     */
    public void setGrantId(String grantId) {
        this.grantId = grantId;
    }
}
