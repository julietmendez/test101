/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.utils;

import com.nokia.cbsdemulator.cbsd.CBSDGrantInfo;
import com.nokia.cbsdemulator.msg.EventInfo.Message;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.util.ArrayList;


/**
 *
 * @author kutlay
 */
public class Stats {

       private final String graphiteServer;
    private final int graphitePort;

    public Stats (String graphiteServer, int graphitePort) {
        this.graphiteServer = graphiteServer;
        this.graphitePort = graphitePort;

    }
    public void update(Message msgType, String sasId, ArrayList<CBSDGrantInfo> grantList, String startTime, double elapsedTime) throws IOException {
        grantList.forEach((CBSDGrantInfo grantInfo) -> {
            try (final Socket socket = new Socket(Stats.this.graphiteServer, Stats.this.graphitePort);
                    final Writer writer = new OutputStreamWriter(socket.getOutputStream())) {
                Long timestamp = System.currentTimeMillis() / 1000;
                String sentMessage;
                
                if (grantInfo.getGrantId().isEmpty()) {
                    sentMessage = msgType.toString() + "." + sasId + " " + elapsedTime + " " + timestamp + "\n";
                } else {
                    sentMessage = msgType.toString() + "." + grantInfo.getGrantId() + " " + elapsedTime + " " + timestamp + "\n";
                }
                
                System.out.println(sentMessage);
                writer.write(sentMessage);
                writer.flush();
            } catch (IOException e) {
                LogUtils.INSTANCE.writeLog("DEBUG", "Failed to connect to" + Stats.this.graphiteServer);
            }
        });
    }
}
