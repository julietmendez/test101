/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.cbsd;

import com.nokia.cbsdemulator.ui.InterfaceModel;
import com.nokia.cbsdemulator.utils.LogUtils;
import com.nokia.cbsdemulator.ConfigHandler;
import com.nokia.cbsdemulator.PerformanceReportCreator;
import com.nokia.cbsdemulator.msg.EventInfo;
import com.nokia.cbsdemulator.msg.MsgParser;
import com.nokia.cbsdemulator.msg.RegisterResponseInfo;
import com.nokia.cbsdemulator.msg.SpectrumInqRespInfo;
import com.nokia.cbsdemulator.msg.GrantRespInfo;
import com.nokia.cbsdemulator.msg.HeartbeatRespInfo;
import com.nokia.cbsdemulator.msg.RelinquishmentRespInfo;
import com.nokia.cbsdemulator.msg.DeregistrationRespInfo;
import com.nokia.cbsdemulator.utils.Stats;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author kutlay
 */
public final class PALDevice extends CBSD implements Runnable {
    
    private volatile boolean running = false;
    private Thread thisThread;
    private boolean isEventInterrupted = false;


    // Initialize a new device
    
    public PALDevice(int cbsdId, double lat, double lng, ArrayList ifList, String sasCbsdId, String filePath, 
            String userId, String fccId, String devId, String cbsdCat, String airIntf, String measCap, String cpiId, String cpiSigAlgo, Stats stats) {
        super(0, filePath); // Call parent's constructor
        
        for (Iterator it = ifList.iterator(); it.hasNext();) {
            InterfaceModel ifModel = (InterfaceModel)it.next();
            CBSDGrantInfo tmpGrant = new CBSDGrantInfo(this); 
            tmpGrant.setMaxEirp(ifModel.getTxPower());
            tmpGrant.setLowFrequency((long) ifModel.getStartFreq() * 1000000);
            tmpGrant.setHighFrequency((long) ifModel.getEndFreq() * 1000000);
            long bw = tmpGrant.getHighFrequency()-tmpGrant.getLowFrequency();
            tmpGrant.setMaxEirp((ifModel.getTxPower()- 10.0));
            tmpGrant.setOrigLowFrequency(tmpGrant.getLowFrequency());
            tmpGrant.setOrigHighFrequency(tmpGrant.getHighFrequency());
            tmpGrant.setLoFreq(5785);
            super.getGrantList().add(tmpGrant); 
            super.setTxPower(ifModel.getTxPower());
            super.setAntHeight(createAntHeight(ifModel.getAntHeight()));
            super.setAntHeightType(ifModel.getAntHeightType());
            super.setAntAzimuth(ifModel.getAntAzimuth());
            super.setAntBeamwidth(ifModel.getAntBeamwidth());
            super.setAntDowntilt(ifModel.getAntDowntilt());
            super.setAntGain(ifModel.getAntGain());
            super.setIndoorDeployment(ifModel.getIndoorDeployment());
        }    

        
        super.setCbsdId(cbsdId);
        super.setUserId(userId);
        super.setFccId(fccId);
        super.setSerialNumber(devId);
        super.setSasCbsdId(sasCbsdId);
        super.setCbsdCategory(cbsdCat);
        super.setAirInterface(airIntf);
        super.setMeasCap(measCap);
        super.setCpiId(cpiId);
        super.setCpiSignatureAlgorithm(cpiSigAlgo);
        super.setAuthStatus(ConfigHandler.getSingletonInstance().getAuthStatusIdx("PAL"));
        
        super.setLatitude(lat);
        super.setLongitude(lng);
        
        super.setXmitExpTime("");        //this.cbsdPortNum = csasPortNum+1;
        super.setStats(stats);

    }
    

    @Override
    public void run() {
        LogUtils.INSTANCE.writeLog("DEBUG", "Start [" + Thread.currentThread().getName() + "] PAL [" + getCbsdId() + "]");
            
        thisThread = Thread.currentThread();
                
       // PerformanceReportCreator perfReportCreator = new PerformanceReportCreator(configFilePath);
                
        running = true;

        while (running) {
            try {
                handleState();
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                LogUtils.INSTANCE.writeLog("INFO", "Interrupted [" + Thread.currentThread().getName() + "] PAL [" + getCbsdId() + "]");
                Thread.currentThread().interrupt();
                if (isEventInterrupted == true) {
                    isEventInterrupted = false;
                }
            }
        }
    }
    
    public void stop() {
        LogUtils.INSTANCE.writeLog("INFO", "Stop [" + Thread.currentThread().getName() + "] PAL [" + getCbsdId() + "]");

        running = false;
    }
/*    
    private void interrupt() {
        LogUtils.INSTANCE.writeLog("INFO", "Interrupt PAL [" + getCbsdId() + "]");
        isEventInterrupted = true;
        thisThread.interrupt();
    }
*/    
    private void handleState() throws InterruptedException {
        switch (getState().getCurrState())
        {
            case UNREGISTERED:        
                try {
                    handleStateUnRegistered();
                } catch (NoSuchAlgorithmException | InvalidKeyException ex) {
                    Logger.getLogger(PALDevice.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            case REGISTERED:
                handleStateRegistered();
                break;

            default:
                LogUtils.INSTANCE.writeLog("INFO", "PAL [" + getCbsdId() + "] is in [" + getState().getCurrStateString() + "] state now.");
                break;
        }
    }
    
    @Override
    public boolean handleMsg(String msg, String clientAddr, ArrayList<CBSDGrantInfo> grantList) {
        LogUtils.INSTANCE.writeLog("INFO",  "[" + msg + "] from " + clientAddr);

        ArrayList<EventInfo> eventList = MsgParser.parseMsg(msg);
        for (EventInfo evt : eventList) {
            if (evt.getErrorType() != EventInfo.ErrorType.SUCCESS) {
                boolean cont = handleErrorRespEvt(evt);
                if (!cont) {
                    return false;
                }
            }

            switch (evt.getMsgType()) {
                case REGISTRATION_RESP:
                    handleEvtRegisterResp(eventList);
                    break;

                case SPECTRUM_INQ_RESP:
                    handleEvtSpectrumInqResp(eventList);
                    break;

                case GRANT_RESP:                
                    handleEvtGrantResp(eventList);
                    break; 

                case HEARTBEAT_RESP:
                    handleEvtHeartbeatResp(eventList);
                    break;     

                case RELINQUISHMENT_RESP:
                    handleEvtRelinquishmentResp(eventList);
                    break;  

                case DEREGISTRATION_RESP:
                    handleEvtDeregistrationResp(eventList);
                    if (isIsDeregistered()) {
                        stop();
                    }
                    setIsDeregistered(false);
                    break; 

                default:
                    handleErrorRespEvt(evt);
                    break;
            }
        }        
        return true;
    } 
    
    protected double createTxPower(double avgTxPower) {
        return avgTxPower + 0.0;
    }

    protected double createAntHeight(double avgAntHeight) {
        return avgAntHeight + 0.0;
    }
}
