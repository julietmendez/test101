/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.ui;


/**
 *
 * @author dbserver
 */
public class InterfaceModel {
    //private final SimpleStringProperty authStatus;
    private  int startFreq; //
    private  int endFreq; //
    private  double txPower; // Unit in mW
    private  double antHeight; // Unit in meter

    private String antHeightType;
    private int antAzimuth;
    private int antDowntilt;
    private int antGain;
    private int antBeamwidth;
    private int indoorDeployment; 
    
    /**
     *
     * @param txPower
     * @param antHeight
     * @param startFreq
     * @param endFreq
     * @param antHeightType
     * @param antAzimuth
     * @param antDowntilt
     * @param antGain
     * @param antBeamwidth
     * @param indoorDeployment
     */
    public InterfaceModel(double txPower, double antHeight, int startFreq, int endFreq, String antHeightType, int  antAzimuth, int antDowntilt, int antGain, int antBeamwidth, int indoorDeployment) {
        this.txPower = txPower;
        this.antHeight = antHeight;
        this.startFreq = startFreq;
        this.endFreq = endFreq;
        this.antHeightType = antHeightType;
        this.antAzimuth = antAzimuth;
        this.antDowntilt = antDowntilt;
        this.antGain = antGain;
        this.antBeamwidth = antBeamwidth;
        this.indoorDeployment = indoorDeployment;
        
    }

    public double getTxPower() {
        return txPower;
    }
    public void setTxPower(int power) {
        txPower=power;
    }

    public double getAntHeight() {
        return antHeight;
    }
    public void setAntHeight(double height) {
        antHeight=height;
    }
            
    public int getStartFreq() {
        return startFreq;
    }
    public void setStartFreq(int lf) {
        startFreq=lf;
    }          
  
    public int getEndFreq() {
        return endFreq;
    }
    public void setEndFreq(int hf) {
        endFreq=hf;
    }            

    /**
     * @return the antHeightType
     */
    public String getAntHeightType() {
        return antHeightType;
    }

    /**
     * @param antHeightType the antHeightType to set
     */
    public void setAntHeightType(String antHeightType) {
        this.antHeightType = antHeightType;
    }

    /**
     * @return the antAzimuth
     */
    public int getAntAzimuth() {
        return antAzimuth;
    }

    /**
     * @param antAzimuth the antAzimuth to set
     */
    public void setAntAzimuth(int antAzimuth) {
        this.antAzimuth = antAzimuth;
    }

    /**
     * @return the antDowntilt
     */
    public int getAntDowntilt() {
        return antDowntilt;
    }

    /**
     * @param antDowntilt the antDowntilt to set
     */
    public void setAntDowntilt(int antDowntilt) {
        this.antDowntilt = antDowntilt;
    }

    /**
     * @return the antGain
     */
    public int getAntGain() {
        return antGain;
    }

    /**
     * @param antGain the antGain to set
     */
    public void setAntGain(int antGain) {
        this.antGain = antGain;
    }

    /**
     * @return the antBeamwidth
     */
    public int getAntBeamwidth() {
        return antBeamwidth;
    }

    /**
     * @param antBeamwidth the antBeamwidth to set
     */
    public void setAntBeamwidth(int antBeamwidth) {
        this.antBeamwidth = antBeamwidth;
    }

    /**
     * @return the indoorDeployment
     */
    public int getIndoorDeployment() {
        return indoorDeployment;
    }

    /**
     * @param indoorDeployment the indoorDeployment to set
     */
    public void setIndoorDeployment(int indoorDeployment) {
        this.indoorDeployment = indoorDeployment;
    }
}
