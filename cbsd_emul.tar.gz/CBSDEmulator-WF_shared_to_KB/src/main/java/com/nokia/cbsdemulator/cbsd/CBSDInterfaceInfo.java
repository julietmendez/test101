/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nokia.cbsdemulator.cbsd;

/**
 *
 * @author dbserver
 */
public class CBSDInterfaceInfo {
    
    private int ifId;
    private String ticket;
    private String ticketExpireTime;
    
    private int authStatus;

    private double txPower; // Unit in mW
    private double antHeight; // Unit in meter
    private String antBase;
    
    private String license;
    
    private String ipAddr;
    private int portNum;
    
    public CBSDInterfaceInfo() {
        this.ifId = 0;
        this.ticket = "";
        this.ticketExpireTime = "";
        this.authStatus = 0;
        this.txPower = 0.0;
        this.antHeight = 0.0;
        this.antBase = "";
        this.license = "";
        this.ipAddr = "";
        this.portNum = 0;
    }
    
    public CBSDInterfaceInfo(int ifId, String ticket, String ticketExpireTime,
            int authStatus, double txPower, double antHeight, String antBase, 
            String license, String ipAddr, int portNum) {
        this.ifId = ifId;
        this.ticket = ticket;
        this.ticketExpireTime = ticketExpireTime;
        this.authStatus = authStatus;
        this.txPower = txPower;
        this.antHeight = antHeight;
        this.antBase = antBase;
        this.license = license;
        this.ipAddr = ipAddr;
        this.portNum = portNum;
    }

    /**
     * @return the ifId
     */
    public int getIfId() {
        return ifId;
    }

    /**
     * @param ifId the ifId to set
     */
    public void setIfId(int ifId) {
        this.ifId = ifId;
    }

    /**
     * @return the ticket
     */
    public String getTicket() {
        return ticket;
    }

    /**
     * @param ticket the ticket to set
     */
    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    /**
     * @return the ticketExpireTime
     */
    public String getTicketExpireTime() {
        return ticketExpireTime;
    }

    /**
     * @param ticketExpireTime the ticketExpireTime to set
     */
    public void setTicketExpireTime(String ticketExpireTime) {
        this.ticketExpireTime = ticketExpireTime;
    }

    /**
     * @return the authStatus
     */
    public int getAuthStatus() {
        return authStatus;
    }

    /**
     * @param authStatus the authStatus to set
     */
    public void setAuthStatus(int authStatus) {
        this.authStatus = authStatus;
    }

    /**
     * @return the txPower
     */
    public double getTxPower() {
        return txPower;
    }

    /**
     * @param txPower the txPower to set
     */
    public void setTxPower(double txPower) {
        this.txPower = txPower;
    }

    /**
     * @return the antHeight
     */
    public double getAntHeight() {
        return antHeight;
    }

    /**
     * @param antHeight the antHeight to set
     */
    public void setAntHeight(double antHeight) {
        this.antHeight = antHeight;
    }

    /**
     * @return the antBase
     */
    public String getAntBase() {
        return antBase;
    }

    /**
     * @param antBase the antBase to set
     */
    public void setAntBase(String antBase) {
        this.antBase = antBase;
    }

    /**
     * @return the license
     */
    public String getLicense() {
        return license;
    }

    /**
     * @param license the license to set
     */
    public void setLicense(String license) {
        this.license = license;
    }

    /**
     * @return the ipAddr
     */
    public String getIpAddr() {
        return ipAddr;
    }

    /**
     * @param ipAddr the ipAddr to set
     */
    public void setIpAddr(String ipAddr) {
        this.ipAddr = ipAddr;
    }

    /**
     * @return the portNum
     */
    public int getPortNum() {
        return portNum;
    }

    /**
     * @param portNum the portNum to set
     */
    public void setPortNum(int portNum) {
        this.portNum = portNum;
    }
}
