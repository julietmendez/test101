/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.cbsd;

//import cbsdemulator.cbsd.CBSDGrantInfo.GrantStateMachine.GrantStates;

//import cbsdemulator.cbsd.CBSD;
import cbsdemulator.utils.ParamUtils;
import com.nokia.cbsdemulator.ui.InterfaceModel;
import com.nokia.cbsdemulator.utils.GeoUtils;
import com.nokia.cbsdemulator.utils.LogUtils;
import com.nokia.cbsdemulator.utils.TimeUtils;
import com.nokia.cbsdemulator.DbHandler;
import static com.nokia.cbsdemulator.utils.LogUtils.SEVERE;
import com.nokia.cbsdemulator.utils.Stats;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

import java.io.File; 
import java.sql.PreparedStatement;
/**
 *
 * @author kutlay
 */
public class CBSDHandler extends DbHandler{
    
    private final String configFilePath;
    private final Stats stats;
    
    public CBSDHandler(String filePath, Stats stats) {
        this.configFilePath = filePath;
        this.stats = stats;
    }
    
    public ArrayList createNewCbsds(int cbsdId, double latitude, double longitude, ArrayList ifList, String userId, 
            String fccId, String devId, String cbsdCat, String airIntf, String measCap, String cpiId, String cpiKey, Stats stats) {

        ArrayList<CBSD> cbsdList = new ArrayList();
        String sasCbsdId = "";
                
        CBSD cbsd = createPalDevice(cbsdId, latitude, longitude, ifList, sasCbsdId, userId, fccId, devId, cbsdCat, airIntf, measCap, cpiId, cpiKey, stats);
        
        cbsdList.add(cbsd);

        return cbsdList;
    }

    public PALDevice createPalDevice(int cbsdId,
            double latitude, double longitude, ArrayList ifList, String sasCbsdId, String userId, String fccId, String devId, String cbsdCat, String airIntf, String measCap, String cpiId, String cpiKey, Stats stats) {
        PALDevice dev = new PALDevice(cbsdId, latitude, longitude, ifList, sasCbsdId, this.configFilePath, userId, fccId, devId, cbsdCat, airIntf, measCap, cpiId, cpiKey, stats);

        return dev;
    }
    
    private int getMaxCbsdId() {
        int id = 0;
        
        Statement st = null;
        try {
            String selectQuery = 
                    "SELECT MAX(cbsd_id) "
                    + "FROM cbsd_info";

//            LogUtils.INSTANCE.writeLog("INFO", selectQuery);
                    
            st = con.createStatement();
            try (ResultSet rs = st.executeQuery(selectQuery)) {

                while (rs.next()) {
                    id = rs.getInt("MAX(cbsd_id)") + 1;
                }
            }
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }
        
        return id;
    }
    
    private int getRegionCode(int regionIdx) {
        int regionCode = 0;
        
        Statement st = null;
        PreparedStatement pstmt = null;
        String selectQuery = 
                    "SELECT region_code " +
                    "FROM region_info " +
                    "WHERE region_id = ?";

        try {           
            pstmt = con.prepareStatement(selectQuery);
            pstmt.setInt(1, regionIdx);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    regionCode = rs.getInt("region_code");
                }
            }            
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }   
        return regionCode;
    }
    
    private Location createLocation(int area) {
        Location loc = new Location(1.0, 1.0);
                
        return loc;
    }
/*    
    private void saveNewCbsd(CBSD cbsd) throws SQLException {
        PreparedStatement st  = null;
        String insertQuery;
        for (CBSDGrantInfo grantInfo : cbsd.getGrantList()) {            
            insertQuery
                    = "INSERT INTO cbsd_info (cbsd_id,grant_id,operator,auth_status,"
                    + "latitude,longitude,tx_power,ant_height,start_freq,end_freq,"
                    + "bandwidth,assigned_tx_power,pal_license,device_id,state,sas_cbsd_id) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            LogUtils.INSTANCE.writeLog("INFO", insertQuery);

            try {
                st = con.prepareStatement(insertQuery);
                int i = 1;
                st.setInt(i++, cbsd.getCbsdId());
                st.setString(i++, grantInfo.getGrantId());
                st.setInt(i++, cbsd.getOperator());
                st.setInt(i++, cbsd.getAuthStatus());
                st.setDouble(i++, cbsd.getLatitude());
                st.setDouble(i++, cbsd.getLongitude());
                st.setDouble(i++, cbsd.getTxPower());
                st.setDouble(i++, cbsd.getAntHeight());
                st.setDouble(i++, cbsd.getStartFreq());
                st.setDouble(i++, cbsd.getEndFreq());
                st.setDouble(i++, cbsd.getBandwidth());
                st.setDouble(i++, cbsd.getAssignedPower());
                st.setString(i++, cbsd.getLicense());
                st.setString(i++, cbsd.getSerialNumber());
                st.setInt(i++, cbsd.getState().getCurrStateIdx());
                st.setString(i++, cbsd.getSasCbsdId());
                st.executeUpdate();
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            } finally {
                try {
                    if (st != null) {
                        st.close();
                    }
                } catch (SQLException e) {
                    LogUtils.INSTANCE.writeLogEx(SEVERE, e);
                }
            }
        }
    
}
    */
    public ArrayList getCbsdData(String configFilePath) throws NullPointerException, IOException {
       ArrayList<CBSD> list = new ArrayList(); 
       String csvFile ="";
      try { 
           csvFile = ParamUtils.INSTANCE.lookupSymbol("csv_file", configFilePath);
           csvFile = "./src/main/resources/" + csvFile;
        }
        catch(NullPointerException | IOException e) {
            LogUtils.INSTANCE.writeLog("INFO", e.getMessage());
        }
        File csvFileFromConfig = new File(csvFile);                
        if (!csvFileFromConfig.exists()) {
            csvFile ="./src/main/resources/10_New_York_New_York_wf_cbsd_devices.csv";
        }

        System.out.println("csvFile " + csvFile); 
        String line = "";
        String cvsSplitBy = ",";
        char commentline = '#';

        LineIterator it = FileUtils.lineIterator(new File(csvFile));
        try {
                while (it.hasNext()) {
                        line = it.nextLine();
                        if (line.charAt(0) == commentline) {
                            continue;
                        }
                
               //System.out.println("line :" + line); 
                String[] cbsd = line.split(cvsSplitBy);

                
                ArrayList ifList = new ArrayList();                
                String antHeightType = cbsd[11];
                String cbsdCat = cbsd[1];
                String airIntf = cbsd[2];
                String measCap = cbsd[19];
                String cpiId = cbsd[20];
                String cpiSigAlgo = cbsd[21];
                
                if (antHeightType.equals("?") == true) {
                    antHeightType = "";
                }
                if (cbsdCat.equals("?") == true) {
                    cbsdCat = "";
                }
                if (airIntf.equals("?") == true) {
                    airIntf = "";
                }
                if (true == measCap.equals("?")) {
                    measCap = "";
                }
                
                if (cpiId.equals("?") == true) {
                    cpiId = "";
                }

                if (cpiSigAlgo.equals("?") == true) {
                    cpiSigAlgo = "";
                }                
                ifList.add(new InterfaceModel(
                        Double.parseDouble(cbsd[7]),
                        Double.parseDouble(cbsd[8]),
                        (int)Double.parseDouble(cbsd[5]),
                        (int)Double.parseDouble(cbsd[6]),
                        antHeightType,
                        Integer.parseInt(cbsd[12]),
                        Integer.parseInt(cbsd[13]),
                        Integer.parseInt(cbsd[14]),
                        Integer.parseInt(cbsd[15]),
                        Integer.parseInt(cbsd[18].trim())));
                /*
                int lowFreq = (int)Double.parseDouble(cbsd[5]);
                int highFreq = (int)Double.parseDouble(cbsd[6]);
                if (highFreq < 3700) {
                    ifList.add(new InterfaceModel(
                        Double.parseDouble(cbsd[7]),
                        Double.parseDouble(cbsd[8]),
                        lowFreq + 10,
                        highFreq + 10,
                        antHeightType,
                        Integer.parseInt(cbsd[12]),
                        Integer.parseInt(cbsd[13]),
                        Integer.parseInt(cbsd[14]),
                        Integer.parseInt(cbsd[15]),
                        Integer.parseInt(cbsd[18].trim()))); 
                } */
                PALDevice tmpDev = new PALDevice(
                       Integer.parseInt(cbsd[0]),
                        Double.parseDouble(cbsd[3]),
                        Double.parseDouble(cbsd[4]),
                        ifList,
                        "",
                        configFilePath,
                        cbsd[16],
                        cbsd[17],
                        cbsd[10],
                        cbsdCat,
                        airIntf,
                        measCap,
                        cpiId,
                        cpiSigAlgo,
                        this.stats
                );

                list.add(tmpDev);

            }

        }
       finally {
                LineIterator.closeQuietly(it);
        }
        return list;

    }
     
    public void updateState(CBSD.StateMachine.States state, int cbsdId, String sasCbsdId) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return;
        }

        PreparedStatement st = null;
            
        int stateIdx = state.ordinal();
                
        String updateQuery
                = "UPDATE cbsd_info SET state = ?, sas_cbsd_id = ? "
                + "WHERE cbsd_id = ?";

        LogUtils.INSTANCE.writeLog("SQL", updateQuery);

        try {
            st = con.prepareStatement(updateQuery);
            int i = 1;
            st.setInt(i++, stateIdx);
            st.setString(i++, sasCbsdId);
            st.setInt(i++, cbsdId);
            st.executeUpdate();
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }
        disconnectDB();
    }
    
    public CBSD.StateMachine.States getState(int cbsdId, int ifId) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return null;
        }
        
        CBSD.StateMachine.States state;
        int stateIdx = 0;
                
        PreparedStatement st = null;

        String selectQuery = 
                    "SELECT state "
                    + "FROM cbsd_info "
                    + "WHERE cbsd_id = ?";
            
        try {           
            st = con.prepareStatement(selectQuery);
            st.setInt(1, cbsdId);
            try (ResultSet rs = st.executeQuery()) {
                while (rs.next()) {
                    stateIdx = rs.getInt("state");
                }
            }            
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }   
        
        state = CBSD.StateMachine.States.values()[stateIdx];
                
        disconnectDB();
        
        return state;
    }
    
    public void updateMaxGrants(int cbsdId, int maxGrants) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return;
        }

        PreparedStatement st = null;
        String updateQuery = 
                    "UPDATE cbsd_info SET max_grants = ?"
                    + " WHERE cbsd_id = ?"; 
                    
            LogUtils.INSTANCE.writeLog("SQL", updateQuery);
                    
        try {
            st = con.prepareStatement(updateQuery);
            int i = 1;
            st.setInt(i++, maxGrants);
            st.setInt(i++, cbsdId);
            st.executeUpdate();
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }
        disconnectDB();    
    }
       
    public int getMaxGrants(int cbsdId) {
        int maxGrants = 1;
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return maxGrants;
        }
        
        PreparedStatement st = null;

        String selectQuery = 
                    "SELECT max_grants "
                    + "FROM cbsd_info "
                    + "WHERE cbsd_id = ?";
            
           // LogUtils.INSTANCE.writeLog("INFO", selectQuery);
                    
        try {           
            st = con.prepareStatement(selectQuery);
            st.setInt(1, cbsdId);
            try (ResultSet rs = st.executeQuery()) {
                while (rs.next()) {
                    maxGrants = rs.getInt("max_grants");
                }
            }            
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }   
        
        disconnectDB();
        
        return maxGrants;
    }
    
    
    public String getTicket(int cbsdId, int ifId) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return null;
        }
        
        String ticket = "";
                
        PreparedStatement st = null;

        String selectQuery = 
                    "SELECT ticket "
                    + "FROM cbsd_info "
                    + "WHERE cbsd_id = ?";

//            LogUtils.INSTANCE.writeLog("INFO", selectQuery);
                    
        try {           
            st = con.prepareStatement(selectQuery);
            st.setInt(1, cbsdId);
            try (ResultSet rs = st.executeQuery()) {
                while (rs.next()) {
                    ticket = rs.getString("ticket");
                }
            }            
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }   
        
        
        disconnectDB();
        
        return ticket;        
    }
    
    public void updateGrantExpireTime(CBSDGrantInfo grantInfo, int cbsdId) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return;
        }

        PreparedStatement st = null;
            
        String updateQuery
                    = "UPDATE cbsd_grant_info SET "
                    + "grant_expire_time = ?" 
                    + " WHERE cbsd_id = ?"
                    + " AND grant_id = ?";

        LogUtils.INSTANCE.writeLog("INFO", updateQuery);
        try {
            st = con.prepareStatement(updateQuery);
            int i = 1;
            st.setString(i++, grantInfo.getGrantExpireTime());
            st.setInt(i++, cbsdId);
            st.setString(i++, grantInfo.getGrantId());
            st.executeUpdate();
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }
        
        disconnectDB();        
    }

    public void updateGrantInfo(CBSDGrantInfo grantInfo, int cbsdId) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return;
        }

        PreparedStatement st = null;
            
        long bandwidth = grantInfo.getHighFrequency() - grantInfo.getLowFrequency();
        int stateIdx = grantInfo.getGrantState().getCurrGrantStateIdx();
        String query;

        int i = 1;

        switch (grantInfo.getGrantState().getCurrGrantState()) {
            case NONE:
                query = "INSERT INTO cbsd_grant_info (cbsd_id,grant_id,"
                        + "grant_exp_time,grant_state,start_freq,end_freq,bandwidth,tx_power) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                try {
                    st = con.prepareStatement(query);
                    st.setInt(i++, cbsdId);
                    st.setString(i++, "0");
                    st.setString(i++, TimeUtils.parseIso8601DateTime(grantInfo.getGrantExpireTime()));
                    st.setInt(i++, 1);
                    st.setDouble(i++, grantInfo.getLowFrequency());
                    st.setDouble(i++, grantInfo.getHighFrequency());
                    st.setDouble(i++, bandwidth);
                    st.setDouble(i++, grantInfo.getMaxEirp());
                    st.executeUpdate();
                } catch (SQLException e) {
                    LogUtils.INSTANCE.writeLogEx(SEVERE, e);
                } finally {
                    try {
                        if (st != null) {
                            st.close();
                        }
                    } catch (SQLException e) {
                        LogUtils.INSTANCE.writeLogEx(SEVERE, e);
                    }
                }
                break;
            case IDLE:
            case GRANTED:
            case AUTHORIZED:
                query = "UPDATE cbsd_grant_info SET "
                        + "grant_id = ?,"
                        + "grant_state = ?,"
                        + " start_freq = ?,"
                        + " end_freq = ?,"
                        + " bandwidth = ?,"
                        + " tx_power = ?,"
                        + " grant_exp_time = ?"
                        + " WHERE (cbsd_id = ?)";
                try {
                    st = con.prepareStatement(query);
                    st.setString(i++, grantInfo.getGrantId());
                    st.setInt(i++, stateIdx);
                    st.setDouble(i++, grantInfo.getLowFrequency());
                    st.setDouble(i++, grantInfo.getHighFrequency());
                    st.setDouble(i++, bandwidth);
                    st.setDouble(i++, grantInfo.getMaxEirp());
                    st.setString(i++, TimeUtils.parseIso8601DateTime(grantInfo.getGrantExpireTime()));
                    st.setInt(i++, cbsdId);
                    st.executeUpdate();
                } catch (SQLException e) {
                    LogUtils.INSTANCE.writeLogEx(SEVERE, e);
                } finally {
                    try {
                        if (st != null) {
                            st.close();
                        }
                    } catch (SQLException e) {
                        LogUtils.INSTANCE.writeLogEx(SEVERE, e);
                    }
                }
                break;
            default:
                disconnectDB();
                return;
        }
        LogUtils.INSTANCE.writeLog("DEBUG", query);

        disconnectDB();        
    }
/*
    public ArrayList getInterferedCbsdList(int cbsdId, double latitude, double longitude, double radius) {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return null;
        }

        ArrayList<CBSDInfo> list = new ArrayList();

        PreparedStatement st = null;

        String selectQuery
                = "SELECT cbsd_id,grant_id,operator,auth_status,"
                + "latitude,longitude,tx_power,ant_height,"
                + "start_freq,end_freq,bandwidth,assigned_tx_power "
                + "FROM cbsd_info "
                + "WHERE state IN (?) "
                + "AND cbsd_id != ? "
                + "ORDER BY cbsd_id ASC";

//            LogUtils.INSTANCE.writeLog("INFO", selectQuery);
        try {
            st = con.prepareStatement(selectQuery);
            int i = 1;
            st.setInt(i++, CBSD.StateMachine.States.REGISTERED.ordinal());
            st.setInt(i++, cbsdId);
            try (ResultSet rs = st.executeQuery()) {

                while (rs.next()) {
                    double dist = GeoUtils.getDistance(latitude, longitude, rs.getDouble("latitude"), rs.getDouble("longitude"));

                    if (dist <= radius) {
//            LogUtils.INSTANCE.writeLog("WARNING", "CBSD ID = " + rs.getInt("cbsd_id") + ", distance = " + dist);
                        if (dist == 0) {
                            dist = 0.001;
                        }

                        CBSDInfo tmpCBSD = new CBSDInfo(
                                rs.getInt("cbsd_id"),
                                "",
                                rs.getInt("grant_id"),
                                rs.getInt("operator"),
                                rs.getInt("auth_status"),
                                rs.getDouble("latitude"),
                                rs.getDouble("longitude"),
                                rs.getDouble("tx_power"),
                                rs.getDouble("ant_height"),
                                "GROUND",
                                rs.getDouble("start_freq"),
                                rs.getDouble("end_freq"),
                                rs.getDouble("bandwidth"),
                                rs.getDouble("assigned_tx_power"),
                                dist
                        );

                        list.add(tmpCBSD);
                    }
                }
            }
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException e) {
                LogUtils.INSTANCE.writeLogEx(SEVERE, e);
            }
        }

        disconnectDB();

        return list;
    }
*/
    public void resetCbsds() {
        if (connectDB(configFilePath) == false) {
            LogUtils.INSTANCE.writeLog("WARNING", "DB connection failed");
            return;
        }

        try {
            String updateQuery
                    = "UPDATE cbsd_info SET state = 0, sas_cbsd_id = 0";

//            LogUtils.INSTANCE.writeLog("INFO", updateQuery);
            try (Statement st = con.createStatement()) {
                st.executeUpdate(updateQuery);
            }
            updateQuery
                    = "TRUNCATE TABLE cbsd_grant_info";
//            LogUtils.INSTANCE.writeLog("INFO", updateQuery);
            try (Statement st = con.createStatement() ) {
                st.executeUpdate(updateQuery);
            }    
        } catch (SQLException e) {
            LogUtils.INSTANCE.writeLogEx(SEVERE, e);
        } 

        disconnectDB();
    }

    private static class Location {
        private final double latitude;
        private final double longitude;
        
        public Location(double lat, double lng) {
            latitude = lat;
            longitude = lng;
        }
    }    
}
