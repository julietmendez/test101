/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.msg;

/**
 *
 * @author kutlay
 */
public class GrantRespInfo extends EventInfo{
    private String sasCbsdId;
    private String grantId;
    private String grantExpireTime;
    private int heartbeatInterval;
    private Double maxEirp;
    private long lowFreq;
    private long highFreq;
    
    public GrantRespInfo() {
        sasCbsdId = "";
        grantId = "";
        grantExpireTime = "";
        heartbeatInterval = 0;
        maxEirp = 0.0;
        lowFreq = 0;
        highFreq = 0;     
    }       

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the grantId
     */
    public String getGrantId() {
        return grantId;
    }

    /**
     * @param grantId the grantId to set
     */
    public void setGrantId(String grantId) {
        this.grantId = grantId;
    }

    /**
     * @return the grantExpireTime
     */
    public String getGrantExpireTime() {
        return grantExpireTime;
    }

    /**
     * @param grantExpireTime the grantExpireTime to set
     */
    public void setGrantExpireTime(String grantExpireTime) {
        this.grantExpireTime = grantExpireTime;
    }

    /**
     * @return the heartbeatInterval
     */
    public int getHeartbeatInterval() {
        return heartbeatInterval;
    }

    /**
     * @param heartbeatInterval the heartbeatInterval to set
     */
    public void setHeartbeatInterval(int heartbeatInterval) {
        this.heartbeatInterval = heartbeatInterval;
    }

    /**
     * @return the maxEirp
     */
    public Double getMaxEirp() {
        return maxEirp;
    }

    /**
     * @param maxEirp the maxEirp to set
     */
    public void setMaxEirp(Double maxEirp) {
        this.maxEirp = maxEirp;
    }

    /**
     * @return the lowFreq
     */
    public long getLowFreq() {
        return lowFreq;
    }

    /**
     * @param lowFreq the lowFreq to set
     */
    public void setLowFreq(long lowFreq) {
        this.lowFreq = lowFreq;
    }

    /**
     * @return the highFreq
     */
    public long getHighFreq() {
        return highFreq;
    }

    /**
     * @param highFreq the highFreq to set
     */
    public void setHighFreq(long highFreq) {
        this.highFreq = highFreq;
    }
}
