/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nokia.cbsdemulator.cbsd;

import com.nokia.cbsdemulator.utils.LogUtils;
import com.nokia.cbsdemulator.utils.TimeUtils;
import java.util.Timer;
import java.util.concurrent.TimeUnit;


/**
 *
 * @author kutlay
 */
public class CBSDGrantInfo {
    private String sasCbsdId;
    private String grantId;
    private GrantStateMachine grantState;
    private double maxEirp; // Unit in mW
    private long lowFrequency;
    private long highFrequency;
    private long origLowFrequency;
    private long origHighFrequency;
    private long loFreq; // used for setFreq (oldFreq..)
    private String grantExpireTime; //UTC time YYYY-MM-DDThh:mm:ssZ
    private int heartbeatInterval;
    private String transmitExpireTime;
    private boolean newOpParam;
    private boolean hbTimerScheduled;
    private Timer teTimer;   // transmit expiry timer
    private boolean teTimerScheduled;
    private long transmitExpireTimeInSec;
    private long grantExpireTimeInSec;
    private boolean grantRenew;
    private boolean relinquishSent;
    private boolean sendGrant;
    private boolean sendHeartbeat;
    private boolean sendRelinquishment;
    private boolean sendDeregister;
    
    public CBSDGrantInfo(CBSD cbsd) {
        this.sasCbsdId = "";
        this.grantId = "";
        this.grantState = new GrantStateMachine(cbsd);
        this.maxEirp = 0.0;
        this.lowFrequency = 0;
        this.highFrequency = 0;
        this.origLowFrequency = 0;
        this.origHighFrequency = 0;
        this.loFreq = 0;
        this.grantExpireTime = TimeUtils.getCurrentDateTime(true);
        this.heartbeatInterval = 0;
        this.transmitExpireTime = "";
        this.newOpParam = false;
        this.hbTimerScheduled = false;
        this.teTimerScheduled = false;
        this.transmitExpireTimeInSec = 0;
        this.grantExpireTimeInSec = 0;
        this.grantRenew = false;
        this.relinquishSent = false;
        this.sendGrant = false;
        this.sendHeartbeat = false;
        this.sendRelinquishment = false;
        this.sendDeregister = false;
    }
    
    public CBSDGrantInfo(String sasCbsdId, String grantId, int grantState, Double maxEirp,
            long lowFreq, long highFreq,
            String grantExpireTime, int heartbeatInterval,
            String transmitExpireTime) {
        this.sasCbsdId = sasCbsdId;
        this.grantId = grantId;
        this.grantState.setCurrGrantState(GrantStateMachine.GrantStates.values()[grantState], grantId);
        this.maxEirp = maxEirp;
        this.lowFrequency = lowFreq;
        this.highFrequency = highFreq;
        this.origLowFrequency = lowFreq;
        this.origHighFrequency = highFreq;
        this.loFreq = 5785;
        this.grantExpireTime = grantExpireTime;
        this.heartbeatInterval = heartbeatInterval;
        this.transmitExpireTime = transmitExpireTime;
        this.teTimerScheduled = false;
        this.transmitExpireTimeInSec = 0;
        this.grantExpireTimeInSec = 0;
        this.grantRenew = false;
        this.relinquishSent = false;
        this.sendGrant = false;
        this.sendHeartbeat = false;
        this.sendRelinquishment = false;
        this.sendDeregister = false;
    }
    
    public void setGrantId(String grantId) {
        this.grantId = grantId;
        
    }

    public String getGrantId() {
        return grantId;

    }
    public void setGrantExpireTime(String grantExpireTime) {    
        if (!grantExpireTime.equals(this.grantExpireTime)) {            
            String nowTime = TimeUtils.getCurrentDateTime(true);  
            this.setGrantExpireTimeInSec(TimeUtils.getTimeDiff(nowTime, grantExpireTime, TimeUnit.SECONDS, true)); 
            this.grantExpireTime = grantExpireTime;
        }
    }
    
    public void setTransmitExpireTime(String transmitExpireTime) {
        if (!transmitExpireTime.equals(this.transmitExpireTime)) {            
            String nowTime = TimeUtils.getCurrentDateTime(true);
            this.setTransmitExpireTimeInSec(TimeUtils.getTimeDiff(nowTime, transmitExpireTime, TimeUnit.SECONDS, true));
            this.transmitExpireTime = TimeUtils.parseIso8601DateTime(transmitExpireTime);
        }
    }
    
    public void setGrantHeartbeatInterval(int heartbeatInterval) {
        this.setHeartbeatInterval(heartbeatInterval);
    }
    
    public double getGrantHeartbeatInterval() {
        return getHeartbeatInterval();
    }
    
    public void setMaxEirp(double maxEirp) {
        this.maxEirp = maxEirp;

    }
    
    public void setFreqRange(long lowFreq, long highFreq) {
        this.setLowFrequency(lowFreq);
        this.setHighFrequency(highFreq);
      
    }

    /**
     * @return the sasCbsdId
     */
    public String getSasCbsdId() {
        return sasCbsdId;
    }

    /**
     * @param sasCbsdId the sasCbsdId to set
     */
    public void setSasCbsdId(String sasCbsdId) {
        this.sasCbsdId = sasCbsdId;
    }

    /**
     * @return the grantState
     */
    public GrantStateMachine getGrantState() {
        return grantState;
    }

    /**
     * @param grantState the grantState to set
     */
    public void setGrantState(GrantStateMachine grantState) {
        this.grantState = grantState;
    }

    /**
     * @return the maxEirp
     */
    public double getMaxEirp() {
        return maxEirp;
    }

    /**
     * @return the lowFrequency
     */
    public long getLowFrequency() {
        return lowFrequency;
    }

    /**
     * @param lowFrequency the lowFrequency to set
     */
    public void setLowFrequency(long lowFrequency) {
        this.lowFrequency = lowFrequency;
    }

    /**
     * @return the highFrequency
     */
    public long getHighFrequency() {
        return highFrequency;
    }

    /**
     * @param highFrequency the highFrequency to set
     */
    public void setHighFrequency(long highFrequency) {
        this.highFrequency = highFrequency;
    }

    /**
     * @return the origLowFrequency
     */
    public long getOrigLowFrequency() {
        return origLowFrequency;
    }

    /**
     * @param origLowFrequency the origLowFrequency to set
     */
    public void setOrigLowFrequency(long origLowFrequency) {
        this.origLowFrequency = origLowFrequency;
    }

    /**
     * @return the origHighFrequency
     */
    public long getOrigHighFrequency() {
        return origHighFrequency;
    }

    /**
     * @param origHighFrequency the origHighFrequency to set
     */
    public void setOrigHighFrequency(long origHighFrequency) {
        this.origHighFrequency = origHighFrequency;
    }

    /**
     * @return the loFreq
     */
    public long getLoFreq() {
        return loFreq;
    }

    /**
     * @param loFreq the loFreq to set
     */
    public void setLoFreq(long loFreq) {
        this.loFreq = loFreq;
    }

    /**
     * @return the grantExpireTime
     */
    public String getGrantExpireTime() {
        return grantExpireTime;
    }

    /**
     * @return the heartbeatInterval
     */
    public int getHeartbeatInterval() {
        return heartbeatInterval;
    }

    /**
     * @param heartbeatInterval the heartbeatInterval to set
     */
    public void setHeartbeatInterval(int heartbeatInterval) {
        this.heartbeatInterval = heartbeatInterval;
    }

    /**
     * @return the transmitExpireTime
     */
    public String getTransmitExpireTime() {
        return transmitExpireTime;
    }

    /**
     * @return the newOpParam
     */
    public boolean isNewOpParam() {
        return newOpParam;
    }

    /**
     * @param newOpParam the newOpParam to set
     */
    public void setNewOpParam(boolean newOpParam) {
        this.newOpParam = newOpParam;
    }

    /**
     * @return the hbTimerScheduled
     */
    public boolean isHbTimerScheduled() {
        return hbTimerScheduled;
    }

    /**
     * @param hbTimerScheduled the hbTimerScheduled to set
     */
    public void setHbTimerScheduled(boolean hbTimerScheduled) {
        this.hbTimerScheduled = hbTimerScheduled;
    }

    /**
     * @return the teTimer
     */
    public Timer getTeTimer() {
        return teTimer;
    }

    /**
     * @param teTimer the teTimer to set
     */
    public void setTeTimer(Timer teTimer) {
        this.teTimer = teTimer;
    }

    /**
     * @return the teTimerScheduled
     */
    public boolean isTeTimerScheduled() {
        return teTimerScheduled;
    }

    /**
     * @param teTimerScheduled the teTimerScheduled to set
     */
    public void setTeTimerScheduled(boolean teTimerScheduled) {
        this.teTimerScheduled = teTimerScheduled;
    }

    /**
     * @return the transmitExpireTimeInSec
     */
    public long getTransmitExpireTimeInSec() {
        return transmitExpireTimeInSec;
    }

    /**
     * @param transmitExpireTimeInSec the transmitExpireTimeInSec to set
     */
    public void setTransmitExpireTimeInSec(long transmitExpireTimeInSec) {
        this.transmitExpireTimeInSec = transmitExpireTimeInSec;
    }

    /**
     * @return the isGrantTimerExpired
     */
    public boolean isGrantTimerExpired() {
        String start = TimeUtils.getCurrentDateTime(true);
        String end = getGrantExpireTime();
        long timeDiff = TimeUtils.getTimeDiff(start, end, TimeUnit.SECONDS, true);
        if (timeDiff <= 300) {
            LogUtils.INSTANCE.writeLog("WARNING", "isGrantTimerExpired: currentTime:" + start + " grantExpireTime:" + end );
            return true;
        } else {
            return false;
        }       
    }

    /**
     * @return the grantExpireTimeInSec
     */
    public long getGrantExpireTimeInSec() {
        return grantExpireTimeInSec;
    }

    /**
     * @param grantExpireTimeInSec the grantExpireTimeInSec to set
     */
    public void setGrantExpireTimeInSec(long grantExpireTimeInSec) {
        this.grantExpireTimeInSec = grantExpireTimeInSec;
    }

    /**
     * @return the grantRenew
     */
    public boolean isGrantRenew() {
        return grantRenew;
    }

    /**
     * @param grantRenew the grantRenew to set
     */
    public void setGrantRenew(boolean grantRenew) {
        this.grantRenew = grantRenew;
    }
    /**
     * @return the relinquishSent
     */
    public boolean isRelinquishSent() {
        return relinquishSent;
    }

    /**
     * @param relinquishSent the relinquishSent to set
     */
    public void setRelinquishSent(boolean relinquishSent) {
        this.relinquishSent = relinquishSent;
    }
    
    public static final class GrantStateMachine {
        
        public enum GrantStates {
            NONE, IDLE, GRANTED, AUTHORIZED;
        }
        
        private final CBSD device;
        
        private GrantStates currGrantState;
        private GrantStates prevGrantState;
        
        public GrantStateMachine(CBSD cbsd) {
            this.device = cbsd;
            this.currGrantState = GrantStates.NONE;
        }
        
        public GrantStates getCurrGrantState() {
            return currGrantState;
        }

        public int getCurrGrantStateIdx() {
            return currGrantState.ordinal();
        }
                
        public String getCurrGrantStateString() {
            return currGrantState.toString();
        }

        public void setCurrGrantState(GrantStates state, String grantId) {
            currGrantState = state;
        }
      
        public boolean isGrantStateNONE() {
            return (currGrantState == GrantStates.NONE);
        }
        
        public boolean isGrantStateIDLE() {
            return (currGrantState == GrantStates.IDLE);
        }

        public boolean isGrantStateGRANTED() {
            return (currGrantState == GrantStates.GRANTED);
        }        
        
        public boolean isGrantStateAUTHORIZED() {
            return (currGrantState == GrantStates.AUTHORIZED);
        }
    }    

    /**
     * @return the sendGrant
     */
    public boolean isSendGrant() {
        return sendGrant;
    }

    /**
     * @param sendGrant the sendGrant to set
     */
    public void setSendGrant(boolean sendGrant) {
        this.sendGrant = sendGrant;
    }

    /**
     * @return the sendHeartbeat
     */
    public boolean isSendHeartbeat() {
        return sendHeartbeat;
    }

    /**
     * @param sendHeartbeat the sendHeartbeat to set
     */
    public void setSendHeartbeat(boolean sendHeartbeat) {
        this.sendHeartbeat = sendHeartbeat;
    }

    /**
     * @return the sendRelinquishment
     */
    public boolean isSendRelinquishment() {
        return sendRelinquishment;
    }

    /**
     * @param sendRelinquishment the sendRelinquishment to set
     */
    public void setSendRelinquishment(boolean sendRelinquishment) {
        this.sendRelinquishment = sendRelinquishment;
    }

    /**
     * @return the sendDeregister
     */
    public boolean isSendDeregister() {
        return sendDeregister;
    }

    /**
     * @param sendDeregister the sendDeregister to set
     */
    public void setSendDeregister(boolean sendDeregister) {
        this.sendDeregister = sendDeregister;
    }
}
